# -*- coding: utf-8 -*-
"""Arka planda çalışma: tek örnek, sistem tepsisi simgesi, Windows açılışında başlama, oturumu hatırlama,
sağ altta bildirim pencereleri."""
import os
import sys
import json
import time
import queue
import socket
import hashlib
import threading
import tkinter as tk

PROGRAM_KLASORU = os.path.dirname(os.path.abspath(__file__))
BASLANGIC_KISAYOLU = "Sipariş ve Gemi Takip (arka plan).lnk"
KOMUTLAR = queue.Queue()  # tepsi menüsü / ikinci örnek -> Tk (ana iş parçacığı)


# ====================================================================== tek örnek
def _port():
    h = int(hashlib.md5(PROGRAM_KLASORU.lower().encode("utf-8")).hexdigest()[:6], 16)
    return 47000 + h % 900


def tek_ornek(bekle=False):
    """Bu program bu bilgisayarda zaten açıksa ona 'pencereyi aç' der ve None döner.
    Açık değilse kilidi (dinleyen soket) döner. bekle=True: yeniden başlatmada eski örneğin kapanmasını bekler."""
    son = time.time() + (15 if bekle else 0)
    while True:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            s.bind(("127.0.0.1", _port()))
            s.listen(5)
            threading.Thread(target=_dinle, args=(s,), daemon=True).start()
            return s
        except OSError:
            s.close()
            if time.time() < son:
                time.sleep(0.5)
                continue
            try:
                c = socket.create_connection(("127.0.0.1", _port()), timeout=2)
                c.sendall(b"AC\n")
                c.close()
            except OSError:
                return socket.socket()  # kilit sahibine ulaşılamadı: yine de aç (sahte kilit)
            return None


def _dinle(s):
    while True:
        try:
            c, _ = s.accept()
            veri = c.recv(64).decode("ascii", "ignore").strip()
            c.close()
            if veri:
                KOMUTLAR.put(veri)
        except OSError:
            return


# ====================================================================== Windows açılışında başlama
def _baslangic_klasoru():
    try:
        import ctypes
        from ctypes import wintypes
        buf = ctypes.create_unicode_buffer(wintypes.MAX_PATH)
        ctypes.windll.shell32.SHGetFolderPathW(None, 0x0007, None, 0, buf)  # CSIDL_STARTUP
        if buf.value:
            return buf.value
    except Exception:
        pass
    return os.path.join(os.environ.get("APPDATA", ""), "Microsoft", "Windows", "Start Menu", "Programs", "Startup")


def baslangic_yolu():
    return os.path.join(_baslangic_klasoru(), BASLANGIC_KISAYOLU)


def baslangicta_mi():
    return sys.platform.startswith("win") and os.path.exists(baslangic_yolu())


def baslangica_ekle(acik=True):
    """(başarılı, mesaj). Windows açılınca program arka planda (tepside) başlar."""
    if not sys.platform.startswith("win"):
        return False, "Yalnızca Windows'ta."
    yol = baslangic_yolu()
    if not acik:
        try:
            if os.path.exists(yol):
                os.remove(yol)
            return True, ""
        except OSError as e:
            return False, str(e)
    try:
        import win32com.client
        from st_kisayol import _pythonw
        k = win32com.client.Dispatch("WScript.Shell").CreateShortCut(yol)
        k.TargetPath = _pythonw()
        k.Arguments = '"%s" --arka-plan' % os.path.join(PROGRAM_KLASORU, "siparis_takip.pyw")
        k.WorkingDirectory = PROGRAM_KLASORU
        k.IconLocation = os.path.join(PROGRAM_KLASORU, "simge.ico")
        k.Description = "Sipariş ve Gemi Takip – arka planda bildirimler"
        k.save()
        return True, yol
    except ImportError:
        return False, "pywin32 kütüphanesi bulunamadı."
    except Exception as e:
        return False, str(e)


# ====================================================================== oturumu hatırlama
def oturum_kaydet(ayarlar, kullanici, sifre_hash):
    """Bu bilgisayarda oturum açık kalır (Windows açılışında şifresiz giriş). Şifre saklanmaz; yalnızca kullanıcı
    numarası ve şifre özetinin parmak izi, Windows hesabına bağlı şifreleme (DPAPI) ile saklanır.
    Şifre değişirse ya da hesap pasif yapılırsa hatırlanan oturum geçersiz olur."""
    from st_programci import sifre_sakla
    veri = json.dumps({"kid": kullanici["id"], "kadi": kullanici["kadi"], "iz": sifre_hash[:24]})
    ayarlar["oturum"] = sifre_sakla(veri)


def oturum_oku(ayarlar, db):
    """Hatırlanan oturum geçerliyse kullanıcı sözlüğünü döner."""
    if not ayarlar.get("oturum"):
        return None
    try:
        from st_programci import sifre_coz
        d = json.loads(sifre_coz(ayarlar["oturum"]))
        r = db._taze("SELECT * FROM kullanicilar WHERE id=?", (d["kid"],)).fetchone()
        if not r or not r["aktif"] or r["kadi"] != d["kadi"] or not (r["sifre_hash"] or "").startswith(d["iz"]):
            return None
        u = dict(r)
        u.pop("sifre_hash", None)
        u.pop("tuz", None)
        return u
    except Exception:
        return None


def oturum_unut(ayarlar):
    ayarlar.pop("oturum", None)


# ====================================================================== sistem tepsisi
def pystray_var_mi():
    try:
        import pystray  # noqa
        return True
    except Exception:
        return False


def pystray_kur_arka_planda():
    """pystray yoksa arka planda kurar; bitince ana iş parçacığına 'TEPSI_KUR' komutu gönderir."""
    def is_():
        if _pystray(kur=True) is not None:
            KOMUTLAR.put("TEPSI_KUR")
    threading.Thread(target=is_, daemon=True).start()


def _pystray(kur=False):
    try:
        import pystray  # noqa
        return pystray
    except ImportError:
        pass
    if not kur or not sys.platform.startswith("win"):
        return None
    try:  # bir kez kurmayı dene (kurulum .exe'si zaten kurar)
        import subprocess
        exe = sys.executable
        if exe.lower().endswith("pythonw.exe"):
            exe = exe[:-len("pythonw.exe")] + "python.exe"
        subprocess.run([exe, "-m", "pip", "install", "--disable-pip-version-check", "pystray"], capture_output=True,
                       timeout=180, creationflags=0x08000000)
        import importlib
        importlib.invalidate_caches()
        import pystray  # noqa: F811
        return pystray
    except Exception:
        return None


class Tepsi:
    """Saatin yanındaki simge. Menü: Aç · Bildirimleri duraklat · Yeniden başlat · Programı kapat."""

    def __init__(self, baslik):
        self.simge = None
        self.duraklat = False
        pystray = _pystray()
        if pystray is None:
            return
        try:
            from PIL import Image
            try:
                resim = Image.open(os.path.join(PROGRAM_KLASORU, "simge.ico"))
            except Exception:
                resim = Image.new("RGB", (64, 64), (14, 35, 53))
            menu = pystray.Menu(
                pystray.MenuItem("Aç", lambda *_: KOMUTLAR.put("AC"), default=True),
                pystray.MenuItem("Bildirimleri duraklat", self._duraklat_degis, checked=lambda _i: self.duraklat),
                pystray.Menu.SEPARATOR,
                pystray.MenuItem("Yeniden başlat", lambda *_: KOMUTLAR.put("YENIDEN")),
                pystray.MenuItem("Programı kapat", lambda *_: KOMUTLAR.put("KAPAT")))
            self.simge = pystray.Icon("siparis_takip", resim, baslik, menu)
            self.simge.run_detached()
        except Exception:
            self.simge = None

    def _duraklat_degis(self, *_):
        self.duraklat = not self.duraklat
        KOMUTLAR.put("DURAKLAT_" + ("1" if self.duraklat else "0"))

    @property
    def var(self):
        return self.simge is not None

    def baslik(self, metin):
        if self.simge is not None:
            try:
                self.simge.title = metin[:120]
            except Exception:
                pass

    def kapat(self):
        if self.simge is not None:
            try:
                self.simge.stop()
            except Exception:
                pass
            self.simge = None


# ====================================================================== bildirim pencereleri
def _calisma_alani(root):
    """(sağ, alt) – görev çubuğu hariç ekran alanı."""
    try:
        import ctypes
        from ctypes import wintypes
        r = wintypes.RECT()
        ctypes.windll.user32.SystemParametersInfoW(0x0030, 0, ctypes.byref(r), 0)  # SPI_GETWORKAREA
        return r.right, r.bottom
    except Exception:
        return root.winfo_screenwidth(), root.winfo_screenheight() - 48


class Bildirimler:
    """Sağ altta üst üste dizilen, kendiliğinden kapanan bildirim kutuları. Tıklanınca ilgili ekran açılır."""
    GENISLIK = 380
    SURE_MS = 9000
    EN_COK = 4

    def __init__(self, root):
        self.root = root
        self.acik = []

    def goster(self, baslik, metin, tiklaninca=None, renk="#1F5F8B", ses=False):
        from st_ortak import font
        while len(self.acik) >= self.EN_COK:
            self._kapat(self.acik[0])
        p = tk.Toplevel(self.root)
        p.overrideredirect(True)
        try:
            p.attributes("-topmost", True)
            p.attributes("-alpha", 0.97)
        except tk.TclError:
            pass
        dis = tk.Frame(p, bg=renk)
        dis.pack(fill="both", expand=True)
        ic = tk.Frame(dis, bg="#FFFFFF", padx=14, pady=10)
        ic.pack(fill="both", expand=True, padx=(5, 1), pady=1)
        ust = tk.Frame(ic, bg="#FFFFFF")
        ust.pack(fill="x")
        tk.Label(ust, text="Sipariş ve Gemi Takip", bg="#FFFFFF", fg="#55606E", font=font(8, True)).pack(side="left")
        x = tk.Label(ust, text="✕", bg="#FFFFFF", fg="#55606E", font=font(10), cursor="hand2")
        x.pack(side="right")
        tk.Label(ic, text=baslik, bg="#FFFFFF", fg="#14202B", font=font(11, True), anchor="w", justify="left",
                 wraplength=self.GENISLIK - 40).pack(fill="x", pady=(2, 2))
        tk.Label(ic, text=metin, bg="#FFFFFF", fg="#33404D", font=font(9), anchor="w", justify="left",
                 wraplength=self.GENISLIK - 40).pack(fill="x")
        if tiklaninca:
            tk.Label(ic, text="Açmak için tıklayın", bg="#FFFFFF", fg="#1F5F8B", font=font(8)).pack(anchor="w", pady=(4, 0))

        def tikla(_e=None):
            self._kapat(p)
            if tiklaninca:
                tiklaninca()
        for w in [ic, ust] + list(ic.winfo_children()):
            if w is not x:
                w.bind("<Button-1>", tikla)
        x.bind("<Button-1>", lambda e: (self._kapat(p), "break")[1])
        p.bind("<Enter>", lambda e: setattr(p, "_uzerinde", True))
        p.bind("<Leave>", lambda e: setattr(p, "_uzerinde", False))
        self.acik.append(p)
        self._diz()
        self._zamanla(p, self.SURE_MS)
        if ses:
            try:
                import winsound
                winsound.MessageBeep(0x40)  # MB_ICONASTERISK
            except Exception:
                pass
        return p

    def _zamanla(self, p, ms):
        def bak():
            if p not in self.acik:
                return
            if getattr(p, "_uzerinde", False):  # fare üzerindeyken kapanmaz
                self._zamanla(p, 2000)
            else:
                self._kapat(p)
        p.after(ms, bak)

    def _kapat(self, p):
        if p in self.acik:
            self.acik.remove(p)
        try:
            p.destroy()
        except tk.TclError:
            pass
        self._diz()

    def _diz(self):
        sag, alt = _calisma_alani(self.root)
        y = alt - 12
        for p in reversed(self.acik):
            try:
                p.update_idletasks()
                h = p.winfo_reqheight()
                y -= h
                p.geometry("%dx%d+%d+%d" % (self.GENISLIK, h, sag - self.GENISLIK - 12, y))
                y -= 8
            except tk.TclError:
                pass

    def hepsini_kapat(self):
        for p in list(self.acik):
            self._kapat(p)
