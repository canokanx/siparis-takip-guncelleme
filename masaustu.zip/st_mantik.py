# -*- coding: utf-8 -*-
"""Sipariş ve Gemi Takip - iş kuralları (arayüzden bağımsız)."""
import re
import datetime as dt

from st_tanim import ASAMA, SEVIYE, DEPARTMANLAR, AKIS_IDLER, asama_no, alan_tanimi, gemi_anahtar  # noqa: F401

# Herkesin görebildiği kimlik alanları (iş akışının yürümesi için şart)
KIMLIK_ALANLARI = {"siparis_tarihi", "musteri", "gemi", "imo", "termin"}


# ------------------------------------------------------------------ tarih / sayı
def _yil(y):
    y = int(y)
    return y + 2000 if y < 100 else y


def tarih_coz(s):
    """gg.aa.yyyy (gg.aa.yy de kabul edilir)"""
    m = re.match(r"^\s*(\d{1,2})[./-](\d{1,2})[./-](\d{4}|\d{2})\s*$", s or "")
    if not m:
        return None
    try:
        return dt.date(_yil(m.group(3)), int(m.group(2)), int(m.group(1)))
    except ValueError:
        return None


def tarihsaat_coz(s):
    """gg.aa.yyyy ss:dd (gg.aa.yy ss:dd de kabul edilir)"""
    m = re.match(r"^\s*(\d{1,2})[./-](\d{1,2})[./-](\d{4}|\d{2})\s+(\d{1,2})[:.](\d{1,2})\s*$", s or "")
    if not m:
        return None
    try:
        return dt.datetime(_yil(m.group(3)), int(m.group(2)), int(m.group(1)), int(m.group(4)), int(m.group(5)))
    except ValueError:
        return None


def sayi_coz(s):
    s = (s or "").strip().replace(" ", "")
    if not s:
        return None
    if "," in s and "." in s:
        s = s.replace(".", "").replace(",", ".") if s.rfind(",") > s.rfind(".") else s.replace(",", "")
    elif "," in s:
        s = s.replace(",", ".")
    try:
        return float(s)
    except ValueError:
        return None


def bugun_str():
    return dt.date.today().strftime("%d.%m.%Y")


def simdi_str():
    return dt.datetime.now().strftime("%d.%m.%Y %H:%M")


def db_zaman_goster(z):
    """'2026-11-02 12:30:00' -> '02.11.2026 12:30'"""
    try:
        return dt.datetime.strptime(z, "%Y-%m-%d %H:%M:%S").strftime("%d.%m.%Y %H:%M")
    except Exception:
        return z or ""


def db_zaman_coz(z):
    try:
        return dt.datetime.strptime(z, "%Y-%m-%d %H:%M:%S")
    except Exception:
        return None


def alan_bicim_hatasi(tur, deger):
    if not deger:
        return None
    if tur == "tarih" and not tarih_coz(deger):
        return "gg.aa.yyyy biçiminde olmalı"
    if tur == "tarihsaat" and not tarihsaat_coz(deger):
        return "gg.aa.yyyy ss:dd biçiminde olmalı"
    if tur == "saataraligi":
        from st_ortak import saat_normalle
        n = saat_normalle(deger.strip())
        if not re.match(r"^\d{2}:\d{2}( - \d{2}:\d{2})?$", n) or \
                any(int(a) > 23 or int(b) > 59 for a, b in re.findall(r"(\d{2}):(\d{2})", n)):
            return "ss:dd - ss:dd biçiminde olmalı (ör. 09:00 - 12:00)"
    if tur == "sayi" and sayi_coz(deger) is None:
        return "sayı olmalı"
    return None


# ------------------------------------------------------------------ yetki
def seviye(kullanici):
    return SEVIYE.get(kullanici["rol"], 1)


def duzenleyebilir(kullanici, asama):
    if kullanici["rol"] == "ust":
        return True
    dept = ASAMA[asama]["dept"]
    if dept == "yonetici":
        return kullanici["rol"] == "yonetici"
    return kullanici["departman"] == dept


def kendi_bolumu(kullanici, asama):
    """Aşama, kullanıcının kendi departmanına mı ait?"""
    return bool(asama) and asama in ASAMA and ASAMA[asama]["dept"] == kullanici.get("departman")


def gorebilir(kullanici, giren_seviye, alan=None, asama=None):
    """Kural: herkes kendi seviyesi ve altındakilerin girdiğini görür.
    İstisna: kişi kendi departmanının aşamasındaki her girdiyi (Yönetici girdisi dahil) görür."""
    if alan in KIMLIK_ALANLARI:
        return True
    if kendi_bolumu(kullanici, asama):
        return True
    return (giren_seviye or 1) <= seviye(kullanici)


def asama_sorumlusu(asama):
    d = ASAMA[asama]["dept"]
    return "Yönetici" if d == "yonetici" else DEPARTMANLAR.get(d, d)


# ------------------------------------------------------------------ sipariş durumu
def deger(s, asama, alan):
    v = s.get("veri", {}).get(asama, {}).get(alan)
    return (v[0] if v else "") or ""


def genel_durum(s):
    """(metin, renk_anahtari, sıradaki sorumlu)"""
    d = s.get("durum", {})
    if s.get("iptal"):
        return "İptal edildi", "na", "—"
    if d.get(6) == "prog":
        return "İade / değişim sürecinde", "prog", "Yönetici"
    etiketler = {1: "Kayıt bekliyor", 7: "Depoya sevkiyat bekleniyor", 2: "Depoda hazırlanıyor", 3: "Sevk planlanıyor",
                 4: "Evrak bekleniyor", 5: "Gemiye sevkiyat bekleniyor", 8: "Tahsilat bekleniyor"}
    for n in AKIS_IDLER:
        if d.get(n, "todo") not in ("done", "na"):
            etiket = etiketler[n]
            if n == 1 and d.get(1, "todo") == "todo":
                etiket = "Taslak"
            return etiket, ("todo" if n == 1 else "prog"), asama_sorumlusu(n)
    return "Kapandı", "done", "—"


def acik_mi(s):
    return genel_durum(s)[0] not in ("Kapandı", "İptal edildi")


def gecikmis_mi(s):
    t = tarih_coz(deger(s, 1, "termin"))
    return bool(t and t < dt.date.today() and s.get("durum", {}).get(2) != "done" and acik_mi(s))


# ------------------------------------------------------------------ tamamlama kontrolü
def tamamlama_engelleri(db, sid, asama, kullanici, form_degerleri=None):
    """Aşamanın tamamlanmasını engelleyen sorunların listesi (boşsa tamamlanabilir)."""
    sorunlar = []
    kayitli = {k: v["deger"] for k, v in db.alan_degerleri(sid, asama).items()}
    if form_degerleri:
        kayitli.update(form_degerleri)
    for anahtar, etiket, zorunlu, tur, _ in ASAMA[asama]["alanlar"]:
        v = (kayitli.get(anahtar) or "").strip()
        if zorunlu and not v:
            sorunlar.append("%s boş" % etiket)
        h = alan_bicim_hatasi(tur, v)
        if h:
            sorunlar.append("%s %s" % (etiket, h))
    durum = db.durumlar(sid)
    if asama == 1:
        imo = (kayitli.get("imo") or "").strip()
        if imo and not re.match(r"^\d{7}$", imo):
            sorunlar.append("IMO numarası 7 haneli olmalı")
        if not db.satirlar(sid):
            sorunlar.append("En az bir malzeme satırı eklenmeli")
    elif asama == 2:
        if not (kayitli.get("depo_durumu") or "").startswith("Hazır"):
            sorunlar.append("Genel depo durumu 'Hazır (sevke hazır)' olmalı")
        for r in db.satirlar(sid):
            t = r["toplama"] or "Bekliyor"
            if t == "Tamamlandı":
                continue
            if t in ("Eksik", "Muadil önerildi") and (r["satir_notu"] or "").strip() and kullanici["rol"] in ("yonetici", "ust"):
                continue  # eksik açıkça belirtilmiş ve yetkili onaylıyor
            sorunlar.append("Ürün tamamlanmadı: %s (%s)" % (r["malzeme"], t))
    elif asama == 3:
        if kayitli.get("giris_izni") == "Bekleniyor":
            sorunlar.append("Liman / tesis giriş izni henüz alınmadı")
    elif asama == 4:
        if kayitli.get("kontrol") != "Tamamlandı":
            sorunlar.append("Kontrol durumu 'Tamamlandı' olmalı")
        sorunlar.extend(kap_kilo_uyusmazligi(db, sid, kayitli))
    elif asama == 7:
        if kayitli.get("tedarik_durumu") != "Depoya ulaştı":
            sorunlar.append("Sevkiyat durumu 'Depoya ulaştı' olmalı")
        if not (kayitli.get("depoya_varis") or "").strip():
            sorunlar.append("Depoya varış tarihi / saati boş")
    elif asama == 5:
        eksik = [str(asama_no(n)) for n in (1, 7, 2, 3, 4) if durum.get(n, "todo") not in ("done", "na")]
        if eksik:
            sorunlar.append("Önce %s. aşama(lar) tamamlanmalı" % ", ".join(eksik))
        if kayitli.get("gemi_teslim_durumu") not in ("Gemiye teslim edildi", "Kısmi teslim"):
            sorunlar.append("Teslim durumu 'Gemiye teslim edildi' (ya da 'Kısmi teslim') olmalı")
        if kayitli.get("gemi_teslim_durumu") == "Kısmi teslim" and not (kayitli.get("sevkiyat_notu") or "").strip():
            sorunlar.append("Kısmi teslimde sevkiyat notuna eksikler yazılmalı")
    elif asama == 8:
        if durum.get(5, "todo") != "done":
            sorunlar.append("Önce %d. aşama (Gemiye Sevkiyat) tamamlanmalı" % asama_no(5))
        if kayitli.get("tahsilat_durumu") != "Ödendi":
            sorunlar.append("Tahsilat durumu 'Ödendi' olmalı")
    return sorunlar


def tamamlama_uyarilari(db, sid, asama):
    """Zorunlu olmayan eksikler: aşama tamamlanırken kullanıcıya sorulur ('Vazgeç' / 'Tamamla')."""
    uyarilar = []
    if asama == 2 and not db.ekler(sid, 2):
        uyarilar.append("Ürün / paket fotoğrafı yüklenmedi")
    if asama == 4 and not db.ekler(sid, 4):
        uyarilar.append("Evrak dosyası (PDF / görsel) yüklenmedi")
    return uyarilar


def kap_kilo_uyusmazligi(db, sid, evrak_degerleri=None):
    depo = {k: v["deger"] for k, v in db.alan_degerleri(sid, 2).items()}
    evrak = evrak_degerleri if evrak_degerleri is not None else {k: v["deger"] for k, v in db.alan_degerleri(sid, 4).items()}
    out = []
    for d_alan, e_alan, ad in (("kap", "toplam_kap", "KAP"), ("brut", "brut", "Brüt ağırlık")):
        a, b = sayi_coz(depo.get(d_alan)), sayi_coz(evrak.get(e_alan))
        if a is not None and b is not None and abs(a - b) > 0.001:
            out.append("Tutarsızlık: evraktaki %s (%s) depo kaydıyla (%s) uyuşmuyor" % (ad, evrak.get(e_alan), depo.get(d_alan)))
    return out


# ------------------------------------------------------------------ ETA
def eta_farki(yeni, eski):
    a, b = tarihsaat_coz(yeni), tarihsaat_coz(eski)
    if not a or not b:
        return None, "—"
    saat = round((a - b).total_seconds() / 3600)
    if saat == 0:
        return 0, "Teyit (değişmedi)"
    if saat > 0:
        return saat, "+%d sa · gecikti" % saat
    return saat, "−%d sa · erkene alındı" % (-saat)


# ------------------------------------------------------------------ gemi takip listesi
def gemileri_esitle(db, kullanici, kegm=None, siparis_id=None):
    """Siparişlerdeki gemi adı / IMO'ya göre gemi kayıtlarını oluşturur ve siparişleri bağlar.
    Sipariş açılıp gemi adı veya IMO girildiği anda gemi takibe girer."""
    from st_kegm import bul
    gemiler = {g["id"]: g for g in db.gemiler()}
    # aynı IMO'lu birden çok gemi kaydı varsa (iki bilgisayar aynı anda eklemiş) birleştir
    sayac = {}
    for g in gemiler.values():
        if (g.get("imo") or "").strip():
            sayac.setdefault(g["imo"].strip(), []).append(g["id"])
    if any(len(v) > 1 for v in sayac.values()):
        for imo, ids in sayac.items():
            if len(ids) > 1:
                db.ayni_imo_birlestir(imo, kullanici)
        gemiler = {g["id"]: g for g in db.gemiler()}
    for s in db.siparis_listesi():
        if siparis_id is not None and s["id"] != siparis_id:
            continue
        ad, imo = deger(s, 1, "gemi").strip(), deger(s, 1, "imo").strip()
        if imo and not re.match(r"^\d{7}$", imo):
            imo = ""
        g = gemiler.get(s.get("gemi_id"))
        if g and ((imo and g.get("imo") == imo) or (not imo and ad and g["anahtar"] == gemi_anahtar(ad))) \
                and not g["ad"].startswith("IMO "):
            continue  # zaten doğru bağlı; buluta gereksiz sorgu gönderme
        if not ad and not imo:
            if s.get("gemi_id"):
                db.siparis_gemiye_bagla(s["id"], None)
            continue
        kaynak_ad = None
        if imo and kegm:
            es = bul(kegm, imo, "")
            kaynak_ad = es["satir"].get("ad") if es else None
        gid = db.gemi_bul_veya_olustur(ad, imo, kullanici, s["id"], kaynak_ad=kaynak_ad)
        if gid and gid != s.get("gemi_id"):
            db.siparis_gemiye_bagla(s["id"], gid)


def takip_gemileri(db, siparisler=None):
    """Açık siparişi olan gemiler (siparişe gemi adı veya IMO girilince otomatik eklenir)."""
    siparisler = siparisler if siparisler is not None else db.siparis_listesi()
    gemiler = {g["id"]: g for g in db.gemiler()}
    etalar = db.tum_etalar()
    sonuc = {}
    for s in siparisler:
        if not acik_mi(s) or not s.get("gemi_id"):
            continue
        a = s["gemi_id"]
        g = gemiler.get(a)
        if not g:
            continue
        if a not in sonuc:
            sonuc[a] = dict(g, siparisler=[], etalar=etalar.get(g["id"], []))
        sonuc[a]["siparisler"].append(s)
    for g in sonuc.values():
        g["depo"], g["depo_renk"] = depo_ozeti(g["siparisler"])
    return sorted(sonuc.values(), key=lambda g: (eta_siralama(g), g["ad"]))


def eta_siralama(g):
    if g["etalar"]:
        t = tarihsaat_coz(g["etalar"][0]["eta"])
        if t:
            return t
    return dt.datetime(2999, 1, 1)


def depo_ozeti(siparisler):
    if not siparisler:
        return "—", "na"
    hazir = [s for s in siparisler if s["durum"].get(2) == "done"]
    if len(hazir) == len(siparisler):
        return "Hazır", "done"
    if len(siparisler) > 1 and hazir:
        return "Kısmen hazır (%d/%d)" % (len(hazir), len(siparisler)), "prog"
    acik = [s for s in siparisler if s["durum"].get(2) != "done"][0]
    v = deger(acik, 2, "depo_durumu")
    if v:
        return v, ("todo" if v.startswith("Eksik") else "prog")
    return ("Malzeme toplanıyor", "prog") if acik["durum"].get(2) == "prog" else ("Malzeme planlanıyor", "todo")


# ------------------------------------------------------------------ uyarılar
def kegm_eslesme(g, kegm):
    """Takipteki gemiyi Kıyı Emniyeti boğaz listelerinde bulur (IMO, yoksa ad)."""
    if not kegm:
        return None
    from st_kegm import bul
    return bul(kegm, (g.get("imo") or "").strip(), g.get("ad"))


def uyarilar(db, kullanici, siparisler=None, gemiler=None, kegm=None):
    siparisler = siparisler if siparisler is not None else db.siparis_listesi()
    gemiler = gemiler if gemiler is not None else takip_gemileri(db, siparisler)
    simdi = dt.datetime.now()
    out = []

    def ekle(anahtar, oncelik, baslik, metin, kaynak, gemi_id=None, siparis_id=None):
        out.append({"anahtar": anahtar, "oncelik": oncelik, "baslik": baslik, "metin": metin,
                    "kaynak": kaynak, "gemi_id": gemi_id, "siparis_id": siparis_id})

    for g in gemiler:
        e = g["etalar"]
        eta = tarihsaat_coz(e[0]["eta"]) if e else None
        hazir_degil = [s for s in g["siparisler"] if s["durum"].get(2) != "done"]
        no_list = ", ".join(s["no"] for s in g["siparisler"])
        if eta:
            kalan = (eta - simdi).total_seconds() / 3600
            if -12 < kalan <= 24 and hazir_degil:
                ekle("kritik-%d-%d" % (g["id"], e[0]["id"]), "Kritik",
                     "%s – ETA'ya 24 saatten az kaldı, depo hazır değil" % g["ad"],
                     "Acente ETA: %s · Depo: %s (%s). Hazırlığı hızlandırın veya müşteriyi bilgilendirin."
                     % (e[0]["eta"], g["depo"], ", ".join(s["no"] for s in hazir_degil)), "Acente ETA + Sipariş", g["id"])
            hazir_plansiz = [s for s in g["siparisler"] if s["durum"].get(2) == "done" and s["durum"].get(3) != "done"]
            if -12 < kalan <= 48 and hazir_plansiz:
                ekle("planla-%d-%d" % (g["id"], e[0]["id"]), "Yüksek",
                     "%s – Depo hazır, gemi yaklaşıyor: sevkiyatı planlayın" % g["ad"],
                     "ETA %s · %s operasyon aşamasında." % (e[0]["eta"], ", ".join(s["no"] for s in hazir_plansiz)),
                     "Acente ETA + Sipariş", g["id"])
        if len(e) > 1:
            alinma = db_zaman_coz(e[0]["alinma"])
            fark, metin = eta_farki(e[0]["eta"], e[1]["eta"])
            if fark and alinma and (simdi - alinma).total_seconds() < 72 * 3600:
                planli = [s for s in g["siparisler"] if s["durum"].get(3) in ("prog", "done")]
                ek = " Planlanmış araç / personel saatini güncelleyin (%s)." % ", ".join(s["no"] for s in planli) if planli else ""
                ekle("etadegisti-%d" % e[0]["id"], "Yüksek", "%s – ETA değişti: %s" % (g["ad"], metin),
                     "Yeni ETA %s (önceki %s).%s" % (e[0]["eta"], e[1]["eta"], ek), "Acente ETA", g["id"])
        es = kegm_eslesme(g, kegm)
        if es:
            from st_kegm import ozet
            satir = es["satir"]
            ekle("kegm-%d-%s-%s" % (g["id"], es["bogaz"], satir.get("plan_zamani") or satir.get("seq") or ""), "Yüksek",
                 "%s – Kıyı Emniyeti boğaz geçiş listesinde" % g["ad"],
                 "%s. Açık sipariş: %s. Depo: %s. Sevkiyat zamanlamasını değerlendirin."
                 % (ozet(es), no_list, g["depo"]), "Kıyı Emniyeti (otomatik)", g["id"])
            if es["yontem"] == "ad" and satir.get("imo") and not (g.get("imo") or "").strip():
                ekle("imoneri-%d-%s" % (g["id"], satir["imo"]), "Normal", "%s – IMO bulundu: %s" % (g["ad"], satir["imo"]),
                     "Kıyı Emniyeti listesinde aynı adlı gemi var. Doğruysa gemi detayından tek tıkla ekleyin.",
                     "Kıyı Emniyeti (otomatik)", g["id"])
        elif (g.get("hareket") or "").startswith("Boğaz geçiş planında") and acik_mi(g["siparisler"][0]):
            ekle("bogaz-%d-%s" % (g["id"], g.get("bogaz") or ""), "Yüksek", "%s – Boğaz geçişine yaklaşıyor, sipariş açık" % g["ad"],
                 "%s · Açık sipariş: %s. Operasyonu değerlendirin." % (g.get("bogaz") or "Boğaz geçiş planında", no_list),
                 "Kıyı Emniyeti (elle teyit)", g["id"])
        if not (g.get("imo") or "").strip():
            ekle("imo-%d" % g["id"], "Normal", "%s – IMO numarası eksik" % g["ad"],
                 "IMO olmadan gemi otomatik eşleştirilemez. Gemi detayından IMO ekleyin.", "Sistem", g["id"])
        if not e:
            ekle("etayok-%d" % g["id"], "Bilgi", "%s – ETA belirsiz, takip ediliyor" % g["ad"],
                 "Acenteden ETA gelince gemi detayından girin. Sipariş: %s" % no_list, "Sistem", g["id"])
    for s in siparisler:
        if gecikmis_mi(s):
            ekle("gecikti-%d" % s["id"], "Normal", "%s – Termin tarihi geçti" % s["no"],
                 "Termin %s · %s · depo aşaması tamamlanmadı." % (deger(s, 1, "termin"), deger(s, 1, "gemi") or "—"),
                 "Sipariş", siparis_id=s["id"])
    sira = {"Kritik": 0, "Yüksek": 1, "Normal": 2, "Bilgi": 3}
    out.sort(key=lambda u: sira[u["oncelik"]])
    return out
