# -*- coding: utf-8 -*-
"""IMO numarasından gemi adını bulur.

Sıra: 1) Kıyı Emniyeti boğaz listeleri (anında, internet beklemez)
      2) Programdaki gemi kayıtları ve önceki sorgular (anında)
      3) VesselFinder herkese açık gemi sayfası (internet, Gemi Sefer Takibi'ndeki yöntem)
Bulunamazsa None döner; arayüz kullanıcıdan adı elle girmesini ister.
"""
import html as _html
import json
import os
import re
import threading
import time
import urllib.error
import urllib.request

ADRES = "https://www.vesselfinder.com/vessels/details/{}"
BASLIKLAR = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
                  "Chrome/130.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9,tr;q=0.8",
}
ONBELLEK = os.path.join(os.path.dirname(os.path.abspath(__file__)), "imo_onbellek.json")
_kilit = threading.Lock()


def imo_gecerli(imo):
    """IMO kontrol hanesi: ilk 6 hanenin 7,6,5,4,3,2 ile çarpımlarının toplamının son hanesi = 7. hane."""
    s = str(imo or "").strip()
    if s.upper().startswith("IMO"):
        s = s[3:].strip()
    if len(s) != 7 or not s.isdigit():
        return False
    return sum(int(s[i]) * (7 - i) for i in range(6)) % 10 == int(s[6])


def _metin(h):
    h = re.sub(r"<(script|style)[\s\S]*?</\1>", " ", h or "")
    h = re.sub(r"<[^>]+>", " ", h)
    return re.sub(r"\s+", " ", _html.unescape(h)).strip()


def _onbellek_oku():
    try:
        with open(ONBELLEK, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def _onbellek_yaz(imo, ad, kaynak):
    with _kilit:
        v = _onbellek_oku()
        v[imo] = {"ad": ad, "kaynak": kaynak, "zaman": time.time()}
        try:
            tmp = ONBELLEK + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(v, f, ensure_ascii=False)
            os.replace(tmp, ONBELLEK)
        except OSError:
            pass


def vesselfinder_ad(imo, zaman_asimi=15):
    istek = urllib.request.Request(ADRES.format(imo), headers=BASLIKLAR)
    with urllib.request.urlopen(istek, timeout=zaman_asimi) as r:
        sayfa = r.read().decode("utf-8", "replace")
    m = re.search(r'<td class="(?:tpc1|n3)"[^>]*>\s*Vessel Name\s*</td>\s*<td class="(?:tpc2|v3)[^"]*"[^>]*>(.*?)</td>', sayfa, re.S)
    ad = _metin(m.group(1)) if m else ""
    if not ad:
        m = re.search(r'<h1 class="title">(.*?)</h1>', sayfa, re.S)
        ad = _metin(m.group(1)) if m else ""
    # sayfa gerçekten bu IMO'ya mı ait?
    if imo not in sayfa:
        return ""
    return ad.upper().strip()


def yerel_ad(imo, kegm=None):
    """İnternetsiz güvenilir kaynaklar (Kıyı Emniyeti listesi, önceki sorgular): (ad, kaynak) ya da (None, None)"""
    for kod in ("I", "C"):
        for s in (kegm or {}).get(kod) or []:
            if s.get("imo") == imo and s.get("ad"):
                ad = s["ad"].upper().strip()
                k = _onbellek_oku().get(imo)
                if not k or k.get("ad") != ad:
                    _onbellek_yaz(imo, ad, "Kıyı Emniyeti")  # gemi listeden çıksa da hatırlansın
                return ad, "Kıyı Emniyeti"
    k = _onbellek_oku().get(imo)
    if k and k.get("ad"):
        return k["ad"], k.get("kaynak") or "önceki sorgu"
    return None, None


def program_kaydi_ad(imo, db):
    """Programda daha önce bu IMO ile girilmiş gemi adı (elle girilmiş olabilir; son çare)."""
    try:
        r = db.c.execute("SELECT ad FROM gemiler WHERE imo=? AND ad NOT LIKE 'IMO %' ORDER BY id LIMIT 1", (imo,)).fetchone()
        return r["ad"] if r and r["ad"] else None
    except Exception:
        return None


def gemi_adi_bul(imo, kegm=None, yedek_ad=None):
    """(ad, kaynak, hata). Ad bulunamazsa ad=None, hata açıklaması dolu olur.
    yedek_ad: internet sonuç vermezse kullanılacak program kaydındaki ad."""
    imo = str(imo or "").strip()
    if not imo_gecerli(imo):
        return None, None, "IMO numarası geçersiz (7 hane ve kontrol hanesi tutmalı)"
    ad, kaynak = yerel_ad(imo, kegm)
    if ad:
        return ad, kaynak, None
    try:
        ad = vesselfinder_ad(imo)
    except urllib.error.HTTPError as e:
        if yedek_ad:
            return yedek_ad, "program kaydı", None
        return None, None, "VesselFinder'da bulunamadı" if e.code == 404 else "VesselFinder erişimi kısıtladı (%d)" % e.code
    except Exception as e:
        if yedek_ad:
            return yedek_ad, "program kaydı", None
        return None, None, "İnternet üzerinden sorgulanamadı (%s)" % str(e)[:60]
    if ad:
        _onbellek_yaz(imo, ad, "VesselFinder")
        return ad, "VesselFinder", None
    if yedek_ad:
        return yedek_ad, "program kaydı", None
    return None, None, "Bu IMO ile gemi adı bulunamadı"
