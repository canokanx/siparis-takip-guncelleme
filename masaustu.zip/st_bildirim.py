# -*- coding: utf-8 -*-
"""Değişiklik bildirimleri: başka kullanıcıların yaptığı değişiklikler (İşlem Geçmişi'nden) ve yeni kritik uyarılar
sağ altta bildirim olarak gösterilir. Kendi yaptıklarınız bildirilmez."""
import time

import st_mantik as M

VARSAYILAN = {"acik": True, "ses": True, "yeni": True, "durum": True, "alan": True, "dosya": True, "silme": True,
              "gemi": True, "uyari": True, "bogaz_bizim": True, "bogaz": True}
TURLER = [("yeni", "Yeni sipariş açıldı"), ("durum", "Aşama başladı / tamamlandı / durum değişti"),
          ("alan", "Sipariş bilgileri değişti"), ("dosya", "Dosya / fotoğraf eklendi veya kaldırıldı"),
          ("silme", "Sipariş silindi / geri alındı / iptal"), ("gemi", "Gemi ve ETA değişiklikleri"),
          ("uyari", "Kritik uyarılar (ETA yaklaşıyor + depo hazır değil, boğaz listesi…)"),
          ("bogaz_bizim", "Boğaz listeleri: siparişli gemilerimizin her değişikliği (ayrı ayrı)"),
          ("bogaz", "Boğaz listeleri: bütün gemilerdeki değişiklikler (boğaz başına özet)")]
RENK = {"yeni": "#2E9E5B", "silme": "#D64538", "durum": "#1F5F8B", "uyari": "#E07B00", "gemi": "#3E7CB8",
        "dosya": "#6B5BB5", "alan": "#1F5F8B", "mudahale": "#55606E", "diger": "#9AA1AC"}
SESSIZ = ("hatalı şifre", "Programcı bölümüne")


def ayarlar(ana):
    d = dict(VARSAYILAN)
    d.update(ana.ayarlar.get("bildirim") or {})
    return d


def kategori(r):
    a = r.get("aciklama") or ""
    al = a.lower()
    if a.startswith("Programcı müdahalesi"):
        return "mudahale"
    if any(s.lower() in al for s in SESSIZ):
        return None
    if r.get("siparis_id") and "oluşturuldu" in al:
        return "yeni"
    if "silindi" in al or "geri alındı" in al or "iptal" in al:
        return "silme"
    if r.get("alan") == "durum" or "tamamlandı" in al or "başladı" in al or "yeniden açıldı" in al:
        return "durum"
    if al.startswith("dosya") or "dosya eklendi" in al or "dosya kaldırıldı" in al:
        return "dosya"
    if "eta" in al or (r.get("gemi_id") and not r.get("siparis_id")):
        return "gemi"
    if r.get("alan") or "malzeme" in al:
        return "alan"
    return "diger"


class BildirimIzleyici:
    """AnaPencere'nin 3 saniyelik döngüsünden çağrılır (kontrol)."""
    UYARI_ARALIK = 60

    def __init__(self, ana, kutular):
        self.ana = ana
        self.db = ana.db
        self.k = ana.k
        self.kutular = kutular
        self.duraklat = False
        self._son_uyari = 0
        self._kayit_bekliyor = False
        kid = str(self.k["id"])
        self.son_id = (ana.ayarlar.get("bildirim_son") or {}).get(kid)
        self.bildirilen = set((ana.ayarlar.get("bildirilen_uyarilar") or {}).get(kid, []))
        self._ilk_uyari = kid not in (ana.ayarlar.get("bildirilen_uyarilar") or {})
        en_son = self._en_son_id()
        if self.son_id is None or self.son_id > en_son:
            self.son_id = en_son
            self._kaydet()
        else:
            self._siz_yokken(en_son)

    # ------------------------------------------------------------------ yardımcılar
    def _en_son_id(self):
        r = self.db._taze("SELECT MAX(id) FROM denetim").fetchone()
        return int(r[0] or 0) if r else 0

    def _yeni_satirlar(self, limit=300):
        return [dict(r) for r in self.db._taze(
            "SELECT id, siparis_id, gemi_id, asama, alan, aciklama, kullanici_id FROM denetim WHERE id > ? "
            "ORDER BY id LIMIT %d" % limit, (self.son_id,))]

    def _kaydet(self):
        a = self.ana.ayarlar
        a.setdefault("bildirim_son", {})[str(self.k["id"])] = self.son_id
        a.setdefault("bildirilen_uyarilar", {})[str(self.k["id"])] = sorted(self.bildirilen)[-500:]
        try:
            self.ana.ayarlar_kaydet()
        except Exception:
            pass
        self._kayit_bekliyor = False

    def _acik_mi(self, tur=None):
        a = ayarlar(self.ana)
        if not a["acik"] or self.duraklat:
            return False
        return a.get(tur, True) if tur else True

    def _ses(self):
        return ayarlar(self.ana)["ses"]

    def _siparis_no(self, sid):
        try:
            s = self.db.siparis(sid)
            return s["no"] if s else "Sipariş #%s" % sid
        except Exception:
            return "Sipariş #%s" % sid

    def _gemi_adi(self, gid):
        try:
            g = self.db.gemi(gid)
            return g["ad"] if g else "Gemi #%s" % gid
        except Exception:
            return "Gemi #%s" % gid

    # ------------------------------------------------------------------ açılışta: siz yokken
    def _siz_yokken(self, en_son):
        if en_son <= self.son_id:
            return
        satirlar = [r for r in self._yeni_satirlar(2000) if r["kullanici_id"] != self.k["id"] and kategori(r)]
        self.son_id = en_son
        self._kaydet()
        if not satirlar or not self._acik_mi():
            return
        siparisler = []
        for r in satirlar:
            if r["siparis_id"] and r["siparis_id"] not in siparisler:
                siparisler.append(r["siparis_id"])
        nolar = ", ".join(self._siparis_no(s) for s in siparisler[:6]) + (" …" if len(siparisler) > 6 else "")
        self.kutular.goster("Siz yokken %d değişiklik yapıldı" % len(satirlar),
                            ("%d siparişte: %s" % (len(siparisler), nolar)) if siparisler else "Gemi ve diğer kayıtlarda.",
                            tiklaninca=lambda: self.ana.pencereyi_ac("gecmis" if self.k["rol"] != "kullanici" else "siparisler"),
                            renk=RENK["durum"], ses=self._ses())

    # ------------------------------------------------------------------ döngü
    def kontrol(self):
        try:
            self._degisiklikler()
        except Exception:
            pass  # bağlantı yoksa sonra tekrar
        if time.time() - self._son_uyari > self.UYARI_ARALIK:
            self._son_uyari = time.time()
            try:
                self._uyarilar()
            except Exception:
                pass

    def _degisiklikler(self):
        if self.db.bulut and getattr(self.db.c, "ayna", None) is not None:
            if self.db.c.ayna.max_denetim <= self.son_id:  # yeni kayıt yok (internete gitmeden bilinir)
                return
        satirlar = self._yeni_satirlar()
        if not satirlar:
            return
        self.son_id = max(r["id"] for r in satirlar)
        self._kaydet()
        baskalari = [r for r in satirlar if r["kullanici_id"] != self.k["id"]]
        gruplar, sira = {}, []
        for r in baskalari:
            t = kategori(r)
            if t is None or (t == "mudahale" and self.k["rol"] != "ust"):
                continue
            if not self._acik_mi(t if t in VARSAYILAN else None):
                continue
            anahtar = (("s", r["siparis_id"]) if r["siparis_id"] else ("g", r["gemi_id"])) + (r["kullanici_id"],)
            if anahtar not in gruplar:
                gruplar[anahtar] = []
                sira.append(anahtar)
            gruplar[anahtar].append((t, r))
        if not sira:
            return
        adlar = self.db.kullanici_adlari()
        gosterilecek = sira[:3]
        for anahtar in gosterilecek:
            self._grup_bildir(anahtar, gruplar[anahtar], adlar)
        if len(sira) > 3:
            kalan = sum(len(gruplar[a]) for a in sira[3:])
            self.kutular.goster("+%d değişiklik daha" % kalan, "Ayrıntılar İşlem Geçmişi'nde.",
                                tiklaninca=lambda: self.ana.pencereyi_ac("gecmis" if self.k["rol"] != "kullanici" else "siparisler"),
                                renk=RENK["diger"])

    def _grup_bildir(self, anahtar, kayitlar, adlar):
        tur_, kimlik, kid = anahtar
        kim = adlar.get(kid, "Bir kullanıcı")
        turler = [t for t, _ in kayitlar]
        ana_tur = next((t for t in ("silme", "yeni", "durum", "dosya", "gemi", "alan", "mudahale") if t in turler), "diger")
        if tur_ == "s":
            baslik = "%s · %s" % (self._siparis_no(kimlik), kim)
            son_asama = next((r["asama"] for _, r in reversed(kayitlar) if r.get("asama")), None)
            ac = (lambda s=kimlik, a=son_asama: self.ana.pencereyi_ac("siparis", siparis_id=s, **({"asama": a} if a else {})))
        else:
            baslik = "%s · %s" % (self._gemi_adi(kimlik) if kimlik else "Gemi", kim)
            ac = (lambda g=kimlik: self.ana.pencereyi_ac("gemi", gemi_id=g)) if kimlik else None
        satirlar, alanlar = [], {}
        for t, r in kayitlar:
            if t == "alan" and r.get("alan"):
                etiket = (r["aciklama"] or "").replace(" değişti", "").strip()
                alanlar.setdefault(r.get("asama"), []).append(etiket)
            else:
                if r["aciklama"] and r["aciklama"] not in satirlar:
                    satirlar.append(r["aciklama"])
        for asama, liste in alanlar.items():
            tekil = []
            for x in liste:
                if x not in tekil:
                    tekil.append(x)
            satirlar.append("%s%s güncellendi" % (("Aşama %s: " % asama) if asama else "",
                                                  ", ".join(tekil[:4]) + (" …" if len(tekil) > 4 else "")))
        metin = "\n".join("• " + x for x in satirlar[:4]) + ("\n• …" if len(satirlar) > 4 else "")
        self.kutular.goster(baslik, metin, tiklaninca=ac, renk=RENK.get(ana_tur, RENK["diger"]), ses=self._ses())

    # ------------------------------------------------------------------ boğaz listeleri (Kıyı Emniyeti)
    def bogaz(self, degisiklikler):
        """Kıyı Emniyeti listesi yenilendi: siparişli gemilerimizin her değişikliği ayrı bildirim; bütün gemilerdeki
        değişiklikler boğaz başına tek özet bildirim (tıklayınca 'Son değişiklikler' listesi açılır)."""
        if not degisiklikler or not self._acik_mi():
            return
        from st_kegm import BOGAZLAR, fark_metni, _ad_anahtar
        gem = M.takip_gemileri(self.db)
        imo_gemi = {(g.get("imo") or "").strip(): g for g in gem if (g.get("imo") or "").strip()}
        ad_gemi = {_ad_anahtar(g["ad"]): g for g in gem if not (g.get("imo") or "").strip()}
        bizim, digerleri = [], {}
        for f in degisiklikler:
            g = imo_gemi.get(f.get("imo") or "") if f.get("imo") else ad_gemi.get(_ad_anahtar(f.get("ad")))
            if g is not None:
                bizim.append((g, f))
            else:
                digerleri.setdefault(f["bogaz"], []).append(f)
        if self._acik_mi("bogaz_bizim"):
            for g, f in bizim[:4]:
                self.kutular.goster("⚓ %s Boğazı · %s" % (BOGAZLAR[f["bogaz"]], g["ad"]),
                                    "Siparişli gemimiz: " + fark_metni(f),
                                    tiklaninca=(lambda gid=g.get("id"): self.ana.pencereyi_ac("gemi", gemi_id=gid)),
                                    renk="#D64538" if f["tur"] in ("eklendi", "durum") else RENK["gemi"], ses=self._ses())
            if len(bizim) > 4:
                self.kutular.goster("⚓ Siparişli gemilerde %d değişiklik daha" % (len(bizim) - 4), "Boğaz Listeleri → Son değişiklikler",
                                    tiklaninca=lambda: self.ana.pencereyi_ac("bogaz", bogaz="D"), renk=RENK["gemi"])
        if self._acik_mi("bogaz"):
            for kod, liste in digerleri.items():
                sayac = {}
                for f in liste:
                    sayac[f["tur"]] = sayac.get(f["tur"], 0) + 1
                adlar = {"eklendi": "listeye girdi", "cikti": "listeden çıktı", "durum": "durum değişti",
                         "plan": "plan zamanı değişti", "yon": "yön değişti"}
                ozet = " · ".join("%d %s" % (n, adlar.get(t, t)) for t, n in sayac.items())
                satirlar = ["• %s – %s" % (f.get("ad") or "?", fark_metni(f)) for f in liste[:5]]
                if len(liste) > 5:
                    satirlar.append("… ve %d değişiklik daha" % (len(liste) - 5))
                self.kutular.goster("%s Boğazı listesi: %d değişiklik" % (BOGAZLAR[kod], len(liste)),
                                    ozet + "\n" + "\n".join(satirlar),
                                    tiklaninca=lambda: self.ana.pencereyi_ac("bogaz", bogaz="D"), renk=RENK["diger"],
                                    ses=False)

    def _uyarilar(self):
        if not self._acik_mi("uyari") and not self._ilk_uyari:
            return
        okunan = self.db.okunanlar(self.k["id"])
        liste = [u for u in M.uyarilar(self.db, self.k, kegm=self.ana.kegm.veri)
                 if u["oncelik"] in ("Kritik", "Yüksek") and u["anahtar"] not in okunan]
        yeni = [u for u in liste if u["anahtar"] not in self.bildirilen]
        for u in yeni:
            self.bildirilen.add(u["anahtar"])
        if yeni:
            self._kaydet()
        if self._ilk_uyari:  # ilk çalışmada var olan uyarılar bildirilmez (Ana Panel'de zaten görünür)
            self._ilk_uyari = False
            return
        if not self._acik_mi("uyari"):
            return
        for u in yeni[:3]:
            hedef = (lambda s=u.get("siparis_id"): self.ana.pencereyi_ac("siparis", siparis_id=s)) if u.get("siparis_id") else \
                (lambda g=u.get("gemi_id"): self.ana.pencereyi_ac("gemi", gemi_id=g)) if u.get("gemi_id") else \
                (lambda: self.ana.pencereyi_ac("ana"))
            self.kutular.goster("%s · %s" % (u["oncelik"], u["baslik"]), u["metin"], tiklaninca=hedef,
                                renk="#D64538" if u["oncelik"] == "Kritik" else RENK["uyari"], ses=self._ses())
        if len(yeni) > 3:
            self.kutular.goster("+%d yeni uyarı" % (len(yeni) - 3), "Ana Panel'de.",
                                tiklaninca=lambda: self.ana.pencereyi_ac("ana"), renk=RENK["uyari"])


# ====================================================================== Ayarlar → Genel kartı
def ayarlar_karti(ana, ic):
    import sys
    import tkinter as tk
    from tkinter import ttk, messagebox
    from st_ortak import kart, lbl
    from st_tanim import KART, SOLUK
    import st_arka_plan as AP
    k = kart(ic)
    k.pack(fill="x", pady=(14, 0))
    lbl(k, "Arka planda çalışma ve bildirimler", boy=12, kalin=True).pack(anchor="w", padx=18, pady=(14, 2))
    lbl(k, "Pencere kapatılınca program saatin yanındaki simgede çalışmaya devam eder; başkalarının yaptığı değişiklikler "
           "sağ altta bildirim olarak gelir. Kendi yaptıklarınız bildirilmez.", fg=SOLUK, wraplength=900).pack(
        anchor="w", padx=18, pady=(0, 8))
    g = tk.Frame(k, bg=KART)
    g.pack(fill="x", padx=18, pady=(0, 14))
    a = ayarlar(ana)

    def kaydet_bildirim():
        ana.ayarlar["bildirim"] = {x: v.get() for x, v in vars_.items()}
        ana.ayarlar_kaydet()

    v_arka = tk.BooleanVar(value=ana.ayarlar.get("arka_planda_calis", True))

    def arka_degisti():
        ana.ayarlar["arka_planda_calis"] = v_arka.get()
        ana.ayarlar_kaydet()
        messagebox.showinfo("Arka planda çalışma", "Değişiklik program yeniden başlatılınca geçerli olur.")
    ttk.Checkbutton(g, text="Pencere kapatılınca arka planda çalışmaya devam et (saatin yanındaki simge)",
                    variable=v_arka, command=arka_degisti).pack(anchor="w")
    if sys.platform.startswith("win"):
        v_bas = tk.BooleanVar(value=AP.baslangicta_mi())

        def bas_degisti():
            ok, m = AP.baslangica_ekle(v_bas.get())
            ana.ayarlar["baslangic_ayarlandi"] = True
            ana.ayarlar_kaydet()
            if not ok:
                v_bas.set(not v_bas.get())
                messagebox.showwarning("Windows açılışı", "Ayarlanamadı: %s" % m)
        ttk.Checkbutton(g, text="Windows açılınca otomatik başlat (pencere açılmadan, arka planda)",
                        variable=v_bas, command=bas_degisti).pack(anchor="w", pady=(2, 0))
    vars_ = {x: tk.BooleanVar(value=a[x]) for x in VARSAYILAN}
    tk.Frame(g, bg=KART, height=8).pack()
    ttk.Checkbutton(g, text="Bildirimleri göster", variable=vars_["acik"], command=kaydet_bildirim).pack(anchor="w")
    ttk.Checkbutton(g, text="Bildirim sesi", variable=vars_["ses"], command=kaydet_bildirim).pack(anchor="w")
    lbl(g, "Hangi değişiklikler bildirilsin:", fg="#33404D", kalin=True, boy=9).pack(anchor="w", pady=(8, 2))
    tf = tk.Frame(g, bg=KART)
    tf.pack(anchor="w", padx=(16, 0))
    for i, (x, ad) in enumerate(TURLER):
        ttk.Checkbutton(tf, text=ad, variable=vars_[x], command=kaydet_bildirim).grid(row=i // 2, column=i % 2, sticky="w",
                                                                                    padx=(0, 24), pady=1)

    def dene():
        ana.uygulama.kutular.goster("Deneme bildirimi", "SP-2026-0001 · Aşama 2: Paketleme tarihi, KAP adedi güncellendi",
                                    tiklaninca=lambda: ana.pencereyi_ac("siparisler"), ses=vars_["ses"].get()) \
            if getattr(ana, "uygulama", None) else None
    ttk.Button(g, text="Deneme bildirimi göster", command=dene).pack(anchor="w", pady=(10, 0))
