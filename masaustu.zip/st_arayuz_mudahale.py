# -*- coding: utf-8 -*-
"""Ayarlar → 'Programa müdahale' sekmesi (programcı şifresiyle açılır).
İşlem geçmişi silme, silinen siparişleri kalıcı silme, ek / gemi temizliği, sipariş düzeltme, onarım ve bakım."""
import os
import tkinter as tk
from tkinter import ttk, messagebox

import st_mudahale as MD
from st_tanim import ZEMIN, KART, SOLUK, YAZI, DURUM, ASAMALAR, tr_upper
from st_ortak import kart, lbl, bant, font, tarih_alani, ortala

PROGRAM_KLASORU = os.path.dirname(os.path.abspath(__file__))
KIRMIZI, YESIL, TURUNCU = "#9E2A21", "#17603A", "#8A4300"


# ====================================================================== ortak
def onay_sil(ana, baslik, metin):
    """Silme onayı: kullanıcı 'SİL' yazmadan işlem yapılmaz."""
    p = tk.Toplevel(ana)
    p.title(baslik)
    p.configure(bg=KART)
    p.transient(ana.root)
    p.resizable(False, False)
    sonuc = {"v": False}
    lbl(p, "⚠  " + baslik, boy=13, kalin=True, fg=KIRMIZI).pack(anchor="w", padx=22, pady=(18, 6))
    lbl(p, metin, fg="#33404D", wraplength=460).pack(anchor="w", padx=22)
    lbl(p, "İşlemden önce verilerin tamamı bu bilgisayara yedeklenir. Onaylamak için kutuya SİL yazın:",
        fg=SOLUK, boy=9, wraplength=460).pack(anchor="w", padx=22, pady=(12, 4))
    v = tk.StringVar()
    e = ttk.Entry(p, textvariable=v, width=12, font=font(12, True))
    e.pack(anchor="w", padx=22)
    dz = tk.Frame(p, bg=KART)
    dz.pack(fill="x", padx=22, pady=16)
    b = ttk.Button(dz, text="Kalıcı olarak sil", style="Tehlike.TButton")
    b.pack(side="right")
    b.state(["disabled"])

    def degisti(*_):
        b.state(["!disabled"] if tr_upper(v.get().strip()) in ("SİL", "SIL") else ["disabled"])
    v.trace_add("write", degisti)

    def sec(x):
        sonuc["v"] = x
        p.destroy()
    b.configure(command=lambda: sec(True))
    ttk.Button(dz, text="Vazgeç", command=lambda: sec(False)).pack(side="right", padx=(0, 8))
    p.bind("<Escape>", lambda e_: sec(False))
    p.protocol("WM_DELETE_WINDOW", lambda: sec(False))
    ortala(p, ana.root)
    e.focus_set()
    p.grab_set()
    p.wait_window()
    return sonuc["v"]


def _calistir(ana, ad, is_, silme=True, yedek=True, yenile=True):
    """Yetki kontrolü → (silmeyse) yedek → iş → sonuç mesajı → ekranı yenile."""
    db = ana.db
    if silme:
        ok, neden = MD.silme_yetkisi(db)
        if not ok:
            messagebox.showwarning(ad, neden)
            return None
    ana.root.configure(cursor="watch")
    ana.root.update()
    try:
        if yedek:
            ana.bildir("Müdahale öncesi yedek alınıyor…")
            ana.root.update()
            yol = MD.oncesi_yedek(db, ad)
            ana.bildir("Yedek alındı: %s" % os.path.basename(yol))
        sonuc = is_()
    except Exception as e:
        import traceback
        traceback.print_exc()
        ana.root.configure(cursor="")
        messagebox.showerror(ad, "İşlem yapılamadı:\n%s" % e)
        return None
    ana.root.configure(cursor="")
    if yenile:
        ana.goster("ayarlar", sekme="mudahale")
    return sonuc


def _kart(ic, baslik, aciklama=None):
    k = kart(ic)
    k.pack(fill="x", pady=(0, 14))
    lbl(k, baslik, boy=13, kalin=True).pack(anchor="w", padx=18, pady=(14, 2))
    if aciklama:
        lbl(k, aciklama, fg=SOLUK, wraplength=980).pack(anchor="w", padx=18, pady=(0, 8))
    g = tk.Frame(k, bg=KART)
    g.pack(fill="x", padx=18, pady=(0, 14))
    return g


def _liste(ust, yukseklik=6, genislik=70):
    f = tk.Frame(ust, bg=KART)
    lb = tk.Listbox(f, selectmode="extended", height=yukseklik, width=genislik, font=font(10), activestyle="none",
                    relief="solid", bd=1, exportselection=False)
    sb = ttk.Scrollbar(f, orient="vertical", command=lb.yview)
    lb.configure(yscrollcommand=sb.set)
    lb.pack(side="left", fill="both", expand=True)
    sb.pack(side="left", fill="y")
    return f, lb


def _mb(n):
    return "%.1f MB" % (n / 1048576.0)


# ====================================================================== sekme
def mudahale_bolumu(ana, ic):
    db = ana.db
    ust_ = tk.Frame(ic, bg=ZEMIN)
    ust_.pack(fill="x", pady=(0, 8))
    ttk.Button(ust_, text="🔒 Kilitle", command=lambda: (setattr(ana, "_programci_acik", False),
                                                       ana.goster("ayarlar", sekme="mudahale"))).pack(side="right")
    bant(ic, "Bu bölümde yapılan silme işlemleri GERİ ALINAMAZ. Her silmeden önce verilerin tamamı bu bilgisayara "
             "otomatik yedeklenir (veri\\_mudahale_yedekleri, son 10 yedek) ve yapılan her müdahale İşlem Geçmişi'ne yazılır.",
         "uyari").pack(fill="x", pady=(0, 12))
    yetkili, neden = MD.silme_yetkisi(db)
    if not yetkili:
        bant(ic, "🔒  " + neden, "kilit").pack(fill="x", pady=(0, 12))

    _durum_karti(ana, ic)
    _gecmis_karti(ana, ic)
    _silinen_siparis_karti(ana, ic)
    _ek_karti(ana, ic)
    _gemi_karti(ana, ic)
    _siparis_duzelt_karti(ana, ic)
    _bakim_karti(ana, ic)
    _bekleyen_karti(ana, ic)
    _hata_karti(ana, ic)


# ---------------------------------------------------------------------- 1 durum
def _durum_karti(ana, ic):
    g = _kart(ic, "1 · Veritabanı durumu")
    try:
        d = MD.durum_ozeti(ana.db)
    except Exception as e:
        lbl(g, "Okunamadı (bağlantı yok?): %s" % e, fg=KIRMIZI).pack(anchor="w")
        return
    iz = tk.Frame(g, bg=KART)
    iz.pack(fill="x")
    for i, (ad, n) in enumerate(d["tablolar"]):
        c = tk.Frame(iz, bg="#F5F7F9", padx=12, pady=6)
        c.grid(row=i // 5, column=i % 5, sticky="ew", padx=(0, 8), pady=(0, 8))
        iz.columnconfigure(i % 5, weight=1, uniform="d")
        lbl(c, ad, bg="#F5F7F9", fg=SOLUK, boy=9).pack(anchor="w")
        lbl(c, "{:,}".format(n).replace(",", "."), bg="#F5F7F9", boy=14, kalin=True).pack(anchor="w")
    alt = "Veritabanı: %s · ek dosyalar: %s" % (_mb(d["boyut"]), _mb(d["ek_boyut"]))
    if d.get("sinir"):
        oran = d["boyut"] / float(d["sinir"])
        alt += " · Supabase ücretsiz sınırın %%%d'i kullanılıyor (500 MB)" % round(oran * 100)
        renk = KIRMIZI if oran > 0.8 else (TURUNCU if oran > 0.6 else YESIL)
    else:
        renk = "#33404D"
    lbl(g, alt, fg=renk, kalin=True).pack(anchor="w", pady=(4, 0))
    lbl(g, "Temizlenebilir: %d silinmiş sipariş · %d kaldırılmış ek dosyası · %d siparişsiz gemi" % (
        d["silinen_siparis"], d["kaldirilan_ek"], d["sahipsiz_gemi"]), fg=SOLUK).pack(anchor="w")
    kl, yedekler = MD.mudahale_yedekleri(ana.db)
    sat = tk.Frame(g, bg=KART)
    sat.pack(fill="x", pady=(6, 0))
    lbl(sat, "Müdahale öncesi yedekler: %d dosya%s" % (len(yedekler), (" · son: %s" % os.path.basename(yedekler[0]))
                                                       if yedekler else ""), fg=SOLUK, boy=9).pack(side="left")
    if yedekler:
        import st_arayuz
        ttk.Button(sat, text="Yedek klasörünü aç", command=lambda: st_arayuz.dosya_ac(kl)).pack(side="left", padx=8)


# ---------------------------------------------------------------------- 2 işlem geçmişi
def _gecmis_karti(ana, ic):
    db = ana.db
    g = _kart(ic, "2 · İşlem geçmişini sil",
              "İşlem Geçmişi kayıtları (kim neyi ne zaman değiştirdi) silinir. Sipariş ve gemi bilgileri etkilenmez; "
              "yalnızca değişiklik kayıtları gider.")
    tur = tk.StringVar(value="once")
    v_tarih = tk.StringVar()
    v_no = tk.StringVar()
    s1 = tk.Frame(g, bg=KART)
    s1.pack(fill="x", pady=2)
    ttk.Radiobutton(s1, text="Şu tarihten ESKİ kayıtlar:", variable=tur, value="once").pack(side="left")
    cer, _ = tarih_alani(s1, v_tarih, "tarih", genislik=12)
    cer.pack(side="left", padx=8)
    s2 = tk.Frame(g, bg=KART)
    s2.pack(fill="x", pady=2)
    ttk.Radiobutton(s2, text="Bir siparişin bütün geçmişi · sipariş no:", variable=tur, value="siparis").pack(side="left")
    ttk.Entry(s2, textvariable=v_no, width=18).pack(side="left", padx=8)
    s3 = tk.Frame(g, bg=KART)
    s3.pack(fill="x", pady=2)
    ttk.Radiobutton(s3, text="BÜTÜN işlem geçmişi", variable=tur, value="tumu").pack(side="left")
    sonuc = lbl(g, "", fg=SOLUK)

    def kosul():
        import st_mantik as M
        t = tur.get()
        if t == "once":
            tarih = M.tarih_coz(v_tarih.get())
            if not tarih:
                messagebox.showwarning("Tarih", "Tarihi gg.aa.yyyy biçiminde yazın ya da takvimden seçin.")
                return None
            return dict(tur=t, tarih=tarih), "%s tarihinden eski" % tarih.strftime("%d.%m.%Y")
        if t == "siparis":
            s = MD.siparis_bul(db, v_no.get())
            if not s:
                messagebox.showwarning("Sipariş", "'%s' numaralı sipariş bulunamadı." % v_no.get())
                return None
            return dict(tur=t, siparis_id=s["id"]), "%s siparişinin" % s["no"]
        return dict(tur=t), "bütün"

    def say():
        k = kosul()
        if not k:
            return
        n = MD.gecmis_say(db, **k[0])
        sonuc.configure(text="%s %d işlem geçmişi kaydı var." % (k[1].capitalize(), n), fg="#33404D")

    def sil():
        k = kosul()
        if not k:
            return
        n = MD.gecmis_say(db, **k[0])
        if not n:
            messagebox.showinfo("İşlem geçmişi", "Silinecek kayıt yok.")
            return
        if not onay_sil(ana, "İşlem geçmişi silinecek", "%s %d işlem geçmişi kaydı kalıcı olarak silinecek." % (
                k[1].capitalize(), n)):
            return
        r = _calistir(ana, "Geçmiş silme", lambda: MD.gecmis_sil(db, ana.k, aciklama=k[1], **k[0]))
        if r is not None:
            ana.bildir("%d işlem geçmişi kaydı silindi." % r)
    dz = tk.Frame(g, bg=KART)
    dz.pack(fill="x", pady=(8, 0))
    ttk.Button(dz, text="Kaç kayıt var?", command=say).pack(side="left")
    ttk.Button(dz, text="Seçilen geçmişi sil", style="Tehlike.TButton", command=sil).pack(side="left", padx=8)
    sonuc.pack(anchor="w", pady=(6, 0))


# ---------------------------------------------------------------------- 3 silinen siparişler
def _silinen_siparis_karti(ana, ic):
    db = ana.db
    g = _kart(ic, "3 · Silinen siparişleri kalıcı olarak sil",
              "Siparişler ekranında 'Silinenler'de duran siparişler; aşama bilgileri, malzeme satırları, ek dosyaları ve "
              "işlem geçmişiyle birlikte tamamen silinir. Bundan sonra 'Geri al' yapılamaz.")
    liste = MD.silinen_siparisler(db)
    if not liste:
        lbl(g, "Silinmiş sipariş yok.", fg=SOLUK).pack(anchor="w")
        return
    f, lb = _liste(g, min(8, max(3, len(liste))))
    f.pack(fill="x")
    for s in liste:
        lb.insert("end", "%s   ·   silinme: %s   ·   neden: %s" % (s["no"], (s.get("silinme") or "")[:16],
                                                                    s.get("silme_nedeni") or "—"))

    def sil(hepsi):
        secili = liste if hepsi else [liste[i] for i in lb.curselection()]
        if not secili:
            messagebox.showinfo("Seçim", "Listeden sipariş seçin (Ctrl ile birden çok).")
            return
        if not onay_sil(ana, "Siparişler kalıcı silinecek", "%d sipariş tüm bilgileriyle kalıcı olarak silinecek:\n%s" % (
                len(secili), ", ".join(s["no"] for s in secili)[:500])):
            return
        r = _calistir(ana, "Silinen siparis", lambda: MD.siparis_kalici_sil(db, ana.k, [s["id"] for s in secili]))
        if r is not None:
            ana.bildir("%d sipariş kalıcı olarak silindi." % r)
    dz = tk.Frame(g, bg=KART)
    dz.pack(fill="x", pady=(8, 0))
    ttk.Button(dz, text="Seçilenleri kalıcı sil", style="Tehlike.TButton", command=lambda: sil(False)).pack(side="left")
    ttk.Button(dz, text="Hepsini kalıcı sil (%d)" % len(liste), command=lambda: sil(True)).pack(side="left", padx=8)


# ---------------------------------------------------------------------- 4 ek dosyalar
def _ek_karti(ana, ic):
    db = ana.db
    g = _kart(ic, "4 · Kaldırılmış ek dosyalarını temizle",
              "Siparişlerde '✕' ile kaldırılan ek dosyalar silinmez, gizlenir. Burada dosyaları kalıcı silip yer açarsınız.")
    n = MD._say(db, "SELECT COUNT(*) FROM ekler WHERE silindi=1")
    lbl(g, "Kaldırılmış ek dosyası: %d" % n, fg="#33404D").pack(anchor="w")
    if not n:
        return

    def temizle():
        if not onay_sil(ana, "Ek dosyaları silinecek", "%d kaldırılmış ek dosyası kalıcı olarak silinecek." % n):
            return
        r = _calistir(ana, "Ek temizligi", lambda: MD.kaldirilan_ekleri_temizle(db, ana.k))
        if r is not None:
            ana.bildir("%d ek dosyası silindi, %s yer açıldı." % (r[0], _mb(r[1])))
    ttk.Button(g, text="Kaldırılmış ekleri kalıcı sil", style="Tehlike.TButton", command=temizle).pack(anchor="w", pady=(8, 0))


# ---------------------------------------------------------------------- 5 gemiler
def _gemi_karti(ana, ic):
    db = ana.db
    g = _kart(ic, "5 · Gemi kayıtları",
              "Siparişi kalmamış gemi kayıtlarını silin ya da aynı geminin iki ayrı kaydını birleştirin.")
    sahipsiz = MD.sahipsiz_gemiler(db)
    lbl(g, "Siparişi olmayan gemiler (%d)" % len(sahipsiz), kalin=True).pack(anchor="w")
    if sahipsiz:
        f, lb = _liste(g, min(6, max(3, len(sahipsiz))), 50)
        f.pack(anchor="w", fill="x")
        for x in sahipsiz:
            lb.insert("end", "%s%s" % (x["ad"], ("   ·   IMO " + x["imo"]) if x.get("imo") else ""))

        def sil(hepsi):
            secili = sahipsiz if hepsi else [sahipsiz[i] for i in lb.curselection()]
            if not secili:
                messagebox.showinfo("Seçim", "Listeden gemi seçin.")
                return
            if not onay_sil(ana, "Gemi kayıtları silinecek", "%d gemi kaydı (ETA geçmişiyle) silinecek:\n%s" % (
                    len(secili), ", ".join(x["ad"] for x in secili)[:500])):
                return
            r = _calistir(ana, "Gemi silme", lambda: MD.gemileri_sil(db, ana.k, [x["id"] for x in secili]))
            if r is not None:
                ana.bildir("%d gemi kaydı silindi." % r)
        dz = tk.Frame(g, bg=KART)
        dz.pack(fill="x", pady=(6, 10))
        ttk.Button(dz, text="Seçilen gemileri sil", style="Tehlike.TButton", command=lambda: sil(False)).pack(side="left")
        ttk.Button(dz, text="Hepsini sil (%d)" % len(sahipsiz), command=lambda: sil(True)).pack(side="left", padx=8)
    else:
        lbl(g, "Yok.", fg=SOLUK).pack(anchor="w", pady=(0, 10))

    gemiler = db.gemiler()
    if len(gemiler) < 2:
        return
    lbl(g, "İki gemi kaydını birleştir", kalin=True).pack(anchor="w")
    adlar = ["%s%s  [#%d]" % (x["ad"], (" · IMO " + x["imo"]) if x.get("imo") else "", x["id"]) for x in gemiler]
    sat = tk.Frame(g, bg=KART)
    sat.pack(anchor="w", pady=4)
    v_k, v_h = tk.StringVar(), tk.StringVar()
    lbl(sat, "Bu kayıt:").pack(side="left")
    ttk.Combobox(sat, textvariable=v_k, values=adlar, state="readonly", width=36).pack(side="left", padx=6)
    lbl(sat, "→ şuna katılsın:").pack(side="left")
    ttk.Combobox(sat, textvariable=v_h, values=adlar, state="readonly", width=36).pack(side="left", padx=6)

    def birlestir():
        if not v_k.get() or not v_h.get():
            messagebox.showinfo("Seçim", "İki gemi seçin.")
            return
        k, h = gemiler[adlar.index(v_k.get())], gemiler[adlar.index(v_h.get())]
        if k["id"] == h["id"]:
            messagebox.showwarning("Seçim", "Aynı gemi seçildi.")
            return
        if not onay_sil(ana, "Gemiler birleştirilecek", "'%s' kaydının siparişleri, ETA'ları ve geçmişi '%s' kaydına "
                                                         "aktarılacak; '%s' kaydı silinecek." % (k["ad"], h["ad"], k["ad"])):
            return
        if _calistir(ana, "Gemi birlestirme", lambda: (MD.gemi_birlestir(db, ana.k, k["id"], h["id"]), True)[1]):
            ana.bildir("Gemi kayıtları birleştirildi.")
    ttk.Button(sat, text="Birleştir", command=birlestir).pack(side="left", padx=6)


# ---------------------------------------------------------------------- 6 sipariş düzeltme
def _siparis_duzelt_karti(ana, ic):
    db = ana.db
    g = _kart(ic, "6 · Sipariş düzeltme",
              "Kurallara takılmadan doğrudan düzeltme: aşama durumlarını değiştirme, sipariş numarasını düzeltme, iptali kaldırma.")
    sat = tk.Frame(g, bg=KART)
    sat.pack(anchor="w")
    v_no = tk.StringVar(value=getattr(ana, "_mudahale_no", ""))
    lbl(sat, "Sipariş no:").pack(side="left")
    e = ttk.Entry(sat, textvariable=v_no, width=20)
    e.pack(side="left", padx=6)
    alan = tk.Frame(g, bg=KART)
    alan.pack(fill="x", pady=(8, 0))

    def bul(_e=None):
        for w in alan.winfo_children():
            w.destroy()
        s = MD.siparis_bul(db, v_no.get())
        if not s:
            lbl(alan, "Sipariş bulunamadı.", fg=KIRMIZI).pack(anchor="w")
            return
        ana._mudahale_no = s["no"]
        durum = db.durumlar(s["id"])
        lbl(alan, "%s%s%s" % (s["no"], "  ·  SİLİNMİŞ" if s.get("silindi") else "", "  ·  İPTAL EDİLMİŞ" if s.get("iptal") else ""),
            kalin=True).pack(anchor="w")
        iz = tk.Frame(alan, bg=KART)
        iz.pack(anchor="w", pady=6)
        ters = {v: k for k, v in DURUM.items()}
        vars_ = {}
        for i, a in enumerate(ASAMALAR):
            n = a["n"]
            lbl(iz, "%d. %s" % (n, a["kisa"]), boy=9, kalin=True).grid(row=0, column=i, sticky="w", padx=(0, 10))
            v = tk.StringVar(value=DURUM.get(durum.get(n, "todo"), "Başlanmadı"))
            ttk.Combobox(iz, textvariable=v, values=list(DURUM.values()), state="readonly", width=14).grid(
                row=1, column=i, sticky="w", padx=(0, 10), pady=(3, 0))
            vars_[n] = v

        def durumlari_kaydet():
            yeni = {n: ters[v.get()] for n, v in vars_.items()}
            if not messagebox.askyesno("Aşama durumları", "Aşama durumları kurallara bakılmadan yazılsın mı?"):
                return
            r = _calistir(ana, "Asama durumu", lambda: MD.asama_durumlarini_yaz(db, ana.k, s["id"], yeni), silme=False,
                          yedek=False)
            if r is not None:
                ana.bildir("%s: %d aşamanın durumu değişti." % (s["no"], len(r)))
        dz = tk.Frame(alan, bg=KART)
        dz.pack(anchor="w", pady=(4, 8))
        ttk.Button(dz, text="Aşama durumlarını kaydet", style="Vurgu.TButton", command=durumlari_kaydet).pack(side="left")
        if s.get("iptal"):
            ttk.Button(dz, text="İptali kaldır", command=lambda: (
                _calistir(ana, "Iptal kaldir", lambda: MD.iptali_kaldir(db, ana.k, s["id"]), silme=False, yedek=False),
                ana.bildir("%s: iptal kaldırıldı." % s["no"]))).pack(side="left", padx=8)
        nf = tk.Frame(alan, bg=KART)
        nf.pack(anchor="w")
        v_yeni = tk.StringVar(value=s["no"])
        lbl(nf, "Yeni sipariş numarası:").pack(side="left")
        ttk.Entry(nf, textvariable=v_yeni, width=20).pack(side="left", padx=6)

        def no_degistir():
            if v_yeni.get().strip().upper() == s["no"]:
                return
            if not messagebox.askyesno("Sipariş numarası", "%s numarası %s olarak değiştirilsin mi?" % (s["no"], v_yeni.get().strip().upper())):
                return
            ana._mudahale_no = v_yeni.get().strip().upper()
            _calistir(ana, "No degistir", lambda: MD.siparis_no_degistir(db, ana.k, s["id"], v_yeni.get()), silme=False,
                      yedek=False)
        ttk.Button(nf, text="Numarayı değiştir", command=no_degistir).pack(side="left")
        lbl(alan, "Siparişi açmak için:", fg=SOLUK, boy=9).pack(anchor="w", pady=(8, 0))
        ttk.Button(alan, text="Sipariş ekranına git", command=lambda: ana.goster("siparis", siparis_id=s["id"])).pack(anchor="w")
    ttk.Button(sat, text="Bul", command=bul).pack(side="left")
    e.bind("<Return>", bul)
    if v_no.get():
        bul()


# ---------------------------------------------------------------------- 7 bakım
def _bakim_karti(ana, ic):
    db = ana.db
    g = _kart(ic, "7 · Bakım ve onarım")

    def satir(baslik, aciklama, metin, komut, stil="TButton"):
        f = tk.Frame(g, bg=KART)
        f.pack(fill="x", pady=4)
        ttk.Button(f, text=metin, command=komut, style=stil, width=34).pack(side="left")
        sag = tk.Frame(f, bg=KART)
        sag.pack(side="left", padx=12, fill="x", expand=True)
        lbl(sag, baslik, kalin=True, boy=10).pack(anchor="w")
        lbl(sag, aciklama, fg=SOLUK, boy=9, wraplength=760).pack(anchor="w")

    def gemi_onar():
        r = _calistir(ana, "Gemi onarim", lambda: MD.gemi_baglarini_onar(db, ana.k, ana.kegm.veri), silme=False, yedek=False)
        if r:
            messagebox.showinfo("Gemi bağları", "Siparişler gemilere yeniden bağlandı.\nGemi kaydı: %d → %d" % r)

    def asama_onar():
        r = _calistir(ana, "Asama onarim", lambda: MD.eksik_asamalari_onar(db, ana.k), silme=False, yedek=False)
        if r is not None:
            messagebox.showinfo("Aşama kayıtları", "%d eksik aşama kaydı eklendi." % r if r else "Eksik kayıt yok.")

    def okundu():
        if not messagebox.askyesno("Okundu işaretleri", "Bütün kullanıcıların 'okundu' işaretleri silinsin mi?\n"
                                                        "Ana Panel uyarıları herkese yeniden okunmamış görünür."):
            return
        r = _calistir(ana, "Okundu temizle", lambda: MD.okundu_temizle(db, ana.k), yedek=False)
        if r is not None:
            ana.bildir("%d okundu işareti temizlendi." % r)

    def sikistir():
        r = _calistir(ana, "Sikistir", lambda: (MD.sikistir(db), True)[1], silme=False, yedek=False)
        if r:
            messagebox.showinfo("Veritabanı", "Veritabanı sıkıştırıldı.")

    def herkes_yeniden():
        from st_bulut import veri_nesli_yenile
        if messagebox.askyesno("Verileri yeniden yükle", "Bütün bilgisayarlar sipariş verilerini buluttan baştan "
                                                          "indirsin mi? (Bir bilgisayarda liste tutarsız görünürse)"):
            _calistir(ana, "Nesil", lambda: veri_nesli_yenile(db.c), silme=False, yedek=False)
            ana.bildir("Bütün bilgisayarlar verileri birkaç saniye içinde baştan yükleyecek.")

    def onbellek():
        if not messagebox.askyesno("Önbellek", "Bu bilgisayardaki önbellek dosyaları silinip program yeniden başlatılsın mı?\n"
                                                "(Veriler silinmez; açılışta buluttan yeniden iner.)"):
            return
        n = MD.yerel_onbellegi_temizle(db, PROGRAM_KLASORU)
        ana.bildir("%d önbellek dosyası silindi." % n)
        ana._kaydet_cb = None
        ana._kapandi = True
        try:
            db.kapat()
        except Exception:
            pass
        from st_programci import yeniden_baslat
        yeniden_baslat()
        ana.root.destroy()

    def kilitler():
        import sys
        ana_mod = sys.modules.get("__main__")
        kil = getattr(ana_mod, "GIRIS_KILIDI", None)
        n = len(kil) if kil else 0
        if kil:
            kil.clear()
        messagebox.showinfo("Giriş kilitleri", "%d kullanıcı adının hatalı giriş kilidi kaldırıldı (bu bilgisayarda)." % n)

    satir("Gemi bağlarını onar", "Siparişlerdeki gemi adı / IMO'ya göre gemi kayıtlarını yeniden bağlar, aynı IMO'lu "
          "kopyaları birleştirir.", "Gemi bağlarını onar", gemi_onar)
    satir("Eksik aşama kayıtlarını onar", "Aşama durumu eksik olan siparişlere eksik aşamaları ekler.",
          "Aşama kayıtlarını onar", asama_onar)
    satir("Okundu işaretlerini temizle", "Ana Panel uyarılarının okunma bilgisini herkes için sıfırlar.",
          "Okundu işaretlerini temizle", okundu)
    satir("Veritabanını sıkıştır", "Silme işlemlerinden sonra boşalan yeri geri kazanır.", "Veritabanını sıkıştır", sikistir)
    if db.bulut:
        satir("Bütün bilgisayarlarda verileri yeniden yükle", "Her bilgisayar sipariş kopyasını buluttan baştan indirir.",
              "Herkeste yeniden yükle", herkes_yeniden)
    satir("Bu bilgisayarın önbelleğini temizle", "Sipariş kopyası, ek dosya önbelleği, IMO ve Kıyı Emniyeti önbelleği silinir; "
          "program yeniden açılır.", "Önbelleği temizle ve yeniden başlat", onbellek)
    satir("Giriş kilitlerini kaldır", "5 kez hatalı şifre girildiği için bekletilen kullanıcı adlarını hemen açar.",
          "Giriş kilitlerini kaldır", kilitler)


# ---------------------------------------------------------------------- 8 bekleyen kayıtlar
def _bekleyen_karti(ana, ic):
    g = _kart(ic, "8 · Bekleyen (bağlantı yokken saklanan) kayıtlar",
              "İnternet yokken formlarda yapılan ve henüz buluta gönderilmemiş değişiklikler.")
    bek = list(getattr(ana, "bekleyen", []))
    if not bek:
        lbl(g, "Bekleyen kayıt yok.", fg=SOLUK).pack(anchor="w")
        return
    f, lb = _liste(g, min(6, len(bek) + 1))
    f.pack(fill="x")
    for e in bek:
        lb.insert("end", "%s · Aşama %d · %d alan · %s · %s" % (e.get("no") or e["sid"], e["asama"], len(e["degerler"]),
                                                                 e["kullanici"].get("ad", ""), e.get("zaman", "")))

    def gonder():
        if not ana.db.cevrimici:
            messagebox.showwarning("Bağlantı yok", "Şu an bağlantı yok; gelince kendiliğinden gönderilecek.")
            return
        ana._bekleyenleri_gonder()
        ana.goster("ayarlar", sekme="mudahale")

    def sil():
        secili = [bek[i] for i in lb.curselection()]
        if not secili:
            messagebox.showinfo("Seçim", "Listeden kayıt seçin.")
            return
        if not messagebox.askyesno("Bekleyen kayıt", "%d bekleyen değişiklik GÖNDERİLMEDEN silinsin mi?" % len(secili)):
            return
        for e in secili:
            if e in ana.bekleyen:
                ana.bekleyen.remove(e)
        ana._bekleyen_yaz()
        ana.goster("ayarlar", sekme="mudahale")
    dz = tk.Frame(g, bg=KART)
    dz.pack(fill="x", pady=(8, 0))
    ttk.Button(dz, text="Şimdi göndermeyi dene", style="Vurgu.TButton", command=gonder).pack(side="left")
    ttk.Button(dz, text="Seçileni sil (gönderme)", command=sil).pack(side="left", padx=8)


# ---------------------------------------------------------------------- 9 hata kaydı
def _hata_karti(ana, ic):
    g = _kart(ic, "9 · Hata kaydı", "Programda oluşan beklenmeyen hataların ayrıntısı (son kısım).")
    yol, metin = MD.hata_kaydi(PROGRAM_KLASORU)
    if not metin:
        lbl(g, "Hata kaydı boş.", fg=YESIL).pack(anchor="w")
        return
    t = tk.Text(g, height=12, font=("Consolas", 9), bg="#F5F7F9", relief="flat", wrap="none")
    t.insert("1.0", metin)
    t.see("end")
    t.configure(state="disabled")
    t.pack(fill="x")

    def temizle():
        if messagebox.askyesno("Hata kaydı", "Hata kaydı temizlensin mi? (eski kayıt hata_kaydi.txt.eski olarak saklanır)"):
            MD.hata_kaydini_temizle(PROGRAM_KLASORU)
            ana.goster("ayarlar", sekme="mudahale")
    dz = tk.Frame(g, bg=KART)
    dz.pack(fill="x", pady=(8, 0))
    import st_arayuz
    ttk.Button(dz, text="Dosyayı aç", command=lambda: st_arayuz.dosya_ac(yol)).pack(side="left")
    ttk.Button(dz, text="Temizle", command=temizle).pack(side="left", padx=8)
