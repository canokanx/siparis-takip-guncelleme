# -*- coding: utf-8 -*-
"""Kıyı Emniyeti Genel Müdürlüğü bağlantısı (Gemi Sefer Takibi'ndeki çalışan bağlantıdan uyarlandı).

- İstanbul ve Çanakkale Boğazı geçiş sırası listeleri (her satırda IMO / MMSI var)
- Boğaz trafiği (açık / askıda saatleri)
- Geminin boğaz geçiş geçmişi (IMO ile)
Arka planda 5 dakikada bir yenilenir; son liste diske kaydedilir, program açılınca hemen gösterilir.
"""
import html
import json
import os
import re
import threading
import time
import datetime as dt
import urllib.parse
import urllib.request

try:
    import requests
except ImportError:  # requests yoksa standart kütüphane ile çalışır
    requests = None

URL = "https://www.kiyiemniyeti.gov.tr/gemi_trafik_bilgi_sistemleri"
TRAFIK_URL = "https://www.kiyiemniyeti.gov.tr/bogaz_trafigi"
GECMIS_URL = "https://www.kiyiemniyeti.gov.tr/Ajax/VesselHistory?IMONumber={imo}"
BOGAZLAR = {"I": "İstanbul", "C": "Çanakkale"}
YONLER = {"SN": "Güney → Kuzey", "NS": "Kuzey → Güney"}
YON_KISA = {"KG": "Kuzey → Güney", "GK": "Güney → Kuzey"}
YENILEME_SN = 300
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) SiparisGemiTakip/1.1"

_TR = re.compile(r"<tr\b[^>]*>(.*?)</tr>", re.S | re.I)
_TD = re.compile(r"<td\b[^>]*>(.*?)</td>", re.S | re.I)
_ETIKET = re.compile(r"<[^>]+>")
_IMO = re.compile(r"ShowHistory\(\s*'?(\d*)'?\s*\)")
_MMSI = re.compile(r"ShowOnMap\(\s*'(\d+)'\s*,\s*''\s*\)")
_SEQ = re.compile(r"ShowMovementHistory\(\s*'(\d+)'")
_SPAN = re.compile(r"<span\b[^>]*>(.*?)</span>", re.S | re.I)


def _yazi(parca):
    return re.sub(r"\s+", " ", html.unescape(_ETIKET.sub(" ", parca))).replace("\xa0", " ").strip()


# ------------------------------------------------------------------ http
class _Oturum:
    def __init__(self):
        self.s = requests.Session() if requests else None
        if not requests:
            import http.cookiejar
            self.op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))

    def get(self, url, params=None, timeout=30):
        if self.s:
            r = self.s.get(url, params=params, headers={"User-Agent": UA}, timeout=timeout)
            r.raise_for_status()
            r.encoding = "utf-8"
            return r.text
        if params:
            url += "?" + urllib.parse.urlencode(params)
        req = urllib.request.Request(url, headers={"User-Agent": UA})
        return self.op.open(req, timeout=timeout).read().decode("utf-8", "replace")

    def post(self, url, data, timeout=45):
        if self.s:
            r = self.s.post(url, data=data, headers={"User-Agent": UA, "Content-Type": "application/x-www-form-urlencoded"},
                            timeout=timeout)
            r.raise_for_status()
            r.encoding = "utf-8"
            return r.text
        req = urllib.request.Request(url, data=urllib.parse.urlencode(data).encode(),
                                     headers={"User-Agent": UA, "Content-Type": "application/x-www-form-urlencoded"})
        return self.op.open(req, timeout=timeout).read().decode("utf-8", "replace")


# ------------------------------------------------------------------ boğaz geçiş listeleri
def tabloyu_coz(sayfa):
    """[{durum, plan_zamani, ad, boy, tip, kilavuz, romorkor, sp2, sp1, imo, mmsi, seq}]"""
    i = sayfa.find("<tbody")
    if i < 0:
        return []
    j = sayfa.find("</tbody>", i)
    govde = sayfa[i:j if j > 0 else None]
    satirlar = []
    for tr in _TR.findall(govde):
        hucre = _TD.findall(tr)
        if len(hucre) < 9:
            continue
        plan = hucre[1]
        span = _SPAN.search(plan)
        durum = _yazi(span.group(1)) if span else ""
        zaman = _yazi(_SPAN.sub(" ", plan)) if span else _yazi(plan)
        imo = (_IMO.search(tr) or [None, ""])[1] or ""
        mmsi = (_MMSI.search(tr) or [None, ""])[1] or ""
        seq = (_SEQ.search(tr) or [None, ""])[1] or ""
        satirlar.append({
            "durum": durum, "plan_zamani": zaman, "ad": _yazi(hucre[2]), "boy": _yazi(hucre[3]),
            "tip": _yazi(hucre[4]), "kilavuz": _yazi(hucre[5]), "romorkor": _yazi(hucre[6]),
            "sp2": _yazi(hucre[7]), "sp1": _yazi(hucre[8]),
            "imo": imo if len(imo) == 7 else "", "mmsi": mmsi if len(mmsi) == 9 else "", "seq": seq,
        })
    return satirlar


def _getir(oturum, bogaz, yon=""):
    return tabloyu_coz(oturum.post(URL, {"submitted": "1", "Strait": bogaz, "Direction": yon, "Movement": ""}))


def listeleri_indir():
    """{'I': [...], 'C': [...], 'zaman': 'dd.mm.yyyy ss:dd'} — her satırda 'yon' alanı da olur."""
    oturum = _Oturum()
    sonuc = {}
    for bogaz in BOGAZLAR:
        hepsi = _getir(oturum, bogaz)
        yon_haritasi = {}
        for yon in YONLER:
            try:
                for s in _getir(oturum, bogaz, yon):
                    yon_haritasi[s["seq"] or (s["imo"], s["ad"])] = yon
            except Exception:
                pass
        for s in hepsi:
            s["yon"] = yon_haritasi.get(s["seq"] or (s["imo"], s["ad"]), "")
        sonuc[bogaz] = hepsi
    sonuc["zaman"] = dt.datetime.now().strftime("%d.%m.%Y %H:%M")
    return sonuc, oturum


# ------------------------------------------------------------------ boğaz trafiği (açık / askıda)
_TRAFIK_PARCA = re.compile(r"<h3[^>]*>(.*?)</h3>|class=\"text_mini_title\"[^>]*>(.*?)</div>|"
                           r"class=\"traffic_info\"[^>]*>(.*?)</div>", re.S | re.I)
_SAAT_ARALIK = re.compile(r"(\d{1,2}:\d{2})\s*-\s*(\d{1,2}:\d{2})\s*(.*)")


def trafik_coz(sayfa):
    """-> {'I': {'KG': [(bas, bit, durum, metin)], 'GK': [...]}, 'C': {...}}  durum: acik | askida | diger"""
    a = sayfa.find('class="traffics"')
    if a < 0:
        return {}
    sonuc, bogaz, yon = {}, None, None
    for h3, baslik, bilgi in _TRAFIK_PARCA.findall(sayfa[a:]):
        if h3:
            t = _yazi(h3).upper()
            bogaz = "I" if "STANBUL" in t else ("C" if "ANAKKALE" in t else None)
            yon = None
        elif baslik:
            t = _yazi(baslik).upper()
            yon = "KG" if t.startswith("KUZEY") else ("GK" if t.startswith("G") else None)
            if bogaz and yon:
                sonuc.setdefault(bogaz, {}).setdefault(yon, [])
        elif bilgi and bogaz and yon:
            m = _SAAT_ARALIK.match(_yazi(bilgi))
            if not m:
                continue
            metin = m.group(3).strip()
            kucuk = metin.lower()
            durum = "askida" if ("ask" in kucuk or "suspension" in kucuk) else \
                ("acik" if ("açık" in kucuk or "open" in kucuk) else "diger")
            kisa = metin.split("(")[0].strip() or metin
            sonuc[bogaz][yon].append((m.group(1).zfill(5), m.group(2).zfill(5), durum, kisa))
    return sonuc


def trafik_indir(oturum=None, gun_sonra=0):
    tarih = dt.date.today() + dt.timedelta(days=gun_sonra)
    return trafik_coz((oturum or _Oturum()).get(TRAFIK_URL, params={"Date": tarih.strftime("%d-%m-%Y")} if gun_sonra else None))


def trafik_durumu(trafik, bogaz, yon, simdi=None):
    """Şu anki durum: (durum, metin, ek) ya da None.  trafik: {'tarih', 'bugun', 'yarin'}"""
    simdi = simdi or dt.datetime.now()
    if not trafik or trafik.get("tarih") != simdi.strftime("%d.%m.%Y"):
        return None
    bugun = ((trafik.get("bugun") or {}).get(bogaz) or {}).get(yon) or []
    yarin = ((trafik.get("yarin") or {}).get(bogaz) or {}).get(yon) or []
    saat = simdi.strftime("%H:%M")
    for i, (bas, bit, durum, metin) in enumerate(bugun):
        if bas <= saat < bit or (bit == "23:59" and saat >= bas):
            bitis, sonraki = bit, None
            sira = bugun[i + 1:] + yarin
            for j, (b2, e2, d2, m2) in enumerate(sira):
                ertesi = "yarın " if j >= len(bugun) - i - 1 else ""
                if d2 == durum:
                    bitis = ertesi + e2
                    continue
                sonraki = (ertesi + b2, d2)
                break
            if sonraki:
                ad = {"acik": "açılış", "askida": "askıya alınma"}.get(sonraki[1], "değişim")
                ek = "%s %s" % (ad, sonraki[0])
            else:
                ek = "bitiş %s" % bitis + (" • yarın planlanmadı" if not yarin else "")
            return durum, metin, ek
    return ("diger", "Planlanmamış", "") if not bugun else None


# ------------------------------------------------------------------ geçiş geçmişi
def gecmis_getir(imo):
    """Geminin boğaz geçiş geçmişi (en yenisi üstte)."""
    sayfa = _Oturum().get(GECMIS_URL.format(imo=int(imo)))
    if "<tbody" not in sayfa:
        return []
    sonuc = []
    for tr in _TR.findall(sayfa[sayfa.find("<tbody"):]):
        h = [_yazi(x) for x in _TD.findall(tr)]
        if len(h) < 7:
            continue
        z = None
        for bicim in ("%m/%d/%Y %H:%M:%S", "%m/%d/%Y %H:%M"):
            try:
                z = dt.datetime.strptime(h[4], bicim)
                break
            except ValueError:
                pass
        bogaz = {"CANAKKALE": "Çanakkale", "ISTANBUL": "İstanbul"}.get(h[3].upper(), h[3].title())
        sonuc.append({"zaman": z.strftime("%d.%m.%Y %H:%M") if z else "", "_z": z or dt.datetime.min,
                      "bogaz": bogaz, "yon": YON_KISA.get(h[6], h[6]), "kalkis": h[1].title(),
                      "varis": h[2].title(), "hazmat": h[5]})
    sonuc.sort(key=lambda x: x["_z"], reverse=True)
    for x in sonuc:
        x.pop("_z", None)
    return sonuc


# ------------------------------------------------------------------ eşleştirme
def _ad_anahtar(ad):
    return " ".join((ad or "").upper().replace("İ", "I").replace("M/V", "").replace("M/T", "").split())


def bul(veri, imo="", ad=""):
    """Boğaz listelerinde gemiyi ara (önce IMO, yoksa birebir ad): {'bogaz','bogaz_adi','sira','satir'} ya da None"""
    ad_k = _ad_anahtar(ad)
    for yontem in ("imo", "ad"):
        for kod in ("I", "C"):
            for i, s in enumerate((veri or {}).get(kod) or [], 1):
                if (yontem == "imo" and imo and s.get("imo") == imo) or \
                        (yontem == "ad" and not imo and ad_k and _ad_anahtar(s.get("ad")) == ad_k):
                    return {"bogaz": kod, "bogaz_adi": BOGAZLAR[kod], "sira": i, "satir": s, "yontem": yontem}
    return None


def ozet(eslesme):
    if not eslesme:
        return ""
    s = eslesme["satir"]
    yon = YONLER.get(s.get("yon"), "")
    parca = ["%s Boğazı sıra %d" % (eslesme["bogaz_adi"], eslesme["sira"])]
    if yon:
        parca.append(yon)
    if s.get("plan_zamani"):
        parca.append("plan " + s["plan_zamani"])
    if s.get("durum"):
        parca.append(s["durum"])
    return " · ".join(parca)


# ------------------------------------------------------------------ listelerdeki değişiklikler
DURUM_ACIKLAMA = {"SP1": "SP1 (bildirim verdi)", "SP2": "SP2", "PLAN. GEÇİŞ": "geçiş planlandı",
                  "GEÇİŞE HAZIR": "geçişe hazır", "BOĞAZDA": "boğazda", "DİĞER": "diğer"}


def _satir_anahtar(s):
    return s.get("seq") or s.get("imo") or _ad_anahtar(s.get("ad"))


def fark(eski, yeni):
    """İki liste arasındaki değişiklikler: [{tur, bogaz, ad, imo, sira, eski, yeni, zaman, satir}]
    tur: eklendi (listeye girdi) · cikti (listeden çıktı / geçişini tamamladı) · durum · plan (plan zamanı) · yon"""
    out = []
    zaman = yeni.get("zaman") or ""
    for kod in BOGAZLAR:
        e = {_satir_anahtar(x): (i, x) for i, x in enumerate((eski or {}).get(kod) or [], 1)}
        y = {_satir_anahtar(x): (i, x) for i, x in enumerate(yeni.get(kod) or [], 1)}
        if not e or not y:
            continue  # bir taraf boş (ilk yükleme / site hatası): her şeyi değişti sayma
        for k, (i, x) in y.items():
            ortak = {"bogaz": kod, "ad": x.get("ad"), "imo": x.get("imo"), "sira": i, "zaman": zaman, "satir": x}
            if k not in e:
                out.append(dict(ortak, tur="eklendi", eski="", yeni=x.get("durum") or ""))
                continue
            o = e[k][1]
            if (o.get("durum") or "") != (x.get("durum") or ""):
                out.append(dict(ortak, tur="durum", eski=o.get("durum") or "", yeni=x.get("durum") or ""))
            if (o.get("plan_zamani") or "") != (x.get("plan_zamani") or ""):
                out.append(dict(ortak, tur="plan", eski=o.get("plan_zamani") or "", yeni=x.get("plan_zamani") or ""))
            if o.get("yon") and x.get("yon") and o["yon"] != x["yon"]:
                out.append(dict(ortak, tur="yon", eski=o["yon"], yeni=x["yon"]))
        for k, (i, x) in e.items():
            if k not in y:
                out.append({"bogaz": kod, "ad": x.get("ad"), "imo": x.get("imo"), "sira": i, "zaman": zaman, "satir": x,
                            "tur": "cikti", "eski": x.get("durum") or "", "yeni": ""})
    return out


def fark_metni(f):
    """Tek değişikliğin kısa Türkçe açıklaması."""
    d = lambda x: DURUM_ACIKLAMA.get(x, x or "—")  # noqa: E731
    if f["tur"] == "eklendi":
        sat = f["satir"]
        ek = [YONLER.get(sat.get("yon"), "")] + (["plan " + sat["plan_zamani"]] if sat.get("plan_zamani") else [])
        return "listeye girdi · sıra %d · %s%s" % (f["sira"], d(f["yeni"]), "".join(" · " + x for x in ek if x))
    if f["tur"] == "cikti":
        return "geçişini tamamladı, listeden çıktı" if f["eski"] == "BOĞAZDA" else "listeden çıktı (%s)" % d(f["eski"])
    if f["tur"] == "durum":
        return "durum: %s → %s" % (d(f["eski"]), d(f["yeni"]))
    if f["tur"] == "plan":
        return "plan zamanı: %s → %s" % (f["eski"] or "—", f["yeni"] or "—")
    if f["tur"] == "yon":
        return "yön: %s → %s" % (YONLER.get(f["eski"], f["eski"]), YONLER.get(f["yeni"], f["yeni"]))
    return f["tur"]


# ------------------------------------------------------------------ arka plan takibi
class KegmTakip:
    """Listeleri arka planda güncel tutar. degisti() thread'den çağrılır (arayüz after() ile almalı)."""

    def __init__(self, onbellek_yolu, degisti=None):
        self.yol = onbellek_yolu
        self.degisti = degisti or (lambda: None)
        self.veri = {"I": [], "C": [], "zaman": ""}
        self.degisiklikler = []  # son 1000 değişiklik (en yenisi sonda)
        self.fark_no = 0  # her yenilemede değişiklik bulunursa artar
        self.son_fark = []
        self.son_fark_bayat = False
        self._dg_yol = os.path.join(os.path.dirname(onbellek_yolu), "kegm_degisiklikler.json")
        try:
            with open(self._dg_yol, "r", encoding="utf-8") as f:
                self.degisiklikler = json.load(f)[-1000:]
        except (OSError, ValueError):
            pass
        self.hata = ""
        self.calisiyor = False
        self._dur = threading.Event()
        self._simdi = threading.Event()
        try:
            with open(self.yol, "r", encoding="utf-8") as f:
                self.veri.update(json.load(f))
        except (OSError, ValueError):
            pass

    def baslat(self):
        threading.Thread(target=self._calis, daemon=True).start()

    def durdur(self):
        self._dur.set()

    def simdi_yenile(self):
        self._simdi.set()

    def _calis(self):
        while not self._dur.is_set():
            self.calisiyor = True
            try:
                yeni, oturum = listeleri_indir()
                try:
                    yeni["trafik"] = {"tarih": dt.date.today().strftime("%d.%m.%Y"), "bugun": trafik_indir(oturum), "yarin": {}}
                    try:
                        yeni["trafik"]["yarin"] = trafik_indir(oturum, gun_sonra=1)
                    except Exception:
                        pass
                except Exception:
                    if self.veri.get("trafik"):
                        yeni["trafik"] = self.veri["trafik"]
                if yeni["I"] or yeni["C"]:
                    try:
                        fl = fark(self.veri, yeni)
                    except Exception:
                        fl = []
                    try:  # önceki liste çok eskiyse (program uzun süre kapalıydı) değişiklikler bildirilmez, kayda geçer
                        once = dt.datetime.strptime(self.veri.get("zaman") or "", "%d.%m.%Y %H:%M")
                        self.son_fark_bayat = (dt.datetime.now() - once).total_seconds() > 1800
                    except ValueError:
                        self.son_fark_bayat = True
                    if fl:
                        self.son_fark = fl
                        self.degisiklikler = (self.degisiklikler + [dict(x, satir=None, metin=fark_metni(x)) for x in fl])[-1000:]
                        self.fark_no += 1
                        try:
                            with open(self._dg_yol + ".tmp", "w", encoding="utf-8") as f:
                                json.dump(self.degisiklikler, f, ensure_ascii=False)
                            os.replace(self._dg_yol + ".tmp", self._dg_yol)
                        except OSError:
                            pass
                    self.veri = yeni
                    self.hata = ""
                    try:
                        gecici = self.yol + ".tmp"
                        with open(gecici, "w", encoding="utf-8") as f:
                            json.dump(yeni, f, ensure_ascii=False)
                        os.replace(gecici, self.yol)
                    except OSError:
                        pass
                else:
                    self.hata = "Kıyı Emniyeti listesi boş geldi (site yapısı değişmiş olabilir)"
            except Exception as e:
                self.hata = "Kıyı Emniyeti sitesine ulaşılamadı: %s" % str(e)[:90]
            self.calisiyor = False
            try:
                self.degisti()
            except Exception:
                pass
            self._simdi.clear()
            bitis = time.time() + YENILEME_SN
            while time.time() < bitis and not self._dur.is_set() and not self._simdi.is_set():
                time.sleep(1)
