# -*- coding: utf-8 -*-
"""Gemi Takip ekranları + İşlem Geçmişi, Kullanıcılar, Ayarlar."""
import datetime as dt
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

import st_mantik as M
from st_tanim import (ROLLER, DEPARTMANLAR, DURUM, RENK, ONCELIK_RENK, BOLGELER, OPERASYON_DURUMLARI,
                      HAREKET_DURUMLARI, SEVIYE_ADI, LACIVERT, VURGU, ZEMIN, KART, CIZGI, YAZI, SOLUK)
from st_ortak import font, pill, kart, link, lbl, bant, ortala

GEMI_FILTRELERI = [
    ("tumu", "Tümü"),
    ("yakin", "48 saatte gelecek"),
    ("degisen", "ETA değişen"),
    ("bogaz", "Boğaz geçişi"),
    ("hazir", "Deposu hazır"),
    ("belirsiz", "ETA belirsiz"),
]


def _eta(g):
    return M.tarihsaat_coz(g["etalar"][0]["eta"]) if g["etalar"] else None


def _filtre_fn(a, kegm=None):
    simdi = dt.datetime.now()
    if a == "yakin":
        return lambda g: bool(_eta(g)) and -12 * 3600 < (_eta(g) - simdi).total_seconds() <= 48 * 3600
    if a == "degisen":
        return lambda g: len(g["etalar"]) > 1 and (M.eta_farki(g["etalar"][0]["eta"], g["etalar"][1]["eta"])[0] or 0) != 0
    if a == "bogaz":
        return lambda g: bool(M.kegm_eslesme(g, kegm)) or "Boğaz" in (g.get("hareket") or "") or bool((g.get("bogaz") or "").strip())
    if a == "hazir":
        return lambda g: g["depo"] == "Hazır"
    if a == "belirsiz":
        return lambda g: not g["etalar"]
    return lambda g: True


def kegm_ozet(g, kegm):
    from st_kegm import ozet
    return ozet(M.kegm_eslesme(g, kegm))


def imo_siparislere_yaz(ana, siparisler, imo):
    """Gemi detayında IMO değişince bu gemiye bağlı açık siparişlerin IMO'sunu da günceller (sipariş esas kaynaktır)."""
    for s in siparisler:
        if M.acik_mi(s) and M.deger(s, 1, "imo") != imo:
            ana.db.alanlari_kaydet(s["id"], 1, {"imo": imo}, ana.k)


def gemi_ekranlarini_ekle(Ana):

    # ================================================================== GEMİ LİSTESİ
    def ekran_gemiler(self, filtre=None):
        filtre = filtre or getattr(self, "_gemi_filtre", "tumu")
        self._gemi_filtre = filtre
        sip = self.db.siparis_listesi()
        gem = M.takip_gemileri(self.db, sip)
        ic = self._sayfa("Gemi Takip · Günlük Operasyon Listesi",
                         "Sipariş kaydı tamamlanınca gemi bu listeye kendiliğinden eklenir; gemiye ait siparişler kapanınca listeden çıkar.",
                         [("Excel'e aktar", lambda: aktar(), "TButton")])
        fl = tk.Frame(ic, bg=ZEMIN)
        fl.pack(fill="x", pady=(0, 12))
        for a, ad in GEMI_FILTRELERI:
            sec = a == filtre
            sayi = len([g for g in gem if _filtre_fn(a, self.kegm.veri)(g)])
            b = tk.Label(fl, text="%s  %d" % (ad, sayi), bg=LACIVERT if sec else KART, fg="#FFFFFF" if sec else YAZI,
                         font=font(10, sec), padx=14, pady=7, cursor="hand2", highlightthickness=1,
                         highlightbackground=LACIVERT if sec else "#B9C2CC")
            b.pack(side="left", padx=(0, 8))
            b.bind("<Button-1>", lambda e, f=a: self.goster("gemiler", filtre=f))

        tablo = kart(ic)
        tablo.pack(fill="x")
        ust = tk.Frame(tablo, bg=KART)
        ust.pack(fill="x", padx=14, pady=10)
        lbl(ust, "Ara").pack(side="left")
        ara = tk.StringVar()
        e = ttk.Entry(ust, textvariable=ara, width=36)
        e.pack(side="left", padx=8)
        kz = self.kegm.veri.get("zaman") or "henüz alınmadı"
        lbl(ust, "Kaynaklar: Acente ETA (elle) · Kıyı Emniyeti boğaz listeleri (otomatik, 5 dk'da bir · son: %s)" % kz,
            fg=SOLUK, boy=8).pack(side="right")
        govde = tk.Frame(tablo, bg=KART)
        govde.pack(fill="x")
        fn = _filtre_fn(filtre, self.kegm.veri)

        def doldur(*_):
            for w in govde.winfo_children():
                w.destroy()
            q = ara.get().strip().lower()
            liste = [g for g in gem if fn(g) and (not q or q in (g["ad"] + " " + (g.get("imo") or "")).lower())]
            bas = ["No", "Gemi adı", "Bölge", "Durum", "Acente ETA", "ETA değişimi", "Depo durumu",
                   "Gemi hareketi", "Kıyı Emniyeti (boğaz)"]
            for c, b in enumerate(bas):
                tk.Label(govde, text=b, bg="#F5F7F9", fg="#33404D", font=font(9, True), anchor="w", padx=8, pady=7).grid(row=0, column=c, sticky="ew")
            govde.columnconfigure(1, weight=1, minsize=150)
            govde.columnconfigure(3, weight=1, minsize=110)
            govde.columnconfigure(7, weight=1, minsize=110)
            if not liste:
                lbl(govde, "Bu filtreye uyan gemi yok.", fg=SOLUK).grid(row=1, column=0, columnspan=9, sticky="w", padx=10, pady=16)
            for r, g in enumerate(liste, start=1):
                ac = (lambda gid: (lambda e=None: self.goster("gemi", gemi_id=gid)))(g["id"])
                hucre = []
                hucre.append(lbl(govde, str(r), fg=SOLUK, padx=8))
                hucre[-1].grid(row=r, column=0, sticky="w")
                ad = tk.Frame(govde, bg=KART)
                ad.grid(row=r, column=1, sticky="w", padx=8, pady=5)
                link(ad, g["ad"], ac).pack(anchor="w")
                if g.get("imo"):
                    lbl(ad, "IMO " + g["imo"], fg=SOLUK, boy=8).pack(anchor="w")
                else:
                    lbl(ad, "IMO eksik", fg="#9E2A21", boy=8, kalin=True).pack(anchor="w")
                lbl(ad, ", ".join(s["no"] for s in g["siparisler"]), fg=SOLUK, boy=8).pack(anchor="w")
                for c, v in ((2, g.get("bolge") or "—"), (3, g.get("op_durum") or "—"),
                             (4, g["etalar"][0]["eta"] if g["etalar"] else "Belirsiz")):
                    x = lbl(govde, v, padx=8, kalin=(c == 4))
                    x.grid(row=r, column=c, sticky="ew")
                    hucre.append(x)
                if len(g["etalar"]) > 1:
                    f_, t_ = M.eta_farki(g["etalar"][0]["eta"], g["etalar"][1]["eta"])
                    pill(govde, t_, "na" if not f_ else ("high" if f_ > 0 else "todo"), boy=8).grid(row=r, column=5, sticky="w", padx=8)
                else:
                    lbl(govde, "—", fg=SOLUK, padx=8).grid(row=r, column=5, sticky="w")
                pill(govde, g["depo"], g["depo_renk"], boy=8).grid(row=r, column=6, sticky="w", padx=8)
                for c, v in ((7, g.get("hareket") or "Bilinmiyor"),):
                    x = lbl(govde, v, padx=8)
                    x.grid(row=r, column=c, sticky="ew")
                    hucre.append(x)
                es = M.kegm_eslesme(g, self.kegm.veri)
                if es:
                    st_ = es["satir"]
                    kisa = "%s #%d" % (es["bogaz_adi"], es["sira"])
                    yon = {"SN": "G→K", "NS": "K→G"}.get(st_.get("yon"), "")
                    alt_k = " · ".join(x_ for x_ in (yon, st_.get("plan_zamani") or "") if x_)
                    kf = tk.Frame(govde, bg=KART)
                    kf.grid(row=r, column=8, sticky="w", padx=8)
                    pill(kf, kisa, "high", boy=8).pack(anchor="w")
                    if alt_k:
                        lbl(kf, alt_k, fg=SOLUK, boy=8).pack(anchor="w")
                else:
                    x = lbl(govde, "Listede yok", fg=SOLUK, padx=8, boy=9)
                    x.grid(row=r, column=8, sticky="ew")
                    hucre.append(x)
                for x in hucre:
                    x.bind("<Button-1>", ac)
                    x.configure(cursor="hand2")
                tk.Frame(govde, bg="#EEF1F4", height=1).grid(row=r, column=0, columnspan=9, sticky="sew")

        def aktar():
            yol = filedialog.asksaveasfilename(title="Excel'e aktar", defaultextension=".xlsx",
                                               initialfile="gunluk_operasyon_%s.xlsx" % M.bugun_str().replace(".", "-"),
                                               filetypes=[("Excel", "*.xlsx"), ("CSV", "*.csv")])
            if not yol:
                return
            bas = ["NO", "GEMİ ADI", "IMO", "BÖLGE", "DURUM", "ACENTE ETA", "ETA DEĞİŞİMİ", "DEPO DURUMU",
                   "İKMAL NOKTASI", "GEMİ HAREKETİ", "KIYI EMNİYETİ", "SİPARİŞLER", "SORUMLU"]
            satir = []
            for i, g in enumerate(gem, 1):
                fark = M.eta_farki(g["etalar"][0]["eta"], g["etalar"][1]["eta"])[1] if len(g["etalar"]) > 1 else ""
                satir.append([i, g["ad"], g.get("imo") or "", g.get("bolge") or "", g.get("op_durum") or "",
                              g["etalar"][0]["eta"] if g["etalar"] else "BELİRSİZ TAKİP EDİLİYOR", fark, g["depo"],
                              g.get("ikmal") or "", g.get("hareket") or "", kegm_ozet(g, self.kegm.veri),
                              ", ".join(s["no"] for s in g["siparisler"]),
                              g.get("sorumlu") or ""])
            self._tablo_yaz(yol, bas, satir)

        ara.trace_add("write", doldur)
        doldur()

    # ================================================================== GEMİ DETAYI
    def ekran_gemi(self, gemi_id):
        g0 = self.db.gemi(gemi_id)
        if not g0:
            self.goster("gemiler")
            return
        sip = self.db.siparis_listesi()
        bagli = [s for s in sip if s.get("gemi_id") == gemi_id]
        etalar = self.db.etalar(gemi_id)  # ETA operasyon bilgisidir, herkese açık
        depo, depo_renk = M.depo_ozeti([s for s in bagli if M.acik_mi(s)])
        ic = self._sayfa(g0["ad"], None)
        link(ic, "‹  Günlük operasyon listesi", lambda: self.goster("gemiler"), bg=ZEMIN, kalin=False).pack(anchor="w", before=ic.winfo_children()[0])

        bk = kart(ic)
        bk.pack(fill="x")
        sol = tk.Frame(bk, bg=KART)
        sol.pack(side="left", padx=18, pady=14)
        lbl(sol, "%s · %s · İkmal noktası: %s" % ("IMO " + g0["imo"] if g0.get("imo") else "IMO eksik", g0.get("bolge") or "—",
                                                g0.get("ikmal") or "—"), fg="#33404D").pack(anchor="w")
        sag = tk.Frame(bk, bg=KART)
        sag.pack(side="right", padx=18)
        lbl(sag, "Depo:", fg="#33404D").pack(side="left")
        pill(sag, depo, depo_renk).pack(side="left", padx=(6, 16))
        lbl(sag, "Hareket:", fg="#33404D").pack(side="left")
        lbl(sag, g0.get("hareket") or "Bilinmiyor", kalin=True).pack(side="left", padx=6)

        es = M.kegm_eslesme(g0, self.kegm.veri)
        if not g0.get("imo"):
            oneri = es["satir"].get("imo") if (es and es["yontem"] == "ad") else ""
            if oneri:
                bf = tk.Frame(ic, bg=ZEMIN)
                bf.pack(fill="x", pady=(12, 0))
                bant(bf, "⚠  IMO numarası girilmemiş. Kıyı Emniyeti listesinde aynı adlı gemi bulundu: IMO %s (%s). "
                         "Doğruysa ekleyin; boğaz takibi ve geçiş geçmişi IMO ile kesinleşir." % (oneri, es["satir"].get("tip") or ""),
                     "uyari").pack(side="left", fill="x", expand=True)

                def imo_ekle(i=oneri):
                    self.db.gemi_guncelle(gemi_id, {"imo": i}, self.k)
                    imo_siparislere_yaz(self, bagli, i)
                    self.bildir("IMO eklendi: %s" % i)
                    self.goster("gemi", gemi_id=gemi_id)
                ttk.Button(bf, text="IMO %s'i ekle" % oneri, style="Vurgu.TButton", command=imo_ekle).pack(side="left", padx=(10, 0))
            else:
                bant(ic, "⚠  IMO numarası girilmemiş. Kıyı Emniyeti listeleri gemiyi IMO ile kesin eşleştirir (IMO yoksa yalnızca "
                         "birebir ad ile aranır). Aşağıdaki Gemi bilgileri bölümünden ekleyin.", "uyari").pack(fill="x", pady=(12, 0))

        # kaynak kartları
        kk = tk.Frame(ic, bg=ZEMIN)
        kk.pack(fill="x", pady=12)
        kaynaklar = [
            ("ACENTE ETA (ELLE GİRİLİR)", etalar[0]["eta"] if etalar else "Belirsiz – takip ediliyor",
             ("Alınma " + M.db_zaman_goster(etalar[0]["alinma"]) + (" · " + etalar[0]["bildiren"] if etalar[0]["bildiren"] else "")) if etalar else "Henüz ETA yok"),
            ("GEMİ HAREKETİ", g0.get("hareket") or "Bilinmiyor", "Elle teyit · otomatik AIS sonraki sürümde"),
            ("KIYI EMNİYETİ – BOĞAZ (OTOMATİK)",
             __import__("st_kegm").ozet(es) if es else "Boğaz geçiş listelerinde yok",
             ("Son güncelleme %s" % (self.kegm.veri.get("zaman") or "—")) + (" · " + self.kegm.hata if self.kegm.hata else "")
             + (" · elle not: " + g0["bogaz"] if g0.get("bogaz") else "")),
        ]
        for i, (b, v, z) in enumerate(kaynaklar):
            k = kart(kk)
            k.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 10, 0))
            kk.columnconfigure(i, weight=1, uniform="kay")
            lbl(k, b, fg=SOLUK, boy=8, kalin=True).pack(anchor="w", padx=14, pady=(12, 2))
            lbl(k, v, boy=12, kalin=True, wraplength=330).pack(anchor="w", padx=14)
            lbl(k, z, fg=SOLUK, boy=8).pack(anchor="w", padx=14, pady=(2, 12))

        alt = tk.Frame(ic, bg=ZEMIN)
        alt.pack(fill="both", expand=True)
        alt.columnconfigure(0, weight=1)
        alt.columnconfigure(1, minsize=340)
        solk = tk.Frame(alt, bg=ZEMIN)
        solk.grid(row=0, column=0, sticky="nsew")
        sagk = tk.Frame(alt, bg=ZEMIN)
        sagk.grid(row=0, column=1, sticky="nsew", padx=(14, 0))

        # ETA girişi
        k = kart(solk)
        k.pack(fill="x")
        lbl(k, "Acenteden yeni ETA gir", boy=12, kalin=True).pack(anchor="w", padx=18, pady=(14, 8))
        form = tk.Frame(k, bg=KART)
        form.pack(fill="x", padx=18)
        v_eta, v_kim, v_lim, v_not = tk.StringVar(), tk.StringVar(), tk.StringVar(value=g0.get("ikmal") or ""), tk.StringVar()
        alanlar = [("Yeni ETA (gg.aa.yyyy ss:dd) *", v_eta), ("Bildiren acente / kişi", v_kim), ("Hedef liman", v_lim), ("Not", v_not)]
        for i, (b, v) in enumerate(alanlar):
            form.columnconfigure(i, weight=1, uniform="eta")
            lbl(form, b, fg="#33404D", boy=9, kalin=True).grid(row=0, column=i, sticky="w", padx=(0, 10))
            e = ttk.Entry(form, textvariable=v)
            e.grid(row=1, column=i, sticky="ew", padx=(0, 10), pady=(3, 0))
            if i == 0:
                e.focus_set()
        alt_ = tk.Frame(k, bg=KART)
        alt_.pack(fill="x", padx=18, pady=12)
        lbl(alt_, "Önceki ETA silinmez; fark otomatik hesaplanır ve operasyona uyarı düşer.", fg=SOLUK, boy=9).pack(side="left")

        def eta_kaydet():
            t = M.tarihsaat_coz(v_eta.get())
            if not t:
                messagebox.showwarning("ETA", "ETA'yı gg.aa.yyyy ss:dd biçiminde yazın.\nÖrnek: 03.11.2026 14:00")
                return
            eta = t.strftime("%d.%m.%Y %H:%M")
            self.db.eta_ekle(gemi_id, eta, v_lim.get().strip(), v_kim.get().strip(), v_not.get().strip(), self.k)
            fark = M.eta_farki(eta, etalar[0]["eta"])[1] if etalar else "ilk ETA"
            self.bildir("%s için ETA kaydedildi (%s)" % (g0["ad"], fark))
            self.goster("gemi", gemi_id=gemi_id)
        ttk.Button(alt_, text="ETA'yı kaydet", style="Vurgu.TButton", command=eta_kaydet).pack(side="right")

        # ETA geçmişi
        k = kart(solk)
        k.pack(fill="x", pady=12)
        lbl(k, "ETA geçmişi", boy=12, kalin=True).pack(anchor="w", padx=18, pady=(14, 8))
        if not etalar:
            lbl(k, "ETA belirsiz – takip ediliyor. Acenteden bilgi gelince yukarıdan girin.", fg=SOLUK).pack(anchor="w", padx=18, pady=(0, 14))
        else:
            tv = ttk.Treeview(k, columns=("eta", "fark", "liman", "alinma", "kim", "not"), show="headings", height=min(6, len(etalar)))
            for a, b, w in (("eta", "ETA", 140), ("fark", "Değişim", 170), ("liman", "Liman", 110), ("alinma", "Alınma", 140),
                            ("kim", "Bildiren", 140), ("not", "Not", 200)):
                tv.heading(a, text=b)
                tv.column(a, width=w, anchor="w")
            tv.tag_configure("gec", background="#FFE6CC")
            tv.tag_configure("erken", background="#FBE3E1")
            for i, e in enumerate(etalar):
                f_, t_ = M.eta_farki(e["eta"], etalar[i + 1]["eta"]) if i + 1 < len(etalar) else (None, "İlk kayıt")
                tv.insert("", "end", values=(e["eta"], t_, e["liman"] or "", M.db_zaman_goster(e["alinma"]), e["bildiren"] or "", e["notu"] or ""),
                          tags=("gec",) if (f_ or 0) > 0 else (("erken",) if (f_ or 0) < 0 else ()))
            tv.pack(fill="x", padx=18, pady=(0, 14))

        # bağlı siparişler
        k = kart(solk)
        k.pack(fill="x")
        lbl(k, "Bu gemiye bağlı siparişler", boy=12, kalin=True).pack(anchor="w", padx=18, pady=(14, 6))
        for s in bagli:
            tk.Frame(k, bg="#EEF1F4", height=1).pack(fill="x")
            sat = tk.Frame(k, bg=KART)
            sat.pack(fill="x", padx=18, pady=8)
            link(sat, s["no"], lambda sid=s["id"]: self.goster("siparis", siparis_id=sid)).pack(side="left")
            pf = tk.Frame(sat, bg=KART)
            pf.pack(side="left", padx=20)
            for n in range(1, 7):
                a_, y_, k_ = RENK[s["durum"].get(n, "todo")]
                tk.Label(pf, text=str(n), width=2, bg=a_, fg=y_, font=font(9, True), highlightthickness=1, highlightbackground=k_).pack(side="left", padx=1)
            g_ = M.genel_durum(s)
            pill(sat, g_[0], g_[1], boy=8).pack(side="right")
        tk.Frame(k, bg=KART, height=8).pack()

        # sağ: gemi bilgileri
        k = kart(sagk)
        k.pack(fill="x")
        lbl(k, "Gemi bilgileri", boy=11, kalin=True).pack(anchor="w", padx=14, pady=(12, 6))
        degis = {}
        bilgi = [("imo", "IMO numarası", None), ("bolge", "Bölge / mevcut konum", BOLGELER),
                 ("op_durum", "Operasyon durumu", OPERASYON_DURUMLARI), ("ikmal", "Öngörülen ikmal noktası", BOLGELER),
                 ("hareket", "Gemi hareketi", HAREKET_DURUMLARI), ("bogaz", "Boğaz / Kıyı Emniyeti bilgisi", None),
                 ("sorumlu", "Sorumlu personel", None), ("notlar", "Notlar", None)]
        for a, b, sec in bilgi:
            lbl(k, b, fg="#33404D", boy=9, kalin=True).pack(anchor="w", padx=14, pady=(4, 0))
            v = tk.StringVar(value=g0.get(a) or "")
            if sec:
                w = ttk.Combobox(k, textvariable=v, values=sec)
            else:
                w = ttk.Entry(k, textvariable=v)
            w.pack(fill="x", padx=14, pady=(2, 0))
            degis[a] = v

        def bilgi_kaydet():
            d = {a: v.get() for a, v in degis.items()}
            imo = d["imo"].strip()
            if imo and (not imo.isdigit() or len(imo) != 7):
                messagebox.showwarning("IMO", "IMO numarası 7 haneli olmalı.")
                return
            self.db.gemi_guncelle(gemi_id, d, self.k)
            if imo and imo != (g0.get("imo") or ""):
                imo_siparislere_yaz(self, bagli, imo)
            self.bildir("Gemi bilgileri kaydedildi")
            self.goster("gemi", gemi_id=gemi_id)
        ttk.Button(k, text="Gemi bilgilerini kaydet", style="Vurgu.TButton", command=bilgi_kaydet).pack(fill="x", padx=14, pady=12)

        # sağ: Kıyı Emniyeti geçiş geçmişi (IMO ile, isteğe bağlı yüklenir)
        kg = kart(sagk)
        kg.pack(fill="x", pady=(12, 0))
        lbl(kg, "Boğaz geçiş geçmişi (Kıyı Emniyeti)", boy=11, kalin=True).pack(anchor="w", padx=14, pady=(12, 4))
        gecmis_kutu = tk.Frame(kg, bg=KART)
        gecmis_kutu.pack(fill="x", padx=14)
        if not g0.get("imo"):
            lbl(gecmis_kutu, "IMO numarası girilince gösterilir.", fg=SOLUK, boy=9).pack(anchor="w")
        else:
            def gecmis_getir():
                for w in gecmis_kutu.winfo_children():
                    w.destroy()
                lbl(gecmis_kutu, "Kıyı Emniyeti'nden alınıyor…", fg=SOLUK, boy=9).pack(anchor="w")
                sonuc = {}

                def is_():
                    try:
                        from st_kegm import gecmis_getir as gg
                        sonuc["v"] = gg(g0["imo"])
                    except Exception as e:
                        sonuc["h"] = str(e)[:120]

                import threading
                t = threading.Thread(target=is_, daemon=True)
                t.start()

                def bekle():
                    if t.is_alive():
                        if gecmis_kutu.winfo_exists():
                            gecmis_kutu.after(300, bekle)
                        return
                    if not gecmis_kutu.winfo_exists():
                        return
                    for w in gecmis_kutu.winfo_children():
                        w.destroy()
                    if "h" in sonuc:
                        lbl(gecmis_kutu, "Ulaşılamadı: " + sonuc["h"], fg="#9E2A21", boy=9, wraplength=290).pack(anchor="w")
                        return
                    v = sonuc.get("v") or []
                    if not v:
                        lbl(gecmis_kutu, "Kayıtlı boğaz geçişi yok.", fg=SOLUK, boy=9).pack(anchor="w")
                    for x in v[:12]:
                        tk.Frame(gecmis_kutu, bg="#EEF1F4", height=1).pack(fill="x", pady=(5, 0))
                        lbl(gecmis_kutu, "%s · %s Boğazı · %s" % (x["zaman"], x["bogaz"], x["yon"]), boy=9, kalin=True).pack(anchor="w")
                        lbl(gecmis_kutu, "%s → %s" % (x["kalkis"] or "?", x["varis"] or "?"), fg=SOLUK, boy=8).pack(anchor="w")
                bekle()
            ttk.Button(kg, text="Geçiş geçmişini getir", command=gecmis_getir).pack(fill="x", padx=14, pady=(6, 0))
        tk.Frame(kg, bg=KART, height=12).pack()

        # sağ: geçmiş
        k = kart(sagk)
        k.pack(fill="x", pady=12)
        lbl(k, "Gemi işlem geçmişi", boy=11, kalin=True).pack(anchor="w", padx=14, pady=(12, 4))
        adlar = self.db.kullanici_adlari()
        kayit = [d for d in self.db.denetim(gemi_id=gemi_id, limit=60) if M.gorebilir(self.k, d["seviye"])]
        if not kayit:
            lbl(k, "Kayıt yok.", fg=SOLUK, boy=9).pack(anchor="w", padx=14)
        for d in kayit[:20]:
            tk.Frame(k, bg="#EEF1F4", height=1).pack(fill="x", padx=14, pady=(6, 0))
            m = d["aciklama"] or ""
            if d["alan"] and d["alan"] != "eta" and (d["eski"] or d["yeni"]):
                m += ": %s → %s" % (d["eski"] or "boş", d["yeni"] or "boş")
            lbl(k, m, boy=9, wraplength=290).pack(anchor="w", padx=14)
            lbl(k, "%s · %s" % (M.db_zaman_goster(d["zaman"]), adlar.get(d["kullanici_id"], "?")), fg=SOLUK, boy=8).pack(anchor="w", padx=14)
        tk.Frame(k, bg=KART, height=10).pack()

    # ================================================================== BOĞAZ LİSTELERİ (KEGM)
    def ekran_bogaz(self, bogaz="I"):
        from st_kegm import BOGAZLAR, YONLER, trafik_durumu, bul
        veri = self.kegm.veri
        gem = M.takip_gemileri(self.db)
        ic = self._sayfa("Boğaz Listeleri · Kıyı Emniyeti",
                         "İstanbul ve Çanakkale Boğazı geçiş sırası – kaynak: kiyiemniyeti.gov.tr (5 dakikada bir otomatik yenilenir)",
                         [("Şimdi yenile", lambda: (self.kegm.simdi_yenile(), self.bildir("Kıyı Emniyeti'nden yenileniyor…")), "TButton")])
        durum = kart(ic)
        durum.pack(fill="x")
        ust = tk.Frame(durum, bg=KART)
        ust.pack(fill="x", padx=16, pady=(12, 4))
        lbl(ust, "Son güncelleme: %s" % (veri.get("zaman") or "henüz alınmadı"), kalin=True).pack(side="left")
        if self.kegm.calisiyor:
            lbl(ust, "  · yenileniyor…", fg=SOLUK).pack(side="left")
        if self.kegm.hata:
            lbl(ust, "  ⚠ " + self.kegm.hata, fg="#9E2A21", boy=9).pack(side="left")
        for kod, ad in BOGAZLAR.items():
            tr = tk.Frame(durum, bg=KART)
            tr.pack(fill="x", padx=16, pady=(0, 6))
            for yk, yad in (("KG", "Kuzey → Güney"), ("GK", "Güney → Kuzey")):
                d = trafik_durumu(veri.get("trafik"), kod, yk)
                if d:
                    renk = {"acik": "done", "askida": "todo"}.get(d[0], "na")
                    pill(tr, "%s %s: %s%s" % (ad, yad, d[1], (" · " + d[2]) if d[2] else ""), renk, boy=8).pack(side="left", padx=(0, 8), pady=2)
        tk.Frame(durum, bg=KART, height=6).pack()

        sekme = tk.Frame(ic, bg=ZEMIN)
        sekme.pack(fill="x", pady=(14, 8))
        for kod, ad in BOGAZLAR.items():
            sec = kod == bogaz
            b = tk.Label(sekme, text="%s Boğazı  %d" % (ad, len(veri.get(kod) or [])), bg=LACIVERT if sec else KART,
                         fg="#FFFFFF" if sec else YAZI, font=font(11, sec), padx=16, pady=8, cursor="hand2",
                         highlightthickness=1, highlightbackground=LACIVERT if sec else "#B9C2CC")
            b.pack(side="left", padx=(0, 8))
            b.bind("<Button-1>", lambda e, k_=kod: self.goster("bogaz", bogaz=k_))
        sadece = tk.BooleanVar(value=False)
        ara = tk.StringVar()
        lbl(sekme, "Ara", bg=ZEMIN).pack(side="left", padx=(16, 6))
        ttk.Entry(sekme, textvariable=ara, width=24).pack(side="left")
        ttk.Checkbutton(sekme, text="Yalnızca siparişli gemilerimiz", variable=sadece, style="Zemin.TCheckbutton").pack(side="left", padx=12)

        # siparişli gemileri eşleştir
        bizim = {}
        for g in gem:
            es = bul(veri, (g.get("imo") or "").strip(), g["ad"])
            if es and es["bogaz"] == bogaz:
                bizim[es["sira"]] = g
        # iki boğazda da siparişli gemilerimizin özeti
        ozet_ = []
        for g in gem:
            es_ = bul(veri, (g.get("imo") or "").strip(), g["ad"])
            if es_:
                ozet_.append("%s → %s #%d (%s)" % (g["ad"], es_["bogaz_adi"], es_["sira"], es_["satir"].get("durum") or ""))
        bant(ic, ("⚓  Boğaz listelerindeki siparişli gemilerimiz: " + " · ".join(ozet_)) if ozet_ else
             "Siparişli gemilerimizden şu an boğaz geçiş listelerinde olan yok (%d gemi takipte)." % len(gem),
             "bilgi" if ozet_ else "kilit").pack(fill="x", pady=(0, 8))
        k = kart(ic)
        k.pack(fill="both", expand=True)
        lbl(k, "Yeşil satırlar siparişi olan gemilerimiz – çift tıklayınca gemi detayı açılır.", fg=SOLUK, boy=9).pack(anchor="w", padx=12, pady=(10, 0))
        cols = ("sira", "biz", "durum", "plan", "ad", "imo", "yon", "boy", "tip", "kilavuz", "romorkor")
        tv = ttk.Treeview(k, columns=cols, show="headings", height=22)
        for a, b, w in (("sira", "Sıra", 50), ("biz", "Sipariş", 170), ("durum", "Durum", 120), ("plan", "Plan zamanı", 140),
                        ("ad", "Gemi", 200), ("imo", "IMO", 80), ("yon", "Yön", 130), ("boy", "Boy", 60), ("tip", "Tip", 130),
                        ("kilavuz", "Kılavuz", 70), ("romorkor", "Römorkör", 80)):
            tv.heading(a, text=b)
            tv.column(a, width=w, anchor="w")
        tv.tag_configure("biz", background="#DDF0E4", font=font(10, True))
        sb = ttk.Scrollbar(k, orient="vertical", command=tv.yview)
        tv.configure(yscrollcommand=sb.set)
        tv.pack(side="left", fill="both", expand=True, padx=(12, 0), pady=10)
        sb.pack(side="right", fill="y", pady=10, padx=(0, 12))

        def doldur(*_):
            tv.delete(*tv.get_children())
            q = ara.get().strip().upper()
            for i, s_ in enumerate(veri.get(bogaz) or [], 1):
                g = bizim.get(i)
                if sadece.get() and not g:
                    continue
                if q and q not in (s_.get("ad", "") + " " + s_.get("imo", "")).upper():
                    continue
                tv.insert("", "end", iid=str(i), values=(i, ", ".join(x["no"] for x in g["siparisler"]) if g else "",
                                                         s_.get("durum"), s_.get("plan_zamani"), s_.get("ad"), s_.get("imo"),
                                                         YONLER.get(s_.get("yon"), ""), s_.get("boy"), s_.get("tip"),
                                                         s_.get("kilavuz"), s_.get("romorkor")),
                          tags=("biz",) if g else ())
            if not tv.get_children():
                tv.insert("", "end", values=("", "", "Liste boş" if not veri.get(bogaz) else "Eşleşen yok", "", "", "", "", "", "", "", ""))

        def cift(e):
            sec = tv.selection()
            if sec and sec[0].isdigit() and int(sec[0]) in bizim:
                self.goster("gemi", gemi_id=bizim[int(sec[0])]["id"])
        tv.bind("<Double-1>", cift)
        ara.trace_add("write", doldur)
        sadece.trace_add("write", doldur)
        doldur()

    # ================================================================== İŞLEM GEÇMİŞİ
    def ekran_gecmis(self):
        ic = self._sayfa("İşlem Geçmişi", "Kim, neyi, ne zaman değiştirdi (görme yetkinize göre süzülür)")
        k = kart(ic)
        k.pack(fill="both", expand=True)
        cols = ("zaman", "kim", "kayit", "asama", "islem", "eski", "yeni")
        tv = ttk.Treeview(k, columns=cols, show="headings", height=24)
        for a, b, w in (("zaman", "Zaman", 130), ("kim", "Kullanıcı", 140), ("kayit", "Kayıt", 140), ("asama", "Aşama", 60),
                        ("islem", "İşlem", 320), ("eski", "Eski değer", 150), ("yeni", "Yeni değer", 150)):
            tv.heading(a, text=b)
            tv.column(a, width=w, anchor="w")
        sb = ttk.Scrollbar(k, orient="vertical", command=tv.yview)
        tv.configure(yscrollcommand=sb.set)
        tv.pack(side="left", fill="both", expand=True, padx=(12, 0), pady=12)
        sb.pack(side="right", fill="y", pady=12, padx=(0, 12))
        adlar = self.db.kullanici_adlari()
        sip = {s["id"]: s["no"] for s in self.db.siparis_listesi()}
        gem = {g["id"]: g["ad"] for g in self.db.gemiler()}
        for d in self.db.denetim(limit=2000):
            if not M.gorebilir(self.k, d["seviye"], asama=d["asama"]):
                continue
            kay = sip.get(d["siparis_id"]) or gem.get(d["gemi_id"]) or ""
            tv.insert("", "end", values=(M.db_zaman_goster(d["zaman"]), adlar.get(d["kullanici_id"], "?"), kay, d["asama"] or "",
                                         d["aciklama"] or "", d["eski"] or "", d["yeni"] or ""))

    # ================================================================== KULLANICILAR
    def ekran_kullanicilar(self):
        ic = self._sayfa("Kullanıcılar / Yetki", "Kullanıcı Kullanıcıların girdiğini ve kendi departmanının aşamasındaki tüm girdileri görür; "
                                                 "Yönetici Yönetici ve Kullanıcı girdilerini görür; Üst Yönetici her şeyi görür.",
                         [("+  Yeni kullanıcı", lambda: kullanici_penceresi(self, None), "Vurgu.TButton")])
        k = kart(ic)
        k.pack(fill="x")
        cols = ("ad", "kadi", "rol", "dept", "aktif")
        tv = ttk.Treeview(k, columns=cols, show="headings", height=14)
        for a, b, w in (("ad", "Ad Soyad", 200), ("kadi", "Kullanıcı adı", 160), ("rol", "Rol", 140), ("dept", "Departman", 140),
                        ("aktif", "Durum", 100)):
            tv.heading(a, text=b)
            tv.column(a, width=w, anchor="w")
        tv.tag_configure("pasif", foreground="#9AA1AC")
        for u in self.db.kullanicilar():
            tv.insert("", "end", iid=str(u["id"]), values=(u["ad"], u["kadi"], ROLLER[u["rol"]], DEPARTMANLAR.get(u["departman"], u["departman"]),
                                                       "Aktif" if u["aktif"] else "Pasif"), tags=() if u["aktif"] else ("pasif",))
        tv.pack(fill="x", padx=12, pady=12)
        dz = tk.Frame(k, bg=KART)
        dz.pack(fill="x", padx=12, pady=(0, 12))

        def secili(fn):
            s = tv.selection()
            if not s:
                messagebox.showinfo("Seçim", "Önce bir kullanıcı seçin.")
                return
            fn(int(s[0]))
        ttk.Button(dz, text="Düzenle", command=lambda: secili(lambda i: kullanici_penceresi(self, i))).pack(side="left")
        ttk.Button(dz, text="Şifre sıfırla", command=lambda: secili(lambda i: sifre_penceresi(self, i))).pack(side="left", padx=6)
        tv.bind("<Double-1>", lambda e: secili(lambda i: kullanici_penceresi(self, i)))

    # ================================================================== AYARLAR
    def ekran_ayarlar(self, sekme="genel"):
        ic = self._sayfa("Ayarlar")
        sk = tk.Frame(ic, bg=ZEMIN)
        sk.pack(fill="x", pady=(0, 12))
        for a_, ad_ in (("genel", "Genel"), ("programci", "Programcı (güncelleme · yedek)")):
            sec = a_ == sekme
            b = tk.Label(sk, text=ad_, bg=LACIVERT if sec else KART, fg="#FFFFFF" if sec else YAZI, font=font(11, sec),
                         padx=16, pady=8, cursor="hand2", highlightthickness=1, highlightbackground=LACIVERT if sec else "#B9C2CC")
            b.pack(side="left", padx=(0, 8))
            b.bind("<Button-1>", lambda e, x=a_: self.goster("ayarlar", sekme=x))
        if sekme == "programci":
            from st_arayuz_programci import programci_bolumu
            programci_bolumu(self, ic)
            return
        k = kart(ic)
        k.pack(fill="x")
        lbl(k, "Veri klasörü", boy=12, kalin=True).pack(anchor="w", padx=18, pady=(14, 2))
        lbl(k, "Siparişler, gemiler ve ekler bu klasördeki veritabanında tutulur. Ekibin aynı veriyi görmesi için bu klasörü "
               "ortak bir ağ klasörüne veya paylaşılan bulut klasörüne taşıyıp herkesin programında aynı klasörü seçin.",
            fg=SOLUK, wraplength=820).pack(anchor="w", padx=18)
        v = tk.StringVar(value=self.db.klasor)
        sat = tk.Frame(k, bg=KART)
        sat.pack(fill="x", padx=18, pady=10)
        ttk.Entry(sat, textvariable=v, state="readonly").pack(side="left", fill="x", expand=True)

        def sec():
            y = filedialog.askdirectory(title="Veri klasörünü seçin", initialdir=self.db.klasor)
            if not y:
                return
            self.ayarlar["veri_klasoru"] = y
            self.ayarlar_kaydet()
            messagebox.showinfo("Veri klasörü", "Yeni veri klasörü kaydedildi:\n%s\n\nProgramı kapatıp yeniden açın. "
                                                "Klasörde veritabanı yoksa yeni ve boş bir veritabanı oluşturulur." % y)
            v.set(y)
        ttk.Button(sat, text="Klasör seç…", command=sec).pack(side="left", padx=(8, 0))
        ttk.Button(sat, text="Klasörü aç", command=lambda: __import__("st_arayuz").dosya_ac(self.db.klasor)).pack(side="left", padx=(8, 0))
        tk.Frame(k, bg=KART, height=6).pack()

        k2 = kart(ic)
        k2.pack(fill="x", pady=12)
        lbl(k2, "Yedek al", boy=12, kalin=True).pack(anchor="w", padx=18, pady=(14, 2))
        lbl(k2, "Veritabanının o anki kopyasını seçtiğiniz yere kaydeder.", fg=SOLUK).pack(anchor="w", padx=18)

        def yedek():
            y = filedialog.asksaveasfilename(title="Yedeği kaydet", defaultextension=".db",
                                             initialfile="siparis_takip_yedek_%s.db" % dt.datetime.now().strftime("%Y%m%d_%H%M"))
            if not y:
                return
            import sqlite3
            hedef = sqlite3.connect(y)
            self.db.c.backup(hedef)
            hedef.close()
            self.bildir("Yedek alındı: " + y)
        ttk.Button(k2, text="Yedek al…", command=yedek).pack(anchor="w", padx=18, pady=12)

        k3 = kart(ic)
        k3.pack(fill="x")
        lbl(k3, "Masaüstü kısayolu", boy=12, kalin=True).pack(anchor="w", padx=18, pady=(14, 2))
        lbl(k3, "Masaüstüne program simgeli kısayol oluşturur.", fg=SOLUK).pack(anchor="w", padx=18)

        def kisayol():
            from st_kisayol import kisayol_olustur
            ok, mesaj = kisayol_olustur()
            (messagebox.showinfo if ok else messagebox.showwarning)("Masaüstü kısayolu",
                                                                     "Kısayol masaüstüne eklendi." if ok else mesaj)
        ttk.Button(k3, text="Kısayol oluştur", command=kisayol).pack(anchor="w", padx=18, pady=12)

    Ana.ekran_gemiler = ekran_gemiler
    Ana.ekran_gemi = ekran_gemi
    Ana.ekran_gecmis = ekran_gecmis
    Ana.ekran_kullanicilar = ekran_kullanicilar
    Ana.ekran_ayarlar = ekran_ayarlar
    Ana.ekran_bogaz = ekran_bogaz


# ---------------------------------------------------------------------------------- pencereler
def kullanici_penceresi(ana, kid, ilk_kurulum=False, root=None, bitince=None):
    """Kullanıcı ekle / düzenle. ilk_kurulum=True ise ilk Üst Yönetici hesabı oluşturulur."""
    db = ana.db if ana else None
    u = db.kullanici(kid) if (kid and db) else None
    p = tk.Toplevel(root or ana)
    p.title("İlk kurulum – Üst Yönetici hesabı" if ilk_kurulum else ("Kullanıcıyı düzenle" if u else "Yeni kullanıcı"))
    p.configure(bg=KART)
    p.resizable(False, False)
    if ana:
        p.transient(ana.root)
    p.grab_set()
    satir = 0
    if ilk_kurulum:
        lbl(p, "Hoş geldiniz", boy=15, kalin=True).grid(row=0, column=0, columnspan=2, sticky="w", padx=18, pady=(16, 2))
        lbl(p, "İlk hesap Üst Yönetici olarak oluşturulur. Diğer kullanıcıları\nsonra 'Kullanıcılar / Yetki' ekranından eklersiniz.",
            fg=SOLUK).grid(row=1, column=0, columnspan=2, sticky="w", padx=18)
        satir = 2
    v_ad = tk.StringVar(value=u["ad"] if u else "")
    v_kadi = tk.StringVar(value=u["kadi"] if u else "")
    v_s1, v_s2 = tk.StringVar(), tk.StringVar()
    rol_ad = {v: k for k, v in ROLLER.items()}
    dep_ad = {v: k for k, v in DEPARTMANLAR.items()}
    v_rol = tk.StringVar(value=ROLLER[u["rol"]] if u else ("Üst Yönetici" if ilk_kurulum else "Kullanıcı"))
    v_dep = tk.StringVar(value=DEPARTMANLAR.get(u["departman"]) if u else ("Yönetim" if ilk_kurulum else "Satın Alma"))
    v_aktif = tk.BooleanVar(value=bool(u["aktif"]) if u else True)
    alanlar = [("Ad Soyad", ttk.Entry(p, textvariable=v_ad, width=34)),
               ("Kullanıcı adı", ttk.Entry(p, textvariable=v_kadi, width=34, state="readonly" if u else "normal"))]
    if not u:
        alanlar += [("Şifre", ttk.Entry(p, textvariable=v_s1, show="•", width=34)),
                    ("Şifre (tekrar)", ttk.Entry(p, textvariable=v_s2, show="•", width=34))]
    if not ilk_kurulum:
        alanlar += [("Rol", ttk.Combobox(p, textvariable=v_rol, values=list(ROLLER.values()), state="readonly", width=32)),
                    ("Departman", ttk.Combobox(p, textvariable=v_dep, values=list(DEPARTMANLAR.values()), state="readonly", width=32))]
    for i, (b, w) in enumerate(alanlar):
        lbl(p, b, boy=9, kalin=True).grid(row=satir + i, column=0, sticky="w", padx=18, pady=6)
        w.grid(row=satir + i, column=1, sticky="ew", padx=18, pady=6)
    satir += len(alanlar)
    if u:
        ttk.Checkbutton(p, text="Aktif (pasif kullanıcı giriş yapamaz)", variable=v_aktif).grid(row=satir, column=1, sticky="w", padx=18)
        satir += 1
    alanlar[0][1].focus_set()

    def tamam():
        ad, kadi = v_ad.get().strip(), v_kadi.get().strip()
        if not ad or not kadi:
            messagebox.showwarning("Eksik", "Ad soyad ve kullanıcı adı zorunlu.", parent=p)
            return
        rol, dep = rol_ad[v_rol.get()], dep_ad[v_dep.get()]
        try:
            if u:
                if u["id"] == ana.k["id"] and (rol != "ust" or not v_aktif.get()):
                    messagebox.showwarning("Uyarı", "Kendi Üst Yönetici yetkinizi kaldıramazsınız.", parent=p)
                    return
                db.kullanici_guncelle(u["id"], ad, rol, dep, v_aktif.get())
            else:
                if len(v_s1.get()) < 4:
                    messagebox.showwarning("Şifre", "Şifre en az 4 karakter olmalı.", parent=p)
                    return
                if v_s1.get() != v_s2.get():
                    messagebox.showwarning("Şifre", "Şifreler aynı değil.", parent=p)
                    return
                (db or ana_db_ilk[0]).kullanici_ekle(kadi, ad, v_s1.get(), rol, dep)
        except Exception as e:
            if "UNIQUE" in str(e):
                messagebox.showwarning("Kullanıcı adı", "Bu kullanıcı adı zaten var.", parent=p)
            else:
                messagebox.showerror("Hata", str(e), parent=p)
            return
        p.destroy()
        if bitince:
            bitince(kadi)
        elif ana:
            ana.goster("kullanicilar")

    dz = tk.Frame(p, bg=KART)
    dz.grid(row=satir, column=0, columnspan=2, sticky="e", padx=18, pady=14)
    if not ilk_kurulum:
        ttk.Button(dz, text="Vazgeç", command=p.destroy).pack(side="right", padx=(6, 0))
    ttk.Button(dz, text="Hesabı oluştur" if ilk_kurulum else "Kaydet", style="Vurgu.TButton", command=tamam).pack(side="right")
    p.bind("<Return>", lambda e: tamam())
    ortala(p, ana.root if ana else None)
    return p


ana_db_ilk = [None]  # ilk kurulumda (ana pencere yokken) kullanılan veritabanı


def sifre_penceresi(ana, kid):
    u = ana.db.kullanici(kid)
    p = tk.Toplevel(ana)
    p.title("Şifre sıfırla – %s" % u["ad"])
    p.configure(bg=KART)
    p.transient(ana.root)
    p.grab_set()
    v1, v2 = tk.StringVar(), tk.StringVar()
    for i, (b, v) in enumerate((("Yeni şifre", v1), ("Yeni şifre (tekrar)", v2))):
        lbl(p, b, boy=9, kalin=True).grid(row=i, column=0, sticky="w", padx=18, pady=(14 if i == 0 else 6, 0))
        e = ttk.Entry(p, textvariable=v, show="•", width=30)
        e.grid(row=i, column=1, padx=18, pady=(14 if i == 0 else 6, 0))
        if i == 0:
            e.focus_set()

    def tamam():
        if len(v1.get()) < 4 or v1.get() != v2.get():
            messagebox.showwarning("Şifre", "Şifreler en az 4 karakter olmalı ve aynı olmalı.", parent=p)
            return
        ana.db.sifre_degistir(kid, v1.get())
        p.destroy()
        ana.bildir("%s için şifre sıfırlandı" % u["ad"])
    ttk.Button(p, text="Kaydet", style="Vurgu.TButton", command=tamam).grid(row=2, column=1, sticky="e", padx=18, pady=14)
    ortala(p, ana.root)
