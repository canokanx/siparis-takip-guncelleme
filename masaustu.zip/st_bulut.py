# -*- coding: utf-8 -*-
"""Bulut veritabanı (Supabase / PostgreSQL) bağlantısı.

Programın veri katmanı SQLite için yazıldı; bu dosya aynı arayüzü (execute / fetchone / lastrowid / commit)
PostgreSQL üzerinde sağlar. Böylece bütün bilgisayarlar internet üzerinden aynı veriyi kullanır.
Saf Python sürücü kullanılır (pg8000) – derleme gerektirmez; yoksa program kendisi kurar.
"""
import collections
import json
import os
import pickle
import re
import ssl
import subprocess
import sys
import threading
import time
import urllib.parse

ID_TABLOLARI = {"kullanicilar", "siparisler", "satirlar", "ekler", "denetim", "gemiler", "etalar"}

SEMA_PG = """
CREATE TABLE IF NOT EXISTS kullanicilar (
    id SERIAL PRIMARY KEY, kadi TEXT UNIQUE NOT NULL, ad TEXT NOT NULL, sifre_hash TEXT NOT NULL, tuz TEXT NOT NULL,
    rol TEXT NOT NULL, departman TEXT NOT NULL, aktif INTEGER NOT NULL DEFAULT 1, olusturma TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS siparisler (
    id SERIAL PRIMARY KEY, no TEXT UNIQUE NOT NULL, olusturan_id INTEGER, olusturma TEXT NOT NULL,
    iptal INTEGER NOT NULL DEFAULT 0, silindi INTEGER NOT NULL DEFAULT 0, silen_id INTEGER, silinme TEXT,
    silme_nedeni TEXT, gemi_id INTEGER);
CREATE TABLE IF NOT EXISTS asama_durum (
    siparis_id INTEGER NOT NULL, asama INTEGER NOT NULL, durum TEXT NOT NULL, guncelleyen_id INTEGER, zaman TEXT,
    PRIMARY KEY (siparis_id, asama));
CREATE TABLE IF NOT EXISTS asama_veri (
    siparis_id INTEGER NOT NULL, asama INTEGER NOT NULL, alan TEXT NOT NULL, deger TEXT, giren_id INTEGER,
    giren_seviye INTEGER NOT NULL DEFAULT 1, zaman TEXT, PRIMARY KEY (siparis_id, asama, alan));
CREATE TABLE IF NOT EXISTS satirlar (
    id SERIAL PRIMARY KEY, siparis_id INTEGER NOT NULL, malzeme TEXT, kod TEXT, miktar TEXT, birim TEXT,
    tedarikci TEXT, termin TEXT, toplama TEXT DEFAULT 'Bekliyor', toplanan TEXT, satir_notu TEXT,
    silindi INTEGER NOT NULL DEFAULT 0, fiyat TEXT, depoda TEXT, tedarik_sekli TEXT);
CREATE TABLE IF NOT EXISTS ekler (
    id SERIAL PRIMARY KEY, siparis_id INTEGER NOT NULL, asama INTEGER NOT NULL, dosya_adi TEXT NOT NULL,
    goreli_yol TEXT NOT NULL, ekleyen_id INTEGER, ekleyen_seviye INTEGER NOT NULL DEFAULT 1, zaman TEXT,
    silindi INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS ek_dosyalar (ek_id INTEGER PRIMARY KEY, veri BYTEA);
CREATE TABLE IF NOT EXISTS denetim (
    id SERIAL PRIMARY KEY, siparis_id INTEGER, gemi_id INTEGER, asama INTEGER, alan TEXT, eski TEXT, yeni TEXT,
    aciklama TEXT, kullanici_id INTEGER, seviye INTEGER NOT NULL DEFAULT 1, zaman TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS gemiler (
    id SERIAL PRIMARY KEY, anahtar TEXT UNIQUE NOT NULL, ad TEXT NOT NULL, imo TEXT, bolge TEXT, op_durum TEXT,
    ikmal TEXT, hareket TEXT, bogaz TEXT, sorumlu TEXT, notlar TEXT, olusturma TEXT);
CREATE TABLE IF NOT EXISTS etalar (
    id SERIAL PRIMARY KEY, gemi_id INTEGER NOT NULL, eta TEXT NOT NULL, liman TEXT, bildiren TEXT, notu TEXT,
    giren_id INTEGER, giren_seviye INTEGER NOT NULL DEFAULT 1, alinma TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS meta (anahtar TEXT PRIMARY KEY, deger TEXT);
CREATE TABLE IF NOT EXISTS okundu (kullanici_id INTEGER NOT NULL, anahtar TEXT NOT NULL, zaman TEXT,
    PRIMARY KEY (kullanici_id, anahtar));
CREATE INDEX IF NOT EXISTS ix_veri_siparis ON asama_veri (siparis_id);
CREATE INDEX IF NOT EXISTS ix_denetim_siparis ON denetim (siparis_id);
CREATE INDEX IF NOT EXISTS ix_denetim_gemi ON denetim (gemi_id);
CREATE INDEX IF NOT EXISTS ix_etalar_gemi ON etalar (gemi_id);
"""
# yedek / aktarım sırası
TABLOLAR = ["kullanicilar", "siparisler", "asama_durum", "asama_veri", "satirlar", "ekler", "denetim", "gemiler",
            "etalar", "meta", "okundu"]


class BulutHatasi(Exception):
    pass


def surucu_hazir(kur=False, log=None):
    """pg8000 var mı; yoksa (kur=True ise) pip ile kurar."""
    try:
        import pg8000  # noqa
        return True
    except ImportError:
        if not kur:
            return False
    exe = sys.executable
    if exe.lower().endswith("pythonw.exe"):
        exe = exe[:-len("pythonw.exe")] + "python.exe"
    gizli = 0x08000000 if sys.platform.startswith("win") else 0
    r = subprocess.run([exe, "-m", "pip", "install", "--disable-pip-version-check", "pg8000"], capture_output=True,
                       text=True, creationflags=gizli)
    if log:
        log(r.stdout[-400:] + r.stderr[-400:])
    try:
        import importlib
        importlib.invalidate_caches()
        import pg8000  # noqa: F811
        return True
    except ImportError:
        return False


_URI = re.compile(r"^postgres(?:ql)?://(?P<user>[^:@/\s]+)(?::(?P<pw>.*))?@(?P<host>[^:/@\s]+)(?::(?P<port>\d+))?(?:/(?P<db>[^?\s]*))?")


def _uri_parcala(uri):
    m = _URI.match((uri or "").strip())
    if not m:
        raise BulutHatasi("Bağlantı adresi tanınmadı. Supabase → Connect → 'Session pooler' adresini olduğu gibi yapıştırın "
                          "(postgresql://postgres.xxxx:[YOUR-PASSWORD]@aws-0-….pooler.supabase.com:5432/postgres).")
    return m


def uri_coz(uri, sifre=""):
    """Supabase bağlantı adresi: postgresql://postgres.xxxx:[YOUR-PASSWORD]@aws-0-eu-central-1.pooler.supabase.com:5432/postgres
    Adresteki [YOUR-PASSWORD] yer tutucusu yerine ayrı yazılan şifre kullanılır."""
    m = _uri_parcala(uri)
    adresteki = urllib.parse.unquote(m.group("pw") or "")
    if adresteki.startswith("[") and adresteki.endswith("]"):
        adresteki = ""
    parola = (sifre or "").strip() or adresteki
    if not parola:
        raise BulutHatasi("Veritabanı şifresi girilmedi.")
    return {"host": m.group("host"), "port": int(m.group("port") or 5432), "user": urllib.parse.unquote(m.group("user")),
            "password": parola, "database": (m.group("db") or "postgres") or "postgres"}


def uri_sifresiz(uri):
    """Adresteki şifreyi çıkarır (ayarlarda şifre ayrıca şifreli saklanır)."""
    m = _uri_parcala(uri)
    return "postgresql://%s@%s:%s/%s" % (m.group("user"), m.group("host"), m.group("port") or 5432, m.group("db") or "postgres")


# ------------------------------------------------------------------ SQL çevirisi (SQLite -> PostgreSQL)
_SORU = re.compile(r"\?")


def cevir(sql):
    s = sql.replace("%", "%%")
    s = _SORU.sub("%s", s)
    if re.match(r"\s*INSERT\s+OR\s+IGNORE\s+INTO", s, re.I):
        s = re.sub(r"INSERT\s+OR\s+IGNORE\s+INTO", "INSERT INTO", s, count=1, flags=re.I) + " ON CONFLICT DO NOTHING"
    tablo = None
    m = re.match(r"\s*INSERT\s+INTO\s+(\w+)", s, re.I)
    if m and m.group(1).lower() in ID_TABLOLARI and "RETURNING" not in s.upper():
        s += " RETURNING id"
        tablo = m.group(1)
    return s, tablo


class Satir(dict):
    """sqlite3.Row gibi: r['ad'], r[0] ve dict(r) çalışır."""

    def __init__(self, sutunlar, degerler):
        super().__init__(zip(sutunlar, degerler))
        self._liste = list(degerler)

    def __getitem__(self, k):
        if isinstance(k, int):
            return self._liste[k]
        return dict.__getitem__(self, k)


class BaglantiYok(BulutHatasi):
    """İnternet / bulut bağlantısı yok. Yazma işlemi yapılamadı (ya da yapıldığı kesin değil)."""
    pass


SAAT_FARKI = [0.0]  # sunucu saati - bilgisayar saati (sn); kayıt saatleri sunucu saatine göre yazılır


def ag_hatasi_mi(e):
    if isinstance(e, (BaglantiYok, OSError, ssl.SSLError)):
        return True
    ad = type(e).__name__
    m = str(e).lower()
    return ad in ("InterfaceError", "OperationalError") or "network" in m or "connection" in m or "timed out" in m \
        or "broken pipe" in m or "eof" in m


def tekil_ihlali_mi(e):
    m = str(e)
    return "23505" in m or "UNIQUE constraint" in m or "duplicate key" in m


class Imlec:
    def __init__(self, satirlar, lastrowid=None, rowcount=-1):
        self._s = satirlar
        self.lastrowid = lastrowid
        self.rowcount = rowcount

    def fetchone(self):
        return self._s[0] if self._s else None

    def fetchall(self):
        return list(self._s)

    def __iter__(self):
        return iter(self._s)


class Baglanti:
    """sqlite3.Connection'ın programda kullanılan kısmı (PostgreSQL üzerinde).

    - Her bilgisayar TEK bağlantı kullanır (Supabase ücretsiz pakette bağlantı sayısı sınırlı). Arka plandaki izleyici
      de aynı bağlantıyı sırayla kullanır.
    - Okumalar önbellekte tutulur; izleyici birkaç saniyede bir buluttaki değişiklik sayacına bakar, başka bilgisayar
      veri değiştirdiyse önbelleği ve sipariş aynasını arka planda tazeler.
    - İnternet koparsa: okumalar son bilinen veriden verilir, yazmalar hemen BaglantiYok hatası verir (program donmaz),
      izleyici bağlantı gelene kadar yeniden dener.
    - Yazmalar ağ hatasında otomatik TEKRARLANMAZ (çift kayıt olmasın)."""
    bulut = True
    IZLEME_SN = 3.0       # değişiklik sayacı kontrol aralığı
    GECERLILIK_SN = 20.0  # izleyici bu kadar süre kontrol edemezse önbellek kısa süreliye döner
    ISITILACAK = 60       # değişiklikte arka planda yeniden çekilecek son sorgu sayısı
    ZAMAN_ASIMI = 6       # sn – yanıt gelmezse bağlantı kopmuş sayılır
    ONBELLEK_SN = 3.0     # izleyici yokken: aynı ekran çizilirken tekrar eden okumalar internete gitmesin

    def __init__(self, ayar, zaman_asimi=None):
        self.ayar = ayar
        self.c = None
        self.zaman_asimi = zaman_asimi or self.ZAMAN_ASIMI
        self._kilit = threading.Lock()          # önbellek
        self._bkilit = threading.RLock()        # bağlantı (tek bağlantı, sırayla kullanılır)
        self._onbellek = {}
        self._nesil = 0
        self._dogrulama = 0.0
        self._izleniyor = False
        self._izleyici = None
        self._kapali = False
        self._islemde = 0
        self._son_okumalar = collections.OrderedDict()
        self.cevrimici = True
        self.son_hata = ""
        self.ayna = None
        self.c = self._yeni_baglanti()
        self._saat_ayarla()

    # ---------------------------------------------------------------- bağlantı
    def _yeni_baglanti(self):
        try:
            import pg8000.dbapi as pg
        except ImportError:
            raise BulutHatasi("Bulut sürücüsü (pg8000) kurulu değil.")
        baglam = ssl.create_default_context()
        baglam.check_hostname = False
        baglam.verify_mode = ssl.CERT_NONE
        try:
            c = pg.connect(host=self.ayar["host"], port=int(self.ayar["port"]), user=self.ayar["user"],
                           password=self.ayar["password"], database=self.ayar["database"], ssl_context=baglam,
                           timeout=self.zaman_asimi)
        except Exception as e:
            m = str(e)
            if "password" in m.lower() or "28P01" in m:
                raise BulutHatasi("Veritabanı şifresi yanlış.")
            if "max client" in m.lower() or "too many" in m.lower():
                raise BulutHatasi("Bulut veritabanı bağlantı sınırı doldu (çok sayıda bilgisayar açık). Biraz sonra tekrar deneyin.")
            raise BaglantiYok("Bulut veritabanına bağlanılamadı: %s" % m[:200])
        c.autocommit = True
        return c

    def _baglan(self):
        """Kopan bağlantıyı yeniler (kilit dışında kurulur, sonra yerine konur)."""
        yeni = self._yeni_baglanti()
        with self._bkilit:
            eski, self.c = self.c, yeni
        try:
            if eski is not None:
                eski.close()
        except Exception:
            pass
        self.cevrimici, self.son_hata = True, ""

    def _koptu(self, e):
        self.cevrimici = False
        self.son_hata = str(e)[:200]
        try:
            if self.c is not None:
                self.c.close()
        except Exception:
            pass
        self.c = None

    def _saat_ayarla(self):
        try:
            import datetime as _dt
            once = time.time()
            r = self._calistir("SELECT now()").fetchone()
            sonra = time.time()
            sunucu = r[0]
            if getattr(sunucu, "tzinfo", None) is not None:
                sunucu = sunucu.astimezone().replace(tzinfo=None)
            yerel = _dt.datetime.fromtimestamp((once + sonra) / 2)
            fark = (sunucu - yerel).total_seconds()
            SAAT_FARKI[0] = fark if abs(fark) > 2 else 0.0
        except Exception:
            pass

    # ---------------------------------------------------------------- çalıştırma
    def _calistir(self, sql, params=(), yazma=None):
        s, tablo = cevir(sql)
        if yazma is None:
            yazma = not s.lstrip()[:6].upper() in ("SELECT", "BEGIN", "COMMIT", "ROLLB")
        with self._bkilit:
            for deneme in (1, 2):
                if self.c is None:
                    if self._islemde:
                        raise BaglantiYok("Bağlantı işlem sırasında koptu.")
                    if self._izleniyor and threading.current_thread() is not self._izleyici:
                        # yeniden bağlanmayı arka plandaki izleyici yapar; ekran beklemez
                        raise BaglantiYok("İnternet / bulut bağlantısı yok (yeniden bağlanılıyor…)")
                    try:
                        self._baglan()
                    except BulutHatasi as e:
                        self._koptu(e)
                        raise BaglantiYok(str(e))
                try:
                    cur = self.c.cursor()
                    cur.execute(s, tuple(params or ()))
                    satirlar = []
                    if cur.description:
                        sutunlar = [d[0] for d in cur.description]
                        satirlar = [Satir(sutunlar, r) for r in cur.fetchall()]
                    son = satirlar[0][0] if (tablo and satirlar) else None
                    self.cevrimici = True
                    return Imlec([] if tablo else satirlar, son, getattr(cur, "rowcount", -1))
                except Exception as e:
                    if not ag_hatasi_mi(e):
                        raise
                    self._koptu(e)
                    # okuma güvenle tekrarlanır; yazma tekrarlanmaz (sunucuya ulaşıp ulaşmadığı belli değil)
                    if deneme == 1 and not yazma and not self._islemde:
                        continue
                    raise BaglantiYok("Bulut bağlantısı koptu: %s" % str(e)[:150])

    def _onbellek_gecerli_mi(self, zaman):
        if not self.cevrimici:
            return True  # bağlantı yokken son bilinen veri gösterilir
        if self._izleniyor and time.time() - self._dogrulama < self.GECERLILIK_SN:
            return True
        return time.time() - zaman < self.ONBELLEK_SN

    def execute(self, sql, params=()):
        okuma = sql.lstrip()[:6].upper() == "SELECT"
        anahtar = (sql, tuple(params or ()))
        if okuma and not self._islemde:
            with self._kilit:
                k = self._onbellek.get(anahtar)
                self._son_okumalar[anahtar] = 1
                self._son_okumalar.move_to_end(anahtar)
                while len(self._son_okumalar) > self.ISITILACAK:
                    self._son_okumalar.popitem(last=False)
                nesil = self._nesil
            if k and self._onbellek_gecerli_mi(k[0]):
                return Imlec(list(k[1]), None)
            try:
                im = self._calistir(sql, params, yazma=False)
            except BaglantiYok:
                if k:
                    return Imlec(list(k[1]), None)  # eski veri, hiç yoktan iyidir
                raise
            with self._kilit:
                if self._nesil == nesil:  # bu arada veri değişmediyse sakla
                    if len(self._onbellek) > 500:
                        self._onbellek.clear()
                    self._onbellek[anahtar] = (time.time(), im.fetchall())
            return im
        if not okuma:
            self.onbellegi_temizle()
        return self._calistir(sql, params, yazma=not okuma)

    def _calistir_ham(self, sql, params=()):
        """Çevrilmemiş PostgreSQL sorgusu (%s parametreli) – satırlar demet olarak döner."""
        with self._bkilit:
            if self.c is None:
                raise BaglantiYok("İnternet / bulut bağlantısı yok.")
            try:
                cur = self.c.cursor()
                cur.execute(sql, tuple(params))
                return [tuple(r) for r in cur.fetchall()]
            except Exception as e:
                if ag_hatasi_mi(e):
                    self._koptu(e)
                    raise BaglantiYok(str(e)[:150])
                raise

    def _calistir_ham_yaz(self, sql, params=()):
        """Çevrilmemiş PostgreSQL komutu (yönetim işleri için)."""
        with self._bkilit:
            if self.c is None:
                raise BaglantiYok("İnternet / bulut bağlantısı yok.")
            try:
                self.c.cursor().execute(sql, tuple(params)) if params else self.c.cursor().execute(sql)
            except Exception as e:
                if ag_hatasi_mi(e):
                    self._koptu(e)
                    raise BaglantiYok(str(e)[:150])
                raise
        self.onbellegi_temizle()

    def taze(self, sql, params=()):
        """Önbelleğe bakmadan doğrudan buluttan okur (kayıt öncesi kontroller için)."""
        return self._calistir(sql, params, yazma=False)

    def onbellegi_temizle(self):
        with self._kilit:
            self._nesil += 1
            self._onbellek = {}
        if self.ayna is not None:
            self.ayna.kirli = True

    # ---------------------------------------------------------------- işlem (hepsi ya da hiçbiri)
    def islem_baslat(self):
        self._bkilit.acquire()
        self._islemde += 1
        if self._islemde == 1:
            try:
                self._calistir("BEGIN", yazma=False)
            except Exception:
                self._islemde -= 1
                self._bkilit.release()
                raise

    def islem_bitir(self, basarili):
        try:
            if self._islemde == 1:
                try:
                    self._calistir("COMMIT" if basarili else "ROLLBACK", yazma=False)
                except Exception:
                    if basarili:
                        raise
        finally:
            self._islemde -= 1
            self._bkilit.release()
            self.onbellegi_temizle()

    # ---------------------------------------------------------------- arka plan izleyici
    def izlemeyi_baslat(self):
        if self._izleniyor:
            return
        self._izleniyor = True
        self._izleyici = threading.Thread(target=self._izle, daemon=True)
        self._izleyici.start()

    def _izle(self):
        son, saat_son = None, time.time()
        while not self._kapali:
            try:
                if self.c is None:
                    self._baglan()
                r = self._calistir("SELECT last_value, is_called FROM st_degisim", yazma=False).fetchone()
                deger = (r[0], r[1]) if r else None
                if son is None:
                    with self._kilit:
                        self._nesil += 1
                        self._onbellek = {}
                    if self.ayna is not None:
                        self.ayna.esitle(self)
                elif deger != son:
                    if self.ayna is not None:
                        self.ayna.esitle(self)
                    self._isit()
                son = deger
                self._dogrulama = time.time()
                if time.time() - saat_son > 600:
                    saat_son = time.time()
                    self._saat_ayarla()
            except Exception as e:
                if ag_hatasi_mi(e):
                    self.cevrimici = False
                    self.son_hata = str(e)[:200]
            time.sleep(self.IZLEME_SN)

    def _isit(self):
        """Başka bilgisayar veri değiştirdi: son kullanılan sorgular arka planda yeniden çekilir, sonra önbellek
        tek seferde değiştirilir (bu sırada ekranlar eski önbellekten hızlı açılmaya devam eder)."""
        with self._kilit:
            nesil = self._nesil
            anahtarlar = list(self._son_okumalar.keys())
        yeni = {}
        for sql, params in anahtarlar:
            if self._kapali:
                return
            try:
                yeni[(sql, params)] = (time.time(), self._calistir(sql, params, yazma=False).fetchall())
            except BaglantiYok:
                return
            except Exception:
                pass
        with self._kilit:
            if self._nesil == nesil:
                self._nesil += 1
                self._onbellek = yeni
            # nesil değiştiyse (bu bilgisayar yazdı) önbellek zaten temizlendi

    def executescript(self, sql):
        for parca in [p.strip() for p in sql.split(";") if p.strip()]:
            self._calistir(parca, yazma=True)

    def commit(self):
        pass  # autocommit; çok adımlı işler islem_baslat / islem_bitir ile yapılır

    def close(self):
        self._kapali = True
        if self.ayna is not None:
            try:
                self.ayna.diske_yaz()
            except Exception:
                pass
        try:
            with self._bkilit:
                if self.c is not None:
                    self.c.close()
        except Exception:
            pass


# ------------------------------------------------------------------ sipariş aynası (artımlı eşitleme)
AYNA_TABLOLARI = {  # tablo: birincil anahtar sütunları
    "siparisler": ("id",),
    "asama_durum": ("siparis_id", "asama"),
    "asama_veri": ("siparis_id", "asama", "alan"),
    "gemiler": ("id",),
    "etalar": ("id",),
}
AYNA_DIZI = {  # bu tablolar sütun adları olmadan dizi olarak indirilir
    "asama_durum": ("siparis_id", "asama", "durum", "guncelleyen_id", "zaman", "degisim"),
    "asama_veri": ("siparis_id", "asama", "alan", "deger", "giren_id", "giren_seviye", "zaman", "degisim"),
}
AYNA_PAYI = 150  # sayaç değeri; işlem sırası kayabileceği için son değişiklikler her eşitlemede yeniden alınır


class Ayna:
    """Sipariş, aşama, gemi ve ETA tablolarının bilgisayardaki kopyası.

    Her satırda 'degisim' (değişiklik sayacı) vardır. Eşitlemede yalnızca son eşitlemeden sonra değişen satırlar
    TEK sorguyla indirilir; böylece sipariş sayısı binleri bulsa da her yenilemede birkaç KB veri iner.
    Kopya diske de yazılır; program açılışında yalnızca aradaki değişiklikler indirilir."""

    def __init__(self, dosya=None):
        self.dosya = dosya
        self.kilit = threading.RLock()
        self.kirli = True
        self.surum = 0
        self._sifirla()
        self._diskten_oku()

    def _sifirla(self):
        self.tablolar = {t: {} for t in AYNA_TABLOLARI}
        self.son_islem = {}
        self.max_degisim = -1
        self.max_denetim = -1
        self.veri_nesli = None
        self.yuklu = False

    # ---------------------------------------------------------------- disk
    def _diskten_oku(self):
        if not self.dosya or not os.path.exists(self.dosya):
            return
        try:
            with open(self.dosya, "rb") as f:
                d = pickle.load(f)
            if d.get("surum") != 2:
                return
            self.tablolar, self.son_islem = d["tablolar"], d["son_islem"]
            self.max_degisim, self.max_denetim = d["max_degisim"], d["max_denetim"]
            self.veri_nesli, self.yuklu = d["veri_nesli"], True
        except Exception:
            self._sifirla()

    def diske_yaz(self):
        if not self.dosya or not self.yuklu:
            return
        with self.kilit:
            d = {"surum": 2, "tablolar": self.tablolar, "son_islem": self.son_islem, "max_degisim": self.max_degisim,
                 "max_denetim": self.max_denetim, "veri_nesli": self.veri_nesli}
            gecici = self.dosya + ".tmp"
            with open(gecici, "wb") as f:
                pickle.dump(d, f, protocol=pickle.HIGHEST_PROTOCOL)
            os.replace(gecici, self.dosya)
        self._son_disk = time.time()

    # ---------------------------------------------------------------- eşitleme
    def esitle(self, baglanti):
        """Değişen satırları indirir. Hata olursa (internet yok) eski kopya kullanılmaya devam eder."""
        with self.kilit:
            esik = max(-1, self.max_degisim - AYNA_PAYI) if self.yuklu else -1
            esik_d = max(-1, self.max_denetim - AYNA_PAYI) if self.yuklu else -1
            parcalar, params = [], []
            for t in AYNA_TABLOLARI:
                if t in AYNA_DIZI:  # çok satırlı tablolar: anahtarsız dizi (daha az veri iner)
                    parcalar.append("SELECT '%s' AS t, json_build_array(%s)::text AS j FROM %s WHERE degisim > %%s"
                                    % (t, ", ".join(AYNA_DIZI[t]), t))
                else:
                    parcalar.append("SELECT '%s' AS t, row_to_json(x)::text AS j FROM %s x WHERE degisim > %%s" % (t, t))
                params.append(esik)
            parcalar.append("SELECT 'denetim', json_build_array(id, siparis_id, zaman)::text FROM denetim WHERE id > %s")
            params.append(esik_d)
            parcalar.append("SELECT 'nesil', deger FROM meta WHERE anahtar = 'veri_nesli'")
            sql = " UNION ALL ".join(parcalar)
        satirlar = baglanti._calistir_ham(sql, params)
        with self.kilit:
            nesil = None
            for t, j in satirlar:
                if t == "nesil":
                    nesil = j
            if self.yuklu and nesil != self.veri_nesli:
                # veriler toptan değişti (geri yükleme / gemi birleştirme): baştan yükle
                self._sifirla()
                self.kirli = True
                return self.esitle(baglanti)
            degisti = False
            for t, j in satirlar:
                if t == "nesil":
                    continue
                r = json.loads(j)
                if t == "denetim":
                    did, ds, dz = r
                    if did > self.max_denetim:
                        self.max_denetim = did
                    if ds is not None and dz:
                        if dz > (self.son_islem.get(ds) or ""):
                            self.son_islem[ds] = dz
                            degisti = True
                    continue
                if t in AYNA_DIZI:
                    r = dict(zip(AYNA_DIZI[t], r))
                dg = r.pop("degisim", 0) or 0
                if dg > self.max_degisim:
                    self.max_degisim = dg
                anahtar = tuple(r[k] for k in AYNA_TABLOLARI[t])
                if self.tablolar[t].get(anahtar) != r:
                    self.tablolar[t][anahtar] = r
                    degisti = True
            self.veri_nesli = nesil
            self.yuklu = True
            self.kirli = False
            if degisti:
                self.surum += 1
        if time.time() - getattr(self, "_son_disk", 0) > 600:
            try:
                self.diske_yaz()
            except Exception:
                pass
        return True

    def hazirla(self, baglanti):
        """Okumadan önce: bu bilgisayar yazdıysa (kirli) değişiklikleri hemen al."""
        if self.kirli or not self.yuklu:
            try:
                self.esitle(baglanti)
            except BaglantiYok:
                if not self.yuklu:
                    raise


def _ayna_bagla(baglanti, klasor):
    """Bağlantıya sipariş aynasını ekler (bulut adresine özel dosya)."""
    import hashlib
    ad = hashlib.sha1(("%s|%s|%s" % (baglanti.ayar.get("host"), baglanti.ayar.get("port"),
                                     baglanti.ayar.get("database"))).encode("utf-8")).hexdigest()[:12]
    baglanti.ayna = Ayna(os.path.join(klasor, "ayna_%s.dat" % ad) if klasor else None)
    return baglanti.ayna


SEMA_SURUM = "5"  # tablolar veya tetikleyiciler değişince artırılır
UYG_ROL = "siparis_app"  # ekip bilgisayarlarının kullandığı kısıtlı veritabanı kullanıcısı

_TETIK_TABLOLARI = TABLOLAR + ["ek_dosyalar"]


def yetki_hatasi_mi(e):
    m = str(e).lower()
    return "42501" in m or "permission denied" in m or "must be owner" in m


def sema_kur(baglanti):
    """Tabloları, değişiklik sayacını ve satır sayaçlarını kurar. Kuruluysa yalnızca tek bir kontrol sorgusu çalışır.
    Kısıtlı kullanıcıyla (ekip bilgisayarı) bağlanıldıysa şema değiştirilemez; yönetici bilgisayarı günceller."""
    try:
        r = baglanti._calistir("SELECT deger FROM meta WHERE anahtar='pg_sema'", yazma=False).fetchone()
        if r and r[0] == SEMA_SURUM:
            return
    except BaglantiYok:
        raise
    except Exception:
        pass
    try:
        _sema_uygula(baglanti)
    except Exception as e:
        if yetki_hatasi_mi(e):
            return  # kısıtlı kullanıcı: şema yönetici bilgisayarından güncellenir
        raise
    baglanti.onbellegi_temizle()


def _sema_uygula(b):
    calis = lambda sql, p=(): b._calistir_ham_yaz(sql, p)  # noqa: E731
    for parca in [x.strip() for x in SEMA_PG.split(";") if x.strip()]:
        calis(parca)
    # değişiklik sayacı: her tabloda ekleme/güncelleme/silmede artar (bilgisayarlar bunu izler)
    calis("CREATE SEQUENCE IF NOT EXISTS st_degisim")
    calis("CREATE OR REPLACE FUNCTION st_degisim_art() RETURNS trigger LANGUAGE plpgsql AS "
          "$f$ BEGIN PERFORM nextval('st_degisim'); RETURN NULL; END $f$")
    calis("CREATE OR REPLACE FUNCTION st_satir_degisim() RETURNS trigger LANGUAGE plpgsql AS "
          "$f$ BEGIN NEW.degisim := nextval('st_degisim'); RETURN NEW; END $f$")
    for t in _TETIK_TABLOLARI:
        calis("DROP TRIGGER IF EXISTS st_degisim_t ON %s" % t)
        calis("CREATE TRIGGER st_degisim_t AFTER INSERT OR UPDATE OR DELETE OR TRUNCATE ON %s "
              "FOR EACH STATEMENT EXECUTE FUNCTION st_degisim_art()" % t)
    # satır sayacı: bilgisayarlar yalnızca değişen satırları indirir
    for t in AYNA_TABLOLARI:
        calis("ALTER TABLE %s ADD COLUMN IF NOT EXISTS degisim BIGINT NOT NULL DEFAULT 0" % t)
        calis("CREATE INDEX IF NOT EXISTS ix_%s_degisim ON %s (degisim)" % (t, t))
        calis("UPDATE %s SET degisim = nextval('st_degisim') WHERE degisim = 0" % t)
        calis("DROP TRIGGER IF EXISTS st_satir_t ON %s" % t)
        calis("CREATE TRIGGER st_satir_t BEFORE INSERT OR UPDATE ON %s FOR EACH ROW EXECUTE FUNCTION st_satir_degisim()" % t)
    calis("CREATE INDEX IF NOT EXISTS ix_gemiler_imo ON gemiler (imo)")
    for sutun in ("fiyat", "depoda", "tedarik_sekli"):  # 1.9.2 · 1.9.9
        calis("ALTER TABLE satirlar ADD COLUMN IF NOT EXISTS %s TEXT" % sutun)
    calis("INSERT INTO meta (anahtar, deger) VALUES ('veri_nesli', %s) ON CONFLICT (anahtar) DO NOTHING",
          (_rastgele(),))
    if rol_var_mi(b):
        yetkileri_ver(b)
    calis("INSERT INTO meta (anahtar, deger) VALUES ('pg_sema', %s) ON CONFLICT (anahtar) DO UPDATE SET deger=excluded.deger",
          (SEMA_SURUM,))


def _rastgele():
    import secrets
    return secrets.token_hex(8)


def veri_nesli_yenile(b):
    """Veriler toptan değişti (geri yükleme, gemi birleştirme): bütün bilgisayarlar aynalarını baştan yükler."""
    b._calistir_ham_yaz("INSERT INTO meta (anahtar, deger) VALUES ('veri_nesli', %s) "
                        "ON CONFLICT (anahtar) DO UPDATE SET deger=excluded.deger", (_rastgele(),))
    b.onbellegi_temizle()


# ------------------------------------------------------------------ kısıtlı ekip kullanıcısı
def rol_var_mi(b):
    return bool(b._calistir_ham("SELECT 1 FROM pg_roles WHERE rolname=%s", (UYG_ROL,)))


def yetkileri_ver(b):
    """Ekip kullanıcısı: okuyabilir, ekleyebilir, güncelleyebilir. Tablo silemez/değiştiremez; işlem geçmişini
    (denetim) değiştiremez ve silemez; sipariş, kullanıcı, aşama verisi kalıcı olarak silinemez."""
    calis = lambda sql: b._calistir_ham_yaz(sql, ())  # noqa: E731
    calis("GRANT USAGE ON SCHEMA public TO %s" % UYG_ROL)
    calis("REVOKE ALL ON ALL TABLES IN SCHEMA public FROM %s" % UYG_ROL)
    calis("GRANT SELECT, INSERT, UPDATE ON kullanicilar, siparisler, asama_durum, asama_veri, satirlar, ekler, "
          "ek_dosyalar, gemiler, etalar, meta, okundu TO %s" % UYG_ROL)
    calis("GRANT DELETE ON gemiler TO %s" % UYG_ROL)  # yinelenen gemi kaydı birleştirme
    calis("GRANT SELECT, INSERT ON denetim TO %s" % UYG_ROL)
    calis("GRANT UPDATE (gemi_id) ON denetim TO %s" % UYG_ROL)
    calis("GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO %s" % UYG_ROL)


def rol_olustur(b):
    """Kısıtlı ekip kullanıcısını oluşturur (ya da şifresini yeniler). Yeni şifreyi döner."""
    import secrets
    sifre = secrets.token_urlsafe(24).replace("-", "a").replace("_", "b")
    if rol_var_mi(b):
        b._calistir_ham_yaz("ALTER ROLE %s WITH LOGIN PASSWORD '%s'" % (UYG_ROL, sifre), ())
    else:
        b._calistir_ham_yaz("CREATE ROLE %s WITH LOGIN PASSWORD '%s'" % (UYG_ROL, sifre), ())
    yetkileri_ver(b)
    return sifre


def rol_kullanici_adi(yonetici_kullanici):
    """Supabase havuz adresinde kullanıcı adı 'rol.proje' biçimindedir (postgres.abcd -> siparis_app.abcd)."""
    if "." in yonetici_kullanici:
        return UYG_ROL + "." + yonetici_kullanici.split(".", 1)[1]
    return UYG_ROL


def yonetici_mi(b):
    """Bu bağlantı şemayı değiştirebilen (yönetici) kullanıcı mı?"""
    try:
        r = b._calistir_ham("SELECT rolname = %s FROM pg_roles WHERE rolname = current_user", (UYG_ROL,))
        return not (r and r[0][0])
    except Exception:
        return True


def tablolari_kopyala(kaynak, hedef, log=print):
    """Bütün tabloları kaynaktan hedefe kopyalar (hedefteki eski kayıtlar silinir). SERIAL sayaçları ayarlanır."""
    bulut_hedef = getattr(hedef, "bulut", False)
    if bulut_hedef:
        hedef.islem_baslat()  # yarıda kesilirse hiçbir şey değişmez
    basarili = False
    try:
        _kopyala(kaynak, hedef, bulut_hedef, log)
        if bulut_hedef:
            veri_nesli_yenile(hedef)
        basarili = True
    finally:
        if bulut_hedef:
            hedef.islem_bitir(basarili)


def _kopyala(kaynak, hedef, bulut_hedef, log):
    for t in reversed(TABLOLAR):
        hedef.execute("DELETE FROM %s" % t)
    for t in TABLOLAR:
        try:
            satirlar = [dict(r) for r in kaynak.execute("SELECT * FROM %s" % t)]
        except Exception:
            satirlar = []
        if not satirlar:
            continue
        for r in satirlar:
            r.pop("degisim", None)  # bulut satır sayacı (yerelde yok, bulutta kendisi verilir)
        sutunlar = list(satirlar[0].keys())
        sql = "INSERT INTO %s (%s) VALUES (%s)" % (t, ", ".join(sutunlar), ", ".join("?" * len(sutunlar)))
        for r in satirlar:
            hedef.execute(sql + (" RETURNING 1" if bulut_hedef and t in ID_TABLOLARI else ""),
                          [r[c] for c in sutunlar])
        log("   %s: %d kayıt" % (t, len(satirlar)))
        if bulut_hedef and t in ID_TABLOLARI:
            hedef.execute("SELECT setval(pg_get_serial_sequence('%s', 'id'), COALESCE((SELECT MAX(id) FROM %s), 0) + 1, false)"
                          % (t, t))
