# -*- coding: utf-8 -*-
"""Sipariş ve Gemi Takip – Oto Kurulum (bu dosya .exe'ye dönüştürülür).

Yeni bilgisayarda çift tıklanınca:
  1) Python 3.10+ var mı bakar; yoksa python.org'dan Python 3.12'yi indirip sessizce kurar (yönetici izni gerekmez)
  2) Gerekli kütüphaneleri kurar: openpyxl (Excel), requests (internet), pywin32 (masaüstü kısayolu), pillow (fotoğraf küçültme)
  3) Program dosyalarını kurulum klasörüne açar (varsa veriler ve ayarlar korunur)
  4) Masaüstüne simgeli kısayol oluşturur ve programı başlatır
Program açılınca GitHub'dan en son sürümü kendisi denetler.
"""
import glob
import json
import os
import queue
import shutil
import subprocess
import sys
import tempfile
import threading
import urllib.request
import zipfile
import tkinter as tk
from tkinter import ttk, messagebox

PYTHON_URL = "https://www.python.org/ftp/python/3.12.7/python-3.12.7-amd64.exe"
KUTUPHANELER = ["pg8000", "openpyxl", "requests", "pywin32", "pillow", "pystray"]
GIZLI = 0x08000000 if sys.platform.startswith("win") else 0  # CREATE_NO_WINDOW


def sifre_sakla(metin):
    """Şifreyi bu bilgisayarın Windows hesabına bağlı olarak şifreler (programdaki ile aynı biçim)."""
    import base64
    if not metin:
        return ""
    try:
        import ctypes
        from ctypes import wintypes

        class BLOB(ctypes.Structure):
            _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]
        veri = metin.encode("utf-8")
        giris = BLOB(len(veri), ctypes.cast(ctypes.create_string_buffer(veri, len(veri)), ctypes.POINTER(ctypes.c_char)))
        cikis = BLOB()
        if not ctypes.windll.crypt32.CryptProtectData(ctypes.byref(giris), None, None, None, None, 0, ctypes.byref(cikis)):
            raise OSError
        sonuc = ctypes.string_at(cikis.pbData, cikis.cbData)
        ctypes.windll.kernel32.LocalFree(cikis.pbData)
        return "dp:" + base64.b64encode(sonuc).decode()
    except Exception:
        return "b6:" + base64.b64encode(metin.encode("utf-8")).decode()


def kaynak(ad):
    taban = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(taban, ad)


def bilgi_oku():
    try:
        with open(kaynak("kurulum_bilgi.json"), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def calistir(komut, log=None, zaman_asimi=1800):
    p = subprocess.Popen(komut, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, creationflags=GIZLI,
                         text=True, encoding="utf-8", errors="replace")
    cikti = []
    for satir in p.stdout:
        satir = satir.rstrip()
        cikti.append(satir)
        if log and satir and not satir.startswith(("  ", "Requirement already")):
            log("   " + satir[:110])
    p.wait(timeout=zaman_asimi)
    return p.returncode, "\n".join(cikti)


def python_surumu(exe):
    try:
        r = subprocess.run([exe, "-c", "import sys, tkinter; print('%d.%d' % sys.version_info[:2]); print(sys.executable)"],
                           capture_output=True, text=True, timeout=60, creationflags=GIZLI)
        if r.returncode == 0:
            s, yol = r.stdout.strip().splitlines()[:2]
            maj, mn = (int(x) for x in s.split("."))
            if (maj, mn) >= (3, 10):
                return yol
    except Exception:
        pass
    return None


def python_bul():
    adaylar = []
    for kom in (["py", "-3.12"], ["py", "-3"], ["python"]):
        try:
            r = subprocess.run(kom + ["-c", "import sys; print(sys.executable)"], capture_output=True, text=True,
                               timeout=60, creationflags=GIZLI)
            if r.returncode == 0 and r.stdout.strip():
                adaylar.append(r.stdout.strip().splitlines()[0])
        except Exception:
            pass
    yerel = os.environ.get("LOCALAPPDATA", "")
    for desen in (os.path.join(yerel, "Programs", "Python", "Python3*", "python.exe"),
                  r"C:\Program Files\Python3*\python.exe", r"C:\Python3*\python.exe"):
        adaylar += sorted(glob.glob(desen), reverse=True)
    for a in adaylar:
        if "WindowsApps" in a:  # Microsoft Store kısayolu, gerçek Python değil
            continue
        yol = python_surumu(a)
        if yol:
            return yol
    return None


class Kurulum:
    def __init__(self):
        self.bilgi = bilgi_oku()
        self.q = queue.Queue()
        self.r = tk.Tk()
        self.r.title("Sipariş ve Gemi Takip – Kurulum")
        self.r.geometry("640x500")
        self.r.configure(bg="#FFFFFF")
        try:
            self.r.iconbitmap(kaynak("simge.ico"))
        except Exception:
            pass
        tk.Label(self.r, text="Sipariş ve Gemi Takip", bg="#0E2335", fg="#FFFFFF", font=("Segoe UI", 15, "bold"),
                 anchor="w", padx=18, pady=12).pack(fill="x")
        hedef = os.path.expandvars(self.bilgi.get("kurulum_klasoru") or r"%USERPROFILE%\SiparisGemiTakip")
        tk.Label(self.r, text="Sürüm %s kurulacak.\nKurulum klasörü:" % self.bilgi.get("surum", "?"), bg="#FFFFFF",
                 justify="left", font=("Segoe UI", 10)).pack(anchor="w", padx=18, pady=(12, 0))
        self.v_hedef = tk.StringVar(value=hedef)
        f = tk.Frame(self.r, bg="#FFFFFF")
        f.pack(fill="x", padx=18)
        ttk.Entry(f, textvariable=self.v_hedef).pack(side="left", fill="x", expand=True)
        self.pb = ttk.Progressbar(self.r, mode="determinate", maximum=5)
        self.pb.pack(fill="x", padx=18, pady=10)
        self.t = tk.Text(self.r, height=14, font=("Consolas", 9), bg="#F5F7F9", relief="flat")
        self.t.pack(fill="both", expand=True, padx=18)
        alt = tk.Frame(self.r, bg="#FFFFFF")
        alt.pack(fill="x", padx=18, pady=12)
        self.b_kur = ttk.Button(alt, text="Kur", command=self.baslat)
        self.b_kur.pack(side="right")
        self.b_kapat = ttk.Button(alt, text="Kapat", command=self.r.destroy)
        self.b_kapat.pack(side="right", padx=8)
        self.log("Gerekli olanlar otomatik kurulur: Python 3.12 (yoksa), pg8000, openpyxl, requests, pywin32, pillow.")
        self.log("İnternet bağlantısı gerekir. 'Kur' düğmesine basın.")
        self.r.after(200, self._kuyruk)

    def log(self, m):
        self.q.put(("log", m))

    def _kuyruk(self):
        try:
            while True:
                tur, m = self.q.get_nowait()
                if tur == "log":
                    self.t.insert("end", m + "\n")
                    self.t.see("end")
                elif tur == "adim":
                    self.pb["value"] = m
                elif tur == "bitti":
                    self.b_kapat.state(["!disabled"])
                    if m:
                        messagebox.showinfo("Kurulum tamam", "Program kuruldu ve açılıyor.\nMasaüstündeki 'Sipariş ve Gemi Takip' "
                                                             "kısayoluyla da açabilirsiniz.")
                        self.r.destroy()
                        return
                    self.b_kur.state(["!disabled"])
        except queue.Empty:
            pass
        self.r.after(150, self._kuyruk)

    def baslat(self):
        self.b_kur.state(["disabled"])
        self.b_kapat.state(["disabled"])
        threading.Thread(target=self._kur, daemon=True).start()

    def _kur(self):
        try:
            self.q.put(("bitti", self.kur(self.v_hedef.get().strip())))
        except Exception as e:
            self.log("\n✖ HATA: %s" % e)
            self.log("Kurulum tamamlanamadı. Bu pencerenin ekran görüntüsünü gönderin.")
            self.q.put(("bitti", False))

    def kur(self, hedef):
        # 1) Python
        self.log("\n[1/5] Python denetleniyor…")
        py = python_bul()
        if py:
            self.log("   ✔ Python bulundu: %s" % py)
        else:
            self.log("   Python yok, indiriliyor (yaklaşık 25 MB)…")
            kur_exe = os.path.join(tempfile.gettempdir(), "python-3.12.7-amd64.exe")
            urllib.request.urlretrieve(PYTHON_URL, kur_exe)
            self.log("   Python kuruluyor (birkaç dakika sürebilir)…")
            kod, _ = calistir([kur_exe, "/quiet", "InstallAllUsers=0", "PrependPath=1", "Include_launcher=1",
                               "Include_tcltk=1", "Include_pip=1", "Include_test=0", "Shortcuts=0"])
            py = python_bul()
            if not py:
                raise RuntimeError("Python kurulamadı (kod %s). python.org'dan Python 3.12'yi elle kurup tekrar deneyin." % kod)
            self.log("   ✔ Python kuruldu: %s" % py)
        self.q.put(("adim", 1))

        # 2) Kütüphaneler
        self.log("\n[2/5] Kütüphaneler kuruluyor…")
        calistir([py, "-m", "pip", "install", "--upgrade", "--disable-pip-version-check", "pip"])
        for kut in KUTUPHANELER:
            kod, cikti = calistir([py, "-m", "pip", "install", "--disable-pip-version-check", "--upgrade", kut])
            self.log(("   ✔ %s" if kod == 0 else "   ⚠ %s kurulamadı (program yine de çalışır)") % kut)
        self.q.put(("adim", 2))

        # 3) Program dosyaları
        self.log("\n[3/5] Program dosyaları kuruluyor: %s" % hedef)
        os.makedirs(hedef, exist_ok=True)
        with zipfile.ZipFile(kaynak("program.zip")) as z:
            for ad in z.namelist():
                if ad.endswith("/") or ".." in ad or ad.startswith("/"):
                    continue
                z.extract(ad, hedef)
        shutil.rmtree(os.path.join(hedef, "__pycache__"), ignore_errors=True)
        ayar_yolu = os.path.join(hedef, "ayarlar.json")
        try:
            with open(ayar_yolu, encoding="utf-8") as f:
                ayar = json.load(f)
        except (OSError, ValueError):
            ayar = {}
        if self.bilgi.get("veri_klasoru") and not ayar.get("veri_klasoru"):
            ayar["veri_klasoru"] = self.bilgi["veri_klasoru"]
            self.log("   Ortak veri klasörü: %s" % self.bilgi["veri_klasoru"])
        b = self.bilgi.get("bulut")
        if b and b.get("uri"):
            ayar["bulut"] = {"uri": b["uri"], "sifre": sifre_sakla(b.get("sifre", ""))}
            self.log("   Ortak bulut veritabanına bağlanacak (kullanıcı adınızla giriş yapın)")
        ayar["kisayol_soruldu"] = True
        with open(ayar_yolu, "w", encoding="utf-8") as f:
            json.dump(ayar, f, ensure_ascii=False, indent=2)
        self.log("   ✔ Dosyalar kuruldu (varsa eski veriler ve ayarlar korundu)")
        self.q.put(("adim", 3))

        # 4) Kısayol
        self.log("\n[4/5] Masaüstü kısayolu oluşturuluyor…")
        kod, cikti = calistir([py, "-c", "import sys; sys.path.insert(0, r'%s'); import st_kisayol as k; ok, m = "
                                          "k.kisayol_olustur(); print('TAMAM' if ok else 'HATA:' + m)" % hedef])
        if "TAMAM" in cikti:
            self.log("   ✔ Masaüstüne 'Sipariş ve Gemi Takip' kısayolu eklendi")
        else:
            self.log("   ⚠ Kısayol oluşturulamadı. Programı şuradan açın: %s\\siparis_takip.pyw" % hedef)
        self.q.put(("adim", 4))

        # 5) Başlat
        self.log("\n[5/5] Program başlatılıyor…")
        pw = os.path.join(os.path.dirname(py), "pythonw.exe")
        subprocess.Popen([pw if os.path.exists(pw) else py, os.path.join(hedef, "siparis_takip.pyw")], cwd=hedef,
                         creationflags=GIZLI)
        self.q.put(("adim", 5))
        self.log("   ✔ Kurulum tamamlandı.")
        return True


if __name__ == "__main__":
    Kurulum().r.mainloop()
