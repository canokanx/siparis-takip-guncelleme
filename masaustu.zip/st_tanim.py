# -*- coding: utf-8 -*-
"""Sipariş ve Gemi Takip - sabit tanımlar (roller, departmanlar, aşamalar, alanlar)."""

PROGRAM_ADI = "Sipariş ve Gemi Takip"
SURUM = "2.0.1"

# ---- Roller ve görünürlük seviyeleri ----
# Kural: herkes kendi seviyesindeki ve altındaki kişilerin girdiği bilgiyi görür.
ROLLER = {"kullanici": "Kullanıcı", "yonetici": "Yönetici", "ust": "Üst Yönetici"}
SEVIYE = {"kullanici": 1, "yonetici": 2, "ust": 3}
SEVIYE_ADI = {1: "Kullanıcı", 2: "Yönetici", 3: "Üst Yönetici"}

DEPARTMANLAR = {
    "satinalma": "Satın Alma",
    "depo": "Depo",
    "operasyon": "Operasyon",
    "evrak": "Evrak",
    "finans": "Finans",
    "yonetim": "Yönetim",
}

# ---- Aşama durumları ----
DURUM = {
    "todo": "Başlanmadı",
    "prog": "Devam ediyor",
    "done": "Tamamlandı",
    "na": "Pasif",
}

# Renkler (arka plan, yazı, kenar)
RENK = {
    "done": ("#DDF0E4", "#17603A", "#2E9E5B"),
    "prog": ("#FFF2C4", "#6B4E00", "#E0A800"),
    "todo": ("#FBE3E1", "#9E2A21", "#D64538"),
    "na": ("#ECEEF1", "#4E5663", "#9AA1AC"),
    "high": ("#FFE6CC", "#8A4300", "#E07B00"),
    "info": ("#E1ECF7", "#1F4E79", "#3E7CB8"),
}
ONCELIK_RENK = {"Kritik": "todo", "Yüksek": "high", "Normal": "info", "Bilgi": "na"}

# Genel arayüz renkleri
LACIVERT = "#0E2335"
VURGU = "#1F5F8B"
ZEMIN = "#EEF1F4"
KART = "#FFFFFF"
CIZGI = "#D5DBE2"
YAZI = "#14202B"
SOLUK = "#55606E"

# ---- Seçim listeleri ----
PARA_BIRIMLERI = ["USD", "EUR", "TRY", "GBP"]
EVET_HAYIR = ["Evet", "Hayır"]
DEPO_DURUMLARI = ["Malzeme planlanıyor", "Malzeme toplanıyor", "Termin bekleniyor",
                  "Kısmen hazır", "Hazır (sevke hazır)", "Eksik / aksaklık var"]
TOPLAMA_DURUMLARI = ["Bekliyor", "Toplanıyor", "Tamamlandı", "Tedarik bekliyor", "Eksik", "Muadil önerildi"]  # 1.9.5 öncesi
# 1.9.5: depo her kalem için bunlardan birini işaretler (eski değerler st_mantik.kalem_durumu ile eşlenir)
DEPO_KALEM_DURUMLARI = ["Bekleniyor", "Geldi – hazırlanıyor", "Geldi – hazır", "Eksik / gelmedi", "Muadil önerildi"]
SEVK_SEKILLERI = ["Kara yolu", "Kurye", "Ambar", "Deniz motoru / tekne", "Elden teslim", "Diğer"]
GIRIS_IZNI = ["Gerekli değil", "Alındı", "Bekleniyor"]
EVRAK_KONTROL = ["Hazırlanıyor", "Kontrolde", "Tamamlandı", "Revizyon gerekli"]
TAHSILAT = ["Talep edilmedi", "Ödeme bekleniyor", "Kısmi ödeme", "Ödendi", "Gecikmiş"]
ISLEM_TURU = ["İade", "Değişim", "Sipariş iptali"]

BOLGELER = ["Zeyport", "Yalova", "Sarayburnu", "Tuzla", "Desan", "Tersan / Yalova",
            "Ambarlı", "Haydarpaşa", "Samsun", "Boğaz yaklaşımı", "Yurt dışı", "Belirsiz"]
OPERASYON_DURUMLARI = ["Teknik malzeme", "Kumanya", "Teknik malzeme + Kumanya", "Sözlü beyan"]
HAREKET_DURUMLARI = ["Bilinmiyor", "Yaklaşıyor", "Demirde", "Yanaştı", "Boğaz geçiş planında",
                     "Boğaz geçişi yaptı", "Ayrıldı"]

# ---- Aşama tanımları ----
# Alan: (anahtar, etiket, zorunlu, tür, seçenekler)
# tür: metin, tarih (gg.aa.yyyy), tarihsaat (gg.aa.yyyy ss:dd), saataraligi (ss:dd - ss:dd), sayi, secim, uzun
#
# "n" aşamanın KALICI kimliğidir (veritabanında bu numara saklanır, değişmez). Ekranda görünen sıra numarası
# "sira"dır. 1.9.0'da araya "Depoya Sevkiyat" (n=7) eklendi, "Sevkiyat & Tahsilat" ikiye ayrıldı:
# "Gemiye Sevkiyat" (n=5) ve "Tahsilat" (n=8). Böylece eski kayıtlar ve eski sürümler bozulmaz.
# Depoya Sevkiyat: her kalem için Alınacak (tedarikçiden biz alıyoruz) · Gönderilecek (tedarikçi depoya gönderiyor)
TEDARIK_SEKILLERI = ["Alınacak", "Gönderilecek"]
SEKME_GIZLI = {}  # sekme çubuklu formlarda sekmeye göre gizlenen alanlar (şu an kullanılmıyor)
TEDARIK_DURUMLARI = ["Hazırlanıyor", "Yolda", "Depoya ulaştı", "Kısmen ulaştı", "Gecikme var"]
GEMI_TESLIM = ["Planlandı", "Yolda", "Gemiye teslim edildi", "Kısmi teslim", "Teslim edilemedi"]
ASAMALAR = [
    {
        "n": 1, "kisa": "Sipariş Kaydı", "uzun": "Siparişin alınması ve sisteme kaydedilmesi",
        "dept": "satinalma",
        "alanlar": [
            ("siparis_tarihi", "Sipariş tarihi", True, "tarih", None),
            ("musteri", "Müşteri / Firma", True, "metin", None),
            ("gemi", "Gemi adı", True, "metin", None),
            ("imo", "IMO numarası", False, "metin", None),
            ("acente", "İlgili acente", False, "metin", None),
            ("siparisi_alan", "Siparişi alan", True, "metin", None),
            ("satis_tutari", "Satış tutarı", True, "sayi", None),
            ("para_birimi", "Para birimi", True, "secim", PARA_BIRIMLERI),
            ("maliyet", "Alış / tedarik maliyeti", False, "sayi", None),
            ("odeme_kosulu", "Ödeme koşulları", False, "metin", None),
            ("komisyon", "Acente komisyonu var mı?", True, "secim", EVET_HAYIR),
            ("komisyon_orani", "Komisyon oranı / tutarı", False, "metin", None),
            ("termin", "Beklenen temin (termin) tarihi", True, "tarih", None),
            ("kritik", "Kritik / öncelikli ürün var mı?", False, "secim", EVET_HAYIR),
            ("aciklama", "Açıklama", False, "uzun", None),
        ],
    },
    {
        "n": 7, "kisa": "Depoya Sevkiyat", "uzun": "Ürünlerin tedarikçiden depoya getirilmesi",
        "dept": "satinalma",
        "alanlar": [
            # 1.9.9: sade form – alınacak / gönderilecek ayrımı kalem bazında (malzeme listesinde) yapılır
            ("tahmini_varis", "Depoya tahmini varış (tarih / saat)", False, "tarihsaat", None),
            ("depoya_varis", "Depoya varış (tarih / saat)", False, "tarihsaat", None),
            ("depoda_teslim_alan", "Depoda teslim alan", False, "metin", None),
            ("tedarik_notu", "Açıklama / eksik ürün notu", False, "uzun", None),
        ],
    },
    {
        "n": 2, "kisa": "Depo & Paketleme", "uzun": "Ürünlerin toplanması, kontrolü ve paketlenmesi",
        "dept": "depo",
        "alanlar": [
            ("depo_durumu", "Genel depo durumu", True, "secim", DEPO_DURUMLARI),
            ("paketleme_tarihi", "Paketleme tarihi", True, "tarih", None),
            ("paketleyen", "Paketleyen personel", True, "metin", None),
            ("kap", "KAP adedi", True, "sayi", None),
            ("brut", "Brüt ağırlık (kg)", True, "sayi", None),
            ("net", "Net ağırlık (kg)", False, "sayi", None),
            ("olcu", "Paket ölçüleri", False, "metin", None),
            ("sevke_hazir", "Sevke hazır tarih / saat", True, "tarihsaat", None),
            ("gecikme_aciklama", "Gecikme açıklaması", False, "metin", None),
            ("depo_notu", "Operasyona not", False, "uzun", None),
        ],
    },
    {
        "n": 3, "kisa": "Operasyon", "uzun": "Gemiye sevkiyatın planlanması ve saha organizasyonu",
        "dept": "operasyon",
        "alanlar": [
            ("sevk_tarihi", "Planlanan sevk tarihi", True, "tarih", None),
            ("saat_araligi", "Saat aralığı", False, "saataraligi", None),
            ("teslim_noktasi", "Teslim noktası (liman / rıhtım / konum)", True, "metin", None),
            ("sevk_sekli", "Sevk şekli", True, "secim", SEVK_SEKILLERI),
            ("gorevli", "Görevli personel ve iletişim", True, "metin", None),
            ("arac", "Araç tipi / plaka / sürücü", True, "metin", None),
            ("giris_izni", "Liman / tesis giriş izni", True, "secim", GIRIS_IZNI),
            ("nakliye_firmasi", "Nakliye firması", False, "metin", None),
            ("tasima_bedeli", "Taşıma bedeli ve ek masraf", False, "metin", None),
            ("talimat", "Operasyon talimatı / özel koşul", False, "uzun", None),
            ("teslim_teyidi", "Teslimat teyidi", True, "metin", None),
        ],
    },
    {
        "n": 4, "kisa": "Evrak", "uzun": "Sevkiyat ve teslimat evraklarının hazırlanması",
        "dept": "evrak",
        "alanlar": [
            ("evrak_turu", "Evrak türü", True, "metin", None),
            ("evrak_no", "Evrak numarası", True, "metin", None),
            ("duzenleme_tarihi", "Düzenleme tarihi", True, "tarih", None),
            ("duzenleyen", "Düzenleyen", True, "metin", None),
            ("ilgili_firma", "İlgili firma", False, "metin", None),
            ("toplam_kap", "Toplam KAP", True, "sayi", None),
            ("brut", "Brüt ağırlık (kg)", True, "sayi", None),
            ("net", "Net ağırlık (kg)", False, "sayi", None),
            ("hacim", "Hacim (m³)", False, "sayi", None),
            ("kontrol", "Kontrol durumu", True, "secim", EVRAK_KONTROL),
            ("evrak_notu", "Eksik belge notu", False, "uzun", None),
        ],
    },
    {
        "n": 5, "kisa": "Gemiye Sevkiyat", "uzun": "Ürünlerin gemiye teslim edilmesi",
        "dept": "operasyon",
        "alanlar": [
            ("sevk_zamani", "Sevkiyatın gerçekleştiği tarih / saat", True, "tarihsaat", None),
            ("gemi_teslim_durumu", "Teslim durumu", True, "secim", GEMI_TESLIM),
            ("teslim_alan", "Teslim alan kişi / kurum", True, "metin", None),
            ("teslim_teyidi", "Teslim teyidi (imza / foto / e-posta)", True, "metin", None),
            ("teslim_edilen_kap", "Teslim edilen KAP", False, "sayi", None),
            ("sevkiyat_notu", "Sevkiyat notu / eksik teslim", False, "uzun", None),
        ],
    },
    {
        "n": 8, "kisa": "Tahsilat", "uzun": "Faturalama ve ödemenin tahsil edilmesi",
        "dept": "finans",
        "alanlar": [
            ("talep_tarihi", "Ödeme talep tarihi", True, "tarih", None),
            ("talep_tutari", "Talep edilen tutar", True, "sayi", None),
            ("fatura_no", "Fatura no", False, "metin", None),
            ("fatura_tarihi", "Fatura tarihi", False, "tarih", None),
            ("tahsilat_durumu", "Tahsilat durumu", True, "secim", TAHSILAT),
            ("tahsil_edilen", "Tahsil edilen tutar", True, "sayi", None),
            ("tahsil_tarihi", "Tahsilat tarihi", True, "tarih", None),
            ("odeme_yontemi", "Ödeme yöntemi", False, "metin", None),
            ("finans_notu", "Finansal açıklama", False, "uzun", None),
        ],
    },
    {
        "n": 6, "kisa": "İade / İptal", "uzun": "İade, değişim veya sipariş iptali (opsiyonel)",
        "dept": "yonetici",  # yalnızca Yönetici ve Üst Yönetici
        "alanlar": [
            ("islem_turu", "İşlem türü", True, "secim", ISLEM_TURU),
            ("neden", "İşlem nedeni", True, "metin", None),
            ("talep_tarihi", "Talep tarihi", True, "tarih", None),
            ("talep_eden", "Talebi oluşturan", True, "metin", None),
            ("etkilenen", "Etkilenen ürün(ler) ve miktar", True, "metin", None),
            ("yeni_urun", "Yeni ürün / termin (değişimde)", False, "metin", None),
            ("mutabakat", "Müşteri / tedarikçi mutabakatı", False, "metin", None),
            ("onaylayan", "Onaylayan yönetici", True, "metin", None),
            ("finansal_etki", "Finansal etki (iade tutarı, mahsup…)", False, "metin", None),
            ("iade_notu", "Açıklama", False, "uzun", None),
        ],
    },
]
for _i, _a in enumerate(ASAMALAR, 1):
    _a["sira"] = _i

SIRA_IDLER = [a["n"] for a in ASAMALAR]          # ekrandaki sıra: 1, 7, 2, 3, 4, 5, 8, 6
IADE = 6
AKIS_IDLER = [n for n in SIRA_IDLER if n != IADE]  # normal iş akışı (İade hariç)
TAHSILAT_ALANLARI = ("talep_tarihi", "talep_tutari", "fatura_no", "fatura_tarihi", "tahsilat_durumu",
                     "tahsil_edilen", "tahsil_tarihi", "odeme_yontemi", "finans_notu")


def asama_no(n):
    """Aşamanın ekranda görünen sıra numarası (kimlik değil)."""
    try:
        return ASAMA[int(n)]["sira"]
    except (KeyError, ValueError, TypeError):
        return n


ASAMA = {a["n"]: a for a in ASAMALAR}


def alan_tanimi(asama, anahtar):
    for a in ASAMA[asama]["alanlar"]:
        if a[0] == anahtar:
            return a
    return None


# ---- Türkçe yardımcılar ----
def tr_upper(s):
    return (s or "").replace("i", "İ").replace("ı", "I").upper()


def tr_lower(s):
    return (s or "").replace("İ", "i").replace("I", "ı").lower()


def gemi_anahtar(ad):
    """Gemi adını karşılaştırma için normalleştirir.
    Gemi adları genelde İngilizce olduğu için i -> I (İ değil) çevrilir."""
    return " ".join((ad or "").upper().replace("İ", "I").split())
