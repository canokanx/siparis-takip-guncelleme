# -*- coding: utf-8 -*-
"""Programcı işleri: GitHub üzerinden güncelleme yayınlama / kurma ve internete otomatik yedek.

- Güncellemeler HERKESE AÇIK bir depoya yüklenir (surum.json + masaustu.zip); ekipteki programlar
  açılışta kontrol eder, yeni sürüm varsa sorup kurar ve kendini yeniden başlatır.
- Yedekler GİZLİ bir depoya yüklenir (veritabanı + ekler, zip). Son 30 yedek tutulur.
- GitHub token'ı bu bilgisayarda Windows'a bağlı olarak şifrelenir (DPAPI); başka bilgisayarda açılamaz.
Ek kütüphane gerekmez.
"""
import base64
import datetime as dt
import io
import json
import os
import re
import shutil
import sqlite3
import sys
import tempfile
import urllib.error
import urllib.request
import zipfile

PROGRAM_KLASORU = os.path.dirname(os.path.abspath(__file__))
API = "https://api.github.com"
UA = "SiparisGemiTakip"
PAKET_UZANTI = (".py", ".pyw", ".txt", ".ico")
PAKET_HARIC = ("ayarlar.json", "hata_kaydi.txt", "yuklu_surum.txt")
YEDEK_KLASORU = "yedekler"
TUTULACAK_YEDEK = 30
BEKLEYEN_GERI_YUKLEME = "geri_yukle_bekleyen.zip"


# ====================================================================== token saklama (Windows DPAPI)
def _dpapi(veri, coz=False):
    import ctypes
    from ctypes import wintypes

    class BLOB(ctypes.Structure):
        _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]
    giris = BLOB(len(veri), ctypes.cast(ctypes.create_string_buffer(veri, len(veri)), ctypes.POINTER(ctypes.c_char)))
    cikis = BLOB()
    fn = ctypes.windll.crypt32.CryptUnprotectData if coz else ctypes.windll.crypt32.CryptProtectData
    if not fn(ctypes.byref(giris), None, None, None, None, 0, ctypes.byref(cikis)):
        raise OSError("DPAPI hatası")
    sonuc = ctypes.string_at(cikis.pbData, cikis.cbData)
    ctypes.windll.kernel32.LocalFree(cikis.pbData)
    return sonuc


def sifre_sakla(metin):
    if not metin:
        return ""
    try:
        return "dp:" + base64.b64encode(_dpapi(metin.encode("utf-8"))).decode()
    except Exception:
        return "b6:" + base64.b64encode(metin.encode("utf-8")).decode()


def sifre_coz(saklanan):
    if not saklanan:
        return ""
    try:
        if saklanan.startswith("dp:"):
            return _dpapi(base64.b64decode(saklanan[3:]), coz=True).decode("utf-8")
        if saklanan.startswith("b6:"):
            return base64.b64decode(saklanan[3:]).decode("utf-8")
    except Exception:
        return ""
    return saklanan


# ====================================================================== sürüm
def surum_tuple(s):
    return tuple(int(x) for x in re.findall(r"\d+", str(s or "0"))) or (0,)


def daha_yeni(a, b):
    return surum_tuple(a) > surum_tuple(b)


def sonraki_surum(s):
    p = list(surum_tuple(s)) + [0, 0]
    return "%d.%d.%d" % (p[0], p[1], p[2] + 1)


# ====================================================================== GitHub
class GitHubHatasi(Exception):
    pass


def _istek(yontem, yol, token, govde=None, ham=False, zaman_asimi=120):
    veri = json.dumps(govde).encode("utf-8") if govde is not None else None
    bas = {"Authorization": "Bearer %s" % token, "X-GitHub-Api-Version": "2022-11-28", "User-Agent": UA,
           "Accept": "application/vnd.github.raw" if ham else "application/vnd.github+json"}
    req = urllib.request.Request(API + yol, data=veri, method=yontem, headers=bas)
    try:
        with urllib.request.urlopen(req, timeout=zaman_asimi) as r:
            icerik = r.read()
            if ham:
                return r.status, icerik
            return r.status, (json.loads(icerik) if icerik else {})
    except urllib.error.HTTPError as e:
        try:
            ayrinti = json.loads(e.read() or b"{}")
        except ValueError:
            ayrinti = {}
        return e.code, ayrinti
    except urllib.error.URLError as e:
        raise GitHubHatasi("GitHub'a ulaşılamadı (%s). İnternet bağlantısını kontrol edin." % e.reason)


def depo_hazirla(sahip, depo, token, gizli):
    """Depoyu kontrol eder, yoksa oluşturur. (tamam, mesaj)"""
    kod, kul = _istek("GET", "/user", token)
    if kod == 401:
        return False, "Token geçersiz ya da süresi dolmuş."
    if kod != 200:
        return False, "GitHub'a bağlanılamadı (HTTP %s)." % kod
    if kul.get("login", "").lower() != sahip.lower():
        return False, "Token '%s' hesabına ait; kullanıcı adı '%s' yazılmış." % (kul.get("login"), sahip)
    kod, d = _istek("GET", "/repos/%s/%s" % (sahip, depo), token)
    if kod == 404:
        kod, d = _istek("POST", "/user/repos", token, {
            "name": depo, "private": gizli, "auto_init": True,
            "description": "Sipariş ve Gemi Takip – %s (otomatik)" % ("yedekler" if gizli else "güncellemeler")})
        if kod not in (200, 201):
            return False, "'%s' deposu oluşturulamadı: %s (token'da 'repo' izni olmalı)" % (depo, d.get("message", kod))
        return True, "'%s' deposu oluşturuldu (%s)." % (depo, "gizli" if gizli else "herkese açık")
    if kod != 200:
        return False, "'%s' deposuna erişilemedi: %s" % (depo, d.get("message", kod))
    if gizli and not d.get("private"):
        return False, "'%s' deposu HERKESE AÇIK. Yedek deposu gizli (private) olmalı – GitHub'da gizli yapın." % depo
    if not gizli and d.get("private"):
        return False, "'%s' deposu gizli. Ekipteki programların güncellemeyi indirebilmesi için herkese açık olmalı." % depo
    return True, "github.com/%s/%s hazır" % (sahip, depo)


def _dosya_yukle(sahip, depo, token, yol, veri, mesaj, dal="main"):
    kod, mevcut = _istek("GET", "/repos/%s/%s/contents/%s?ref=%s" % (sahip, depo, yol, dal), token)
    govde = {"message": mesaj, "branch": dal, "content": base64.b64encode(veri).decode("ascii")}
    if kod == 200 and isinstance(mevcut, dict) and mevcut.get("sha"):
        govde["sha"] = mevcut["sha"]
    kod, d = _istek("PUT", "/repos/%s/%s/contents/%s" % (sahip, depo, yol), token, govde, zaman_asimi=600)
    if kod not in (200, 201):
        raise GitHubHatasi("%s yüklenemedi: %s" % (yol, d.get("message", kod)))
    return d


def raw_url(sahip, depo, dosya, dal="main"):
    return "https://raw.githubusercontent.com/%s/%s/%s/%s" % (sahip, depo, dal, dosya)


# ====================================================================== güncelleme yayınlama
def paket_olustur(surum):
    """Program dosyalarını zip'ler; paketteki st_tanim.py'nin SURUM satırı yeni sürüme çevrilir."""
    b = io.BytesIO()
    with zipfile.ZipFile(b, "w", zipfile.ZIP_DEFLATED) as z:
        for ad in sorted(os.listdir(PROGRAM_KLASORU)):
            yol = os.path.join(PROGRAM_KLASORU, ad)
            if not os.path.isfile(yol) or not ad.endswith(PAKET_UZANTI) or ad in PAKET_HARIC or ad.startswith(("_", "test")):
                continue
            if ad == "st_tanim.py":
                with open(yol, encoding="utf-8") as f:
                    metin = re.sub(r'^SURUM = ".*?"', 'SURUM = "%s"' % surum, f.read(), count=1, flags=re.M)
                z.writestr(ad, metin.encode("utf-8"))
            else:
                z.write(yol, ad)
    return b.getvalue()


def guncelleme_yayinla(sahip, depo, token, surum, notlar, yayinlayan):
    tamam, mesaj = depo_hazirla(sahip, depo, token, gizli=False)
    if not tamam:
        raise GitHubHatasi(mesaj)
    paket = paket_olustur(surum)
    _dosya_yukle(sahip, depo, token, "masaustu.zip", paket, "Sürüm %s paketi" % surum)
    bilgi = {"surum": surum, "notlar": notlar, "tarih": dt.datetime.now().strftime("%d.%m.%Y %H:%M"),
             "yayinlayan": yayinlayan, "paket": raw_url(sahip, depo, "masaustu.zip"), "boyut": len(paket)}
    _dosya_yukle(sahip, depo, token, "surum.json", json.dumps(bilgi, ensure_ascii=False, indent=2).encode("utf-8"),
                 "Sürüm %s" % surum)
    # yayınlayan bilgisayar da yeni sürümde sayılsın
    yol = os.path.join(PROGRAM_KLASORU, "st_tanim.py")
    with open(yol, encoding="utf-8") as f:
        metin = f.read()
    with open(yol, "w", encoding="utf-8") as f:
        f.write(re.sub(r'^SURUM = ".*?"', 'SURUM = "%s"' % surum, metin, count=1, flags=re.M))
    return bilgi, raw_url(sahip, depo, "surum.json")


# ====================================================================== güncelleme kontrolü / kurma (herkes)
def _indir(url, zaman_asimi=60):
    if "raw.githubusercontent.com" in url:
        url += ("&" if "?" in url else "?") + "t=" + dt.datetime.now().strftime("%Y%m%d%H%M%S")
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=zaman_asimi) as r:
        return r.read()


def guncelleme_kontrol(kaynak_url):
    return json.loads(_indir(kaynak_url, 30).decode("utf-8-sig"))


def guncelleme_kur(bilgi):
    """Paketi indirir, kontrol eder ve kurar. Eski dosyalar _yedek/<sürüm> altına alınır."""
    import py_compile
    from st_tanim import SURUM
    veri = _indir(bilgi["paket"], 300)
    z = zipfile.ZipFile(io.BytesIO(veri))
    adlar = [a for a in z.namelist() if not a.endswith("/") and "/" not in a and "\\" not in a]
    if "siparis_takip.pyw" not in adlar:
        raise ValueError("Güncelleme paketi bozuk (siparis_takip.pyw yok)")
    gecici = tempfile.mkdtemp(prefix="st_guncelleme_")
    try:
        for ad in adlar:
            with open(os.path.join(gecici, ad), "wb") as f:
                f.write(z.read(ad))
            if ad.endswith((".py", ".pyw")):
                py_compile.compile(os.path.join(gecici, ad), doraise=True, cfile=os.path.join(gecici, "__k.pyc"))
        yedek = os.path.join(PROGRAM_KLASORU, "_yedek", re.sub(r"[^\w.]", "_", SURUM))
        os.makedirs(yedek, exist_ok=True)
        for ad in adlar:
            hedef = os.path.join(PROGRAM_KLASORU, ad)
            if os.path.exists(hedef):
                shutil.copy2(hedef, os.path.join(yedek, ad))
            shutil.copy2(os.path.join(gecici, ad), hedef)
        return bilgi.get("surum")
    finally:
        shutil.rmtree(gecici, ignore_errors=True)


def yeniden_baslat():
    import subprocess
    exe = sys.executable
    w = os.path.join(os.path.dirname(exe), "pythonw.exe")
    subprocess.Popen([w if os.path.exists(w) else exe, os.path.join(PROGRAM_KLASORU, "siparis_takip.pyw")],
                     cwd=PROGRAM_KLASORU)


# ====================================================================== internet yedeği
def yedek_paketi(db):
    """Veritabanının tutarlı kopyası + ekler klasörü -> zip baytları"""
    b = io.BytesIO()
    gecici = tempfile.mkdtemp(prefix="st_yedek_")
    try:
        kopya = os.path.join(gecici, "siparis_takip.db")
        hedef = sqlite3.connect(kopya)
        db.c.backup(hedef)
        hedef.close()
        with zipfile.ZipFile(b, "w", zipfile.ZIP_DEFLATED) as z:
            z.write(kopya, "siparis_takip.db")
            for d, _, fs in os.walk(db.ek_klasoru):
                for f in fs:
                    tam = os.path.join(d, f)
                    z.write(tam, os.path.relpath(tam, db.klasor).replace("\\", "/"))
            z.writestr("yedek_bilgi.json", json.dumps({"tarih": dt.datetime.now().strftime("%d.%m.%Y %H:%M")},
                                                      ensure_ascii=False))
    finally:
        shutil.rmtree(gecici, ignore_errors=True)
    return b.getvalue()


def internete_yedekle(veri, sahip, depo, token):
    """veri: yedek_paketi(db) çıktısı (veritabanı ana iş parçacığında kopyalanır, yükleme arka planda yapılabilir)."""
    tamam, mesaj = depo_hazirla(sahip, depo, token, gizli=True)
    if not tamam:
        raise GitHubHatasi(mesaj)
    if len(veri) > 95 * 1024 * 1024:
        raise GitHubHatasi("Yedek çok büyük (%d MB). GitHub tek dosyada 100 MB sınırı var." % (len(veri) // 1048576))
    ad = "%s/siparis_takip_%s.zip" % (YEDEK_KLASORU, dt.datetime.now().strftime("%Y%m%d_%H%M"))
    _dosya_yukle(sahip, depo, token, ad, veri, "Otomatik yedek %s" % ad)
    # eskileri temizle
    try:
        liste = yedekleri_listele(sahip, depo, token)
        for y in liste[TUTULACAK_YEDEK:]:
            _istek("DELETE", "/repos/%s/%s/contents/%s" % (sahip, depo, y["path"]), token,
                   {"message": "Eski yedek silindi", "sha": y["sha"], "branch": "main"})
    except Exception:
        pass
    return ad, len(veri)


def yedekleri_listele(sahip, depo, token):
    kod, d = _istek("GET", "/repos/%s/%s/contents/%s" % (sahip, depo, YEDEK_KLASORU), token)
    if kod == 404:
        return []
    if kod != 200 or not isinstance(d, list):
        raise GitHubHatasi("Yedek listesi alınamadı: %s" % (d.get("message", kod) if isinstance(d, dict) else kod))
    return sorted([x for x in d if x.get("name", "").endswith(".zip")], key=lambda x: x["name"], reverse=True)


def yedegi_indir(sahip, depo, token, yol, hedef_klasor):
    """Yedeği indirir; program yeniden açılınca geri yüklenmek üzere bekletir."""
    kod, veri = _istek("GET", "/repos/%s/%s/contents/%s" % (sahip, depo, yol), token, ham=True, zaman_asimi=600)
    if kod != 200:
        raise GitHubHatasi("Yedek indirilemedi (HTTP %s)" % kod)
    zipfile.ZipFile(io.BytesIO(veri)).testzip()
    with open(os.path.join(hedef_klasor, BEKLEYEN_GERI_YUKLEME), "wb") as f:
        f.write(veri)


def bekleyen_geri_yuklemeyi_uygula(veri_klasoru):
    """Program açılırken (veritabanı açılmadan önce) çağrılır. Mevcut veri _onceki_<tarih> klasörüne alınır."""
    paket = os.path.join(veri_klasoru, BEKLEYEN_GERI_YUKLEME)
    if not os.path.exists(paket):
        return None
    damga = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    onceki = os.path.join(veri_klasoru, "_onceki_%s" % damga)
    os.makedirs(onceki, exist_ok=True)
    for ad in ("siparis_takip.db", "ekler"):
        yol = os.path.join(veri_klasoru, ad)
        if os.path.exists(yol):
            shutil.move(yol, os.path.join(onceki, ad))
    with zipfile.ZipFile(paket) as z:
        for ad in z.namelist():
            if ad.startswith(("/", "..")) or ".." in ad.split("/"):
                continue
            if ad == "yedek_bilgi.json":
                continue
            z.extract(ad, veri_klasoru)
    os.remove(paket)
    return onceki
