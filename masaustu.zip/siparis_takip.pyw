# -*- coding: utf-8 -*-
"""Sipariş ve Gemi Takip Programı - başlangıç dosyası.
Çift tıklayarak açılır (Python 3.10+ gerekir, ek kütüphane gerekmez; Excel çıktısı için openpyxl önerilir)."""
import os
import sys
import json
import traceback
import tkinter as tk
from tkinter import ttk, messagebox

PROGRAM_KLASORU = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, PROGRAM_KLASORU)
os.chdir(PROGRAM_KLASORU)

from st_tanim import PROGRAM_ADI, SURUM, LACIVERT, VURGU, KART, SOLUK, YAZI  # noqa: E402
from st_ortak import stilleri_kur, font, lbl, ortala  # noqa: E402
from st_db import VeriTabani  # noqa: E402

AYAR_DOSYASI = os.path.join(PROGRAM_KLASORU, "ayarlar.json")
HATA_DOSYASI = os.path.join(PROGRAM_KLASORU, "hata_kaydi.txt")


def ayarlari_oku():
    try:
        with open(AYAR_DOSYASI, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def ayarlari_yaz(a):
    try:
        with open(AYAR_DOSYASI, "w", encoding="utf-8") as f:
            json.dump(a, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def hata_yaz(exc_type, exc, tb):
    metin = "".join(traceback.format_exception(exc_type, exc, tb))
    try:
        import datetime
        with open(HATA_DOSYASI, "a", encoding="utf-8") as f:
            f.write("\n==== %s ====\n%s" % (datetime.datetime.now(), metin))
    except Exception:
        pass
    try:
        messagebox.showerror("Beklenmeyen hata", "%s\n\nAyrıntı hata_kaydi.txt dosyasına yazıldı." % exc)
    except Exception:
        pass


class Uygulama:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("%s %s" % (PROGRAM_ADI, SURUM))
        self.root.report_callback_exception = hata_yaz
        try:
            self.root.iconbitmap(os.path.join(PROGRAM_KLASORU, "simge.ico"))
        except Exception:
            pass
        stilleri_kur(self.root)
        self.ayarlar = ayarlari_oku()
        veri = self.ayarlar.get("veri_klasoru") or os.path.join(PROGRAM_KLASORU, "veri")
        try:
            from st_programci import bekleyen_geri_yuklemeyi_uygula
            onceki = bekleyen_geri_yuklemeyi_uygula(veri)
            if onceki:
                messagebox.showinfo("Yedek geri yüklendi", "İnternet yedeği geri yüklendi.\n\nÖnceki veriler şu klasöre "
                                                           "alındı (silinmedi):\n%s" % onceki)
        except Exception as e:
            messagebox.showerror("Yedek geri yüklenemedi", str(e))
        try:
            self.db = VeriTabani(veri)
        except Exception as e:
            messagebox.showerror("Veri klasörü açılamadı", "%s\n\n%s\n\nVarsayılan klasör kullanılacak." % (veri, e))
            self.ayarlar.pop("veri_klasoru", None)
            ayarlari_yaz(self.ayarlar)
            self.db = VeriTabani(os.path.join(PROGRAM_KLASORU, "veri"))
        self.root.geometry("1400x880")
        try:
            self.root.state("zoomed")
        except tk.TclError:
            pass
        self.root.minsize(1100, 700)
        self.root.protocol("WM_DELETE_WINDOW", self.kapat)
        self.ana = None
        self.giris_ekrani()

    def temizle(self):
        for w in self.root.winfo_children():
            w.destroy()

    # ------------------------------------------------------------------ giriş
    def giris_ekrani(self):
        self.temizle()
        self.ana = None
        zemin = tk.Frame(self.root, bg=LACIVERT)
        zemin.pack(fill="both", expand=True)
        k = tk.Frame(zemin, bg=KART, padx=36, pady=30)
        k.place(relx=0.5, rely=0.45, anchor="center")
        ilk = self.db.kullanici_sayisi() == 0
        lbl(k, "SİPARİŞ VE GEMİ TAKİP", fg=SOLUK, boy=9, kalin=True).pack(anchor="w")
        lbl(k, "İlk kurulum" if ilk else "Giriş yap", boy=20, kalin=True).pack(anchor="w")
        lbl(k, "İlk hesap Üst Yönetici olarak oluşturulur.\nDiğer kullanıcıları içeriden eklersiniz." if ilk else
            "Her kullanıcı kendi hesabıyla giriş yapar.", fg=SOLUK).pack(anchor="w", pady=(2, 14))
        v = {}
        alanlar = ([("ad", "Ad Soyad", "")] if ilk else []) + [("kadi", "Kullanıcı adı", ""), ("sifre", "Şifre", "•")]
        if ilk:
            alanlar.append(("sifre2", "Şifre (tekrar)", "•"))
        ilk_giris = None
        for a, b, gizle in alanlar:
            lbl(k, b, boy=10, kalin=True).pack(anchor="w")
            v[a] = tk.StringVar(value=self.ayarlar.get("son_kullanici", "") if a == "kadi" and not ilk else "")
            e = ttk.Entry(k, textvariable=v[a], show=gizle, width=36, font=font(11))
            e.pack(fill="x", pady=(3, 10), ipady=3)
            if ilk_giris is None and not v[a].get():
                ilk_giris = e
        caps = lbl(k, "", fg="#9E2A21", boy=9)
        caps.pack(anchor="w")
        mesaj = lbl(k, "", fg="#9E2A21", boy=10)
        mesaj.pack(anchor="w")

        def capslock(e):
            try:
                caps.configure(text="⚠ CAPS LOCK AÇIK" if (e.state & 0x2) else "")
            except Exception:
                pass
        self.root.bind("<KeyRelease>", capslock)

        def gir(_e=None):
            if ilk:
                ad, kadi, s1, s2 = v["ad"].get().strip(), v["kadi"].get().strip(), v["sifre"].get(), v["sifre2"].get()
                if not ad or not kadi:
                    mesaj.configure(text="Ad soyad ve kullanıcı adı zorunlu.")
                    return
                if len(s1) < 4 or s1 != s2:
                    mesaj.configure(text="Şifreler en az 4 karakter olmalı ve aynı olmalı.")
                    return
                self.db.kullanici_ekle(kadi, ad, s1, "ust", "yonetim")
            u = self.db.giris(v["kadi"].get(), v["sifre"].get())
            if not u:
                mesaj.configure(text="Kullanıcı adı veya şifre hatalı (ya da hesap pasif).")
                return
            self.ayarlar["son_kullanici"] = u["kadi"]
            ayarlari_yaz(self.ayarlar)
            self.root.unbind("<KeyRelease>")
            self.ac(u)

        ttk.Button(k, text="Hesabı oluştur ve gir" if ilk else "Giriş", style="Vurgu.TButton", command=gir).pack(fill="x", pady=(8, 0), ipady=4)
        lbl(k, "Veri: " + self.db.klasor, fg=SOLUK, boy=8, wraplength=330).pack(anchor="w", pady=(14, 0))
        self.root.bind("<Return>", gir)
        (ilk_giris or e).focus_set()

    def ac(self, kullanici):
        from st_arayuz import AnaPencere
        self.root.unbind("<Return>")
        self.temizle()
        self.ana = AnaPencere(self.root, self.db, kullanici, self.ayarlar, self.giris_ekrani)
        self.ana.ayarlar_kaydet = lambda: ayarlari_yaz(self.ayarlar)
        self.ana.pack(fill="both", expand=True)
        if sys.platform.startswith("win") and not self.ayarlar.get("kisayol_soruldu"):
            self.ayarlar["kisayol_soruldu"] = True
            ayarlari_yaz(self.ayarlar)
            if messagebox.askyesno("Masaüstü kısayolu", "Masaüstüne program simgeli bir kısayol oluşturulsun mu?"):
                from st_kisayol import kisayol_olustur
                ok, mesaj = kisayol_olustur()
                (messagebox.showinfo if ok else messagebox.showwarning)(
                    "Masaüstü kısayolu", "Kısayol masaüstüne eklendi." if ok else mesaj)

    def kapat(self):
        if self.ana is not None:
            try:
                self.ana._bekleyeni_kaydet()
            except Exception:
                pass
        self.db.kapat()
        self.root.destroy()

    def calistir(self):
        self.root.mainloop()


if __name__ == "__main__":
    try:
        Uygulama().calistir()
    except Exception:
        hata_yaz(*sys.exc_info())
