# -*- coding: utf-8 -*-
"""Sipariş ve Gemi Takip Programı - başlangıç dosyası.
Çift tıklayarak açılır (Python 3.10+ gerekir, ek kütüphane gerekmez; Excel çıktısı için openpyxl önerilir)."""
import os
import sys
import json
import traceback
import tkinter as tk
from tkinter import ttk, messagebox

PROGRAM_KLASORU = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, PROGRAM_KLASORU)
os.chdir(PROGRAM_KLASORU)

from st_tanim import PROGRAM_ADI, SURUM, LACIVERT, VURGU, KART, SOLUK, YAZI  # noqa: E402
from st_ortak import stilleri_kur, font, lbl, ortala  # noqa: E402
from st_db import VeriTabani, sifre_yeterli_mi  # noqa: E402
import time  # noqa: E402

GIRIS_KILIDI = {}  # kullanıcı adı -> (hatalı deneme sayısı, kilit bitiş zamanı)

AYAR_DOSYASI = os.path.join(PROGRAM_KLASORU, "ayarlar.json")
HATA_DOSYASI = os.path.join(PROGRAM_KLASORU, "hata_kaydi.txt")


def ayarlari_oku():
    try:
        with open(AYAR_DOSYASI, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def ayarlari_yaz(a):
    try:
        with open(AYAR_DOSYASI, "w", encoding="utf-8") as f:
            json.dump(a, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def hata_yaz(exc_type, exc, tb):
    # bilinen durumlar: anlaşılır mesaj (hata kaydı penceresi yok)
    ad = getattr(exc_type, "__name__", "")
    if ad == "BaglantiYok":
        try:
            messagebox.showwarning("Bağlantı yok", "İnternet / bulut bağlantısı yok; işlem yapılamadı.\n\n"
                                                   "Bağlantı gelince (üstte '● Çevrimiçi' yazınca) tekrar deneyin.")
        except Exception:
            pass
        return
    if ad in ("SiparisSilindiHatasi", "KullaniciHatasi", "CakismaHatasi"):
        try:
            messagebox.showwarning("İşlem yapılamadı", str(exc))
        except Exception:
            pass
        return
    metin = "".join(traceback.format_exception(exc_type, exc, tb))
    try:
        import datetime
        with open(HATA_DOSYASI, "a", encoding="utf-8") as f:
            f.write("\n==== %s ====\n%s" % (datetime.datetime.now(), metin))
    except Exception:
        pass
    try:
        messagebox.showerror("Beklenmeyen hata", "%s\n\nAyrıntı hata_kaydi.txt dosyasına yazıldı." % exc)
    except Exception:
        pass


class Uygulama:
    def __init__(self, arka_plan=False, kilit=None):
        self.arka_plan = arka_plan  # Windows açılışında: pencere açılmadan tepside başlar
        self.kilit = kilit
        self.tepsi = None
        self.root = tk.Tk()
        if arka_plan:
            self.root.withdraw()
        self.root.title("%s %s" % (PROGRAM_ADI, SURUM))
        self.root.report_callback_exception = hata_yaz
        try:
            self.root.iconbitmap(os.path.join(PROGRAM_KLASORU, "simge.ico"))
        except Exception:
            pass
        stilleri_kur(self.root)
        self.ayarlar = ayarlari_oku()
        from st_arka_plan import Bildirimler
        self.kutular = Bildirimler(self.root)
        veri = self.ayarlar.get("veri_klasoru") or os.path.join(PROGRAM_KLASORU, "veri")
        if self.ayarlar.get("bulut"):
            self.db = self.bulut_ac(veri)
            if self.db is None:
                self.root.destroy()
                raise SystemExit
        else:
            self.db = self.yerel_ac(veri)
        self.root.geometry("1400x880")
        try:
            self.root.state("zoomed")
        except tk.TclError:
            pass
        self.root.minsize(1100, 700)
        self.root.protocol("WM_DELETE_WINDOW", self.pencere_kapat)
        self.ana = None
        self._tepsi_kur()
        self._komut_after = self.root.after(300, self._komutlar)
        u = None
        if self.arka_plan or self.ayarlar.get("oturum"):
            from st_arka_plan import oturum_oku
            u = oturum_oku(self.ayarlar, self.db)
        if u:
            self.ac(u, sessiz=self.arka_plan)
        else:
            self.giris_ekrani()
            if self.arka_plan:  # hatırlanan oturum yok: giriş için pencere açılır
                self.pencereyi_goster()

    # ------------------------------------------------------------------ arka plan / tepsi
    def _tepsi_kur(self):
        if not self.ayarlar.get("arka_planda_calis", True):
            return
        import st_arka_plan as AP
        if AP.pystray_var_mi():
            self._tepsi_olustur()
        else:
            AP.pystray_kur_arka_planda()  # ilk sefer: simge kütüphanesi arka planda kurulur, bitince simge çıkar
        # ilk kez: Windows açılışında arka planda başlasın
        if sys.platform.startswith("win") and not self.ayarlar.get("baslangic_ayarlandi"):
            from st_arka_plan import baslangica_ekle
            ok, _ = baslangica_ekle(True)
            if ok:
                self.ayarlar["baslangic_ayarlandi"] = True
                ayarlari_yaz(self.ayarlar)

    def _tepsi_olustur(self):
        from st_arka_plan import Tepsi
        t = Tepsi("%s %s" % (PROGRAM_ADI, SURUM))
        self.tepsi = t if t.var else None
        if self.tepsi is not None and self.ana is not None:
            self.tepsi.baslik("Sipariş ve Gemi Takip · %s" % self.ana.k["ad"])

    def _komutlar(self):
        """Tepsi menüsünden ve ikinci açılıştan gelen komutlar (ana iş parçacığında işlenir)."""
        from st_arka_plan import KOMUTLAR
        try:
            while True:
                k = KOMUTLAR.get_nowait()
                if k == "AC":
                    self.pencereyi_goster()
                elif k == "KAPAT":
                    self.tam_kapat()
                    return
                elif k == "YENIDEN":
                    self.tam_kapat(yeniden=True)
                    return
                elif k == "TEPSI_KUR":
                    if self.tepsi is None:
                        self._tepsi_olustur()
                elif k.startswith("DURAKLAT_"):
                    if self.ana is not None and self.ana.bildirim is not None:
                        self.ana.bildirim.duraklat = k.endswith("1")
        except Exception:
            pass
        try:
            self._komut_after = self.root.after(300, self._komutlar)
        except tk.TclError:
            pass

    def pencereyi_goster(self):
        self.root.deiconify()
        try:
            self.root.state("zoomed")
        except tk.TclError:
            pass
        self.root.lift()
        try:
            self.root.attributes("-topmost", True)
            self.root.after(300, lambda: self.root.attributes("-topmost", False))
        except tk.TclError:
            pass
        self.root.focus_force()

    def pencere_kapat(self):
        """Pencerenin X'i: arka planda çalışma açıksa program kapanmaz, tepsiye iner."""
        if not self.ayarlar.get("arka_planda_calis", True) or self.ana is None:
            self.tam_kapat()
            return
        try:
            self.ana._bekleyeni_kaydet()
        except Exception:
            pass
        if self.tepsi is not None:
            self.root.withdraw()
            if not self.ayarlar.get("tepsi_bilgisi_verildi"):
                self.ayarlar["tepsi_bilgisi_verildi"] = True
                ayarlari_yaz(self.ayarlar)
                self.kutular.goster("Program arka planda çalışıyor",
                                    "Değişiklikler bildirim olarak gelmeye devam eder. Açmak için saatin yanındaki "
                                    "simgeye çift tıklayın; tamamen kapatmak için simgeye sağ tıklayıp 'Programı kapat'.",
                                    tiklaninca=self.pencereyi_goster)
        else:
            self.root.iconify()  # tepsi simgesi kurulamadıysa görev çubuğuna küçülür

    def oturumu_unut(self):
        from st_arka_plan import oturum_unut
        oturum_unut(self.ayarlar)
        ayarlari_yaz(self.ayarlar)

    def tam_kapat(self, yeniden=False):
        if self.ana is not None:
            try:
                self.ana._bekleyeni_kaydet()
            except Exception:
                pass
            self.ana._kapandi = True
        try:
            self.kutular.hepsini_kapat()
        except Exception:
            pass
        try:
            self.db.kapat()
        except Exception:
            pass
        if yeniden:
            from st_programci import yeniden_baslat
            yeniden_baslat()
        try:
            self.root.after_cancel(self._komut_after)
        except Exception:
            pass
        try:
            self.root.destroy()
        except tk.TclError:
            pass

    def yerel_ac(self, veri):
        try:
            from st_programci import bekleyen_geri_yuklemeyi_uygula
            onceki = bekleyen_geri_yuklemeyi_uygula(veri)
            if onceki:
                messagebox.showinfo("Yedek geri yüklendi", "İnternet yedeği geri yüklendi.\n\nÖnceki veriler şu klasöre "
                                                           "alındı (silinmedi):\n%s" % onceki)
        except Exception as e:
            messagebox.showerror("Yedek geri yüklenemedi", str(e))
        try:
            return VeriTabani(veri)
        except Exception as e:
            messagebox.showerror("Veri klasörü açılamadı", "%s\n\n%s\n\nVarsayılan klasör kullanılacak." % (veri, e))
            self.ayarlar.pop("veri_klasoru", None)
            ayarlari_yaz(self.ayarlar)
            return VeriTabani(os.path.join(PROGRAM_KLASORU, "veri"))

    def bulut_ac(self, veri):
        """Bulut veritabanına bağlanır; olmazsa tekrar denemeyi sorar."""
        import st_bulut
        from st_programci import sifre_coz
        b = self.ayarlar["bulut"]
        bekle = tk.Toplevel(self.root)
        bekle.overrideredirect(True)
        tk.Label(bekle, text="Bulut veritabanına bağlanılıyor…", bg=LACIVERT, fg="#FFFFFF", font=font(12),
                 padx=30, pady=20).pack()
        ortala(bekle)
        self.root.withdraw()
        if self.arka_plan:
            bekle.withdraw()  # Windows açılışında sessiz bağlanır
        bekle.update()
        deneme = 0
        try:
            while True:
                try:
                    if not st_bulut.surucu_hazir(kur=True):
                        raise st_bulut.BulutHatasi("Bulut sürücüsü (pg8000) kurulamadı. İnternet bağlantısını kontrol edin.")
                    ayar = st_bulut.uri_coz(b.get("uri", ""), sifre_coz(b.get("sifre", "")))
                    db = VeriTabani(veri, bulut=ayar)
                    try:
                        from st_programci import bekleyen_buluta_uygula
                        if bekleyen_buluta_uygula(db, log=lambda m: None):
                            messagebox.showinfo("Yedek geri yüklendi", "İnternet yedeği bulut veritabanına geri yüklendi.")
                    except Exception as e:
                        messagebox.showerror("Yedek geri yüklenemedi", str(e))
                    db.c.izlemeyi_baslat()  # başka bilgisayarların değişikliklerini arka planda izler
                    return db
                except Exception as e:
                    deneme += 1
                    if self.arka_plan and deneme <= 20:
                        time.sleep(15)  # Windows yeni açıldı, internet henüz gelmemiş olabilir: sessizce tekrar dene
                        continue
                    if not messagebox.askretrycancel("Bulut veritabanı", "Bulut veritabanına bağlanılamadı.\n\n%s\n\n"
                                                     "İnternet bağlantısını kontrol edip 'Yeniden dene'ye basın." % e):
                        return None
        finally:
            bekle.destroy()
            if not self.arka_plan:
                self.root.deiconify()

    def temizle(self):
        for w in self.root.winfo_children():
            w.destroy()

    # ------------------------------------------------------------------ giriş
    def giris_ekrani(self):
        self.temizle()
        self.ana = None
        zemin = tk.Frame(self.root, bg=LACIVERT)
        zemin.pack(fill="both", expand=True)
        k = tk.Frame(zemin, bg=KART, padx=36, pady=30)
        k.place(relx=0.5, rely=0.45, anchor="center")
        ilk = self.db.kullanici_sayisi() == 0
        lbl(k, "SİPARİŞ VE GEMİ TAKİP", fg=SOLUK, boy=9, kalin=True).pack(anchor="w")
        lbl(k, "İlk kurulum" if ilk else "Giriş yap", boy=20, kalin=True).pack(anchor="w")
        lbl(k, "İlk hesap Üst Yönetici olarak oluşturulur.\nDiğer kullanıcıları içeriden eklersiniz." if ilk else
            "Her kullanıcı kendi hesabıyla giriş yapar.", fg=SOLUK).pack(anchor="w", pady=(2, 14))
        v = {}
        alanlar = ([("ad", "Ad Soyad", "")] if ilk else []) + [("kadi", "Kullanıcı adı", ""), ("sifre", "Şifre", "•")]
        if ilk:
            alanlar.append(("sifre2", "Şifre (tekrar)", "•"))
        ilk_giris = None
        for a, b, gizle in alanlar:
            lbl(k, b, boy=10, kalin=True).pack(anchor="w")
            v[a] = tk.StringVar(value=self.ayarlar.get("son_kullanici", "") if a == "kadi" and not ilk else "")
            e = ttk.Entry(k, textvariable=v[a], show=gizle, width=36, font=font(11))
            e.pack(fill="x", pady=(3, 10), ipady=3)
            if ilk_giris is None and not v[a].get():
                ilk_giris = e
        v_hatirla = tk.BooleanVar(value=True)
        ttk.Checkbutton(k, text="Bu bilgisayarda oturumum açık kalsın (arka planda bildirim için)",
                        variable=v_hatirla).pack(anchor="w", pady=(0, 6))
        caps = lbl(k, "", fg="#9E2A21", boy=9)
        caps.pack(anchor="w")
        mesaj = lbl(k, "", fg="#9E2A21", boy=10)
        mesaj.pack(anchor="w")

        def capslock(e):
            try:
                caps.configure(text="⚠ CAPS LOCK AÇIK" if (e.state & 0x2) else "")
            except Exception:
                pass
        self.root.bind("<KeyRelease>", capslock)

        def gir(_e=None):
            if ilk:
                ad, kadi, s1, s2 = v["ad"].get().strip(), v["kadi"].get().strip(), v["sifre"].get(), v["sifre2"].get()
                if not ad or not kadi:
                    mesaj.configure(text="Ad soyad ve kullanıcı adı zorunlu.")
                    return
                if not sifre_yeterli_mi(s1) or s1 != s2:
                    mesaj.configure(text="Şifreler en az 6 karakter olmalı ve aynı olmalı.")
                    return
                self.db.kullanici_ekle(kadi, ad, s1, "ust", "yonetim")
            kadi_ = v["kadi"].get().strip().upper()
            kilit = GIRIS_KILIDI.get(kadi_)
            if kilit and kilit[1] > time.time():
                mesaj.configure(text="Çok sayıda hatalı deneme. %d saniye sonra tekrar deneyin." % (kilit[1] - time.time() + 1))
                return
            try:
                u = self.db.giris(v["kadi"].get(), v["sifre"].get())
            except Exception as e:
                mesaj.configure(text="Bağlantı yok, giriş yapılamadı. Tekrar deneyin.\n(%s)" % str(e)[:80])
                return
            if not u:
                sayi = (kilit[0] if kilit else 0) + 1
                bekle = 60 if sayi >= 5 else 0
                GIRIS_KILIDI[kadi_] = (0 if bekle else sayi, time.time() + bekle)
                mesaj.configure(text="Kullanıcı adı veya şifre hatalı (ya da hesap pasif)." +
                                ("\n5 hatalı deneme: 60 saniye beklemelisiniz." if bekle else
                                 " (%d deneme kaldı)" % (5 - sayi) if sayi >= 3 else ""))
                return
            GIRIS_KILIDI.pop(kadi_, None)
            self.ayarlar["son_kullanici"] = u["kadi"]
            from st_arka_plan import oturum_kaydet, oturum_unut
            if v_hatirla.get():
                oturum_kaydet(self.ayarlar, u, u.get("sifre_hash") or "")
            else:
                oturum_unut(self.ayarlar)
            ayarlari_yaz(self.ayarlar)
            self.root.unbind("<KeyRelease>")
            self.ac(u)

        ttk.Button(k, text="Hesabı oluştur ve gir" if ilk else "Giriş", style="Vurgu.TButton", command=gir).pack(fill="x", pady=(8, 0), ipady=4)
        lbl(k, "Veri: " + self.db.konum_metni, fg=SOLUK, boy=8, wraplength=330).pack(anchor="w", pady=(14, 0))
        self.root.bind("<Return>", gir)
        (ilk_giris or e).focus_set()

    def ac(self, kullanici, sessiz=False):
        from st_arayuz import AnaPencere
        self.root.unbind("<Return>")
        self.temizle()
        self.ana = AnaPencere(self.root, self.db, kullanici, self.ayarlar, self.giris_ekrani)
        self.ana.ayarlar_kaydet = lambda: ayarlari_yaz(self.ayarlar)
        self.ana.uygulama = self
        self.ana.pack(fill="both", expand=True)
        if sessiz:
            return  # Windows açılışında: pencere açılmaz, bildirimler tepsiden gelir
        if sys.platform.startswith("win") and not self.ayarlar.get("kisayol_soruldu"):
            self.ayarlar["kisayol_soruldu"] = True
            ayarlari_yaz(self.ayarlar)
            if messagebox.askyesno("Masaüstü kısayolu", "Masaüstüne program simgeli bir kısayol oluşturulsun mu?"):
                from st_kisayol import kisayol_olustur
                ok, mesaj = kisayol_olustur()
                (messagebox.showinfo if ok else messagebox.showwarning)(
                    "Masaüstü kısayolu", "Kısayol masaüstüne eklendi." if ok else mesaj)

    def kapat(self):
        self.tam_kapat()

    def calistir(self):
        try:
            self.root.mainloop()
        finally:
            # pencere hangi yoldan kapanırsa kapansın: tepsi simgesi ve tek örnek kilidi bırakılır
            if self.tepsi is not None:
                self.tepsi.kapat()
            try:
                if self.kilit is not None:
                    self.kilit.close()
            except Exception:
                pass


if __name__ == "__main__":
    try:
        import st_arka_plan
        kilit = st_arka_plan.tek_ornek(bekle="--yeniden" in sys.argv)
        if kilit is None:
            sys.exit(0)  # program zaten açık: onun penceresi öne getirildi
        Uygulama(arka_plan="--arka-plan" in sys.argv, kilit=kilit).calistir()
    except SystemExit:
        pass
    except Exception:
        hata_yaz(*sys.exc_info())
    os._exit(0)
