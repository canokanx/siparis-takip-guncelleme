# -*- coding: utf-8 -*-
"""Masaüstüne program simgeli kısayol oluşturur (Windows)."""
import os
import sys

PROGRAM_KLASORU = os.path.dirname(os.path.abspath(__file__))
KISAYOL_ADI = "Sipariş ve Gemi Takip.lnk"


def _pythonw():
    exe = sys.executable
    aday = os.path.join(os.path.dirname(exe), "pythonw.exe")
    return aday if os.path.exists(aday) else exe


def masaustu_klasoru():
    try:
        import ctypes
        from ctypes import wintypes
        buf = ctypes.create_unicode_buffer(wintypes.MAX_PATH)
        ctypes.windll.shell32.SHGetFolderPathW(None, 0x0010, None, 0, buf)  # CSIDL_DESKTOPDIRECTORY
        if buf.value:
            return buf.value
    except Exception:
        pass
    return os.path.join(os.path.expanduser("~"), "Desktop")


def kisayol_olustur():
    """(basarili, mesaj) döner."""
    if not sys.platform.startswith("win"):
        return False, "Kısayol yalnızca Windows'ta oluşturulabilir."
    hedef = os.path.join(masaustu_klasoru(), KISAYOL_ADI)
    try:
        import win32com.client  # pywin32
        kabuk = win32com.client.Dispatch("WScript.Shell")
        k = kabuk.CreateShortCut(hedef)
        k.TargetPath = _pythonw()
        k.Arguments = '"%s"' % os.path.join(PROGRAM_KLASORU, "siparis_takip.pyw")
        k.WorkingDirectory = PROGRAM_KLASORU
        k.IconLocation = os.path.join(PROGRAM_KLASORU, "simge.ico")
        k.Description = "Sipariş ve Gemi Takip Programı"
        k.save()
        return True, hedef
    except ImportError:
        return False, ("Otomatik kısayol için 'pywin32' kütüphanesi bulunamadı.\n\n"
                       "Elle oluşturmak için: program klasöründeki 'siparis_takip.pyw' dosyasına sağ tıklayın → "
                       "Gönder → Masaüstü (kısayol oluştur).")
    except Exception as e:
        return False, "Kısayol oluşturulamadı: %s" % e


if __name__ == "__main__":
    ok, mesaj = kisayol_olustur()
    try:
        import tkinter as tk
        from tkinter import messagebox
        r = tk.Tk()
        r.withdraw()
        (messagebox.showinfo if ok else messagebox.showwarning)("Masaüstü kısayolu",
                                                                 ("Kısayol oluşturuldu:\n" + mesaj) if ok else mesaj)
        r.destroy()
    except Exception:
        print(mesaj)
