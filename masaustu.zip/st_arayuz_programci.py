# -*- coding: utf-8 -*-
"""Ayarlar → Programcı bölümü: GitHub bağlantısı, güncelleme yayınlama / kurma, internete otomatik yedek."""
import datetime as dt
import time
import os
import threading
import tkinter as tk
from tkinter import ttk, messagebox

import st_programci as P
import st_mantik as M
from st_tanim import SURUM, ZEMIN, KART, SOLUK
from st_ortak import kart, lbl, bant

VARSAYILAN = {"gh_kullanici": "canokanx", "gh_guncelleme_depo": "siparis-takip-guncelleme",
              "gh_yedek_depo": "siparis-takip-yedek", "yedek_otomatik": "1", "yedek_aralik_saat": "24",
              "guncelleme_otomatik": "1"}
ARALIKLAR = [("Her 6 saatte bir", "6"), ("Her 12 saatte bir", "12"), ("Her gün", "24"), ("Haftada bir", "168")]


def ayar(ana, anahtar):
    return ana.db.meta_al(anahtar, VARSAYILAN.get(anahtar, ""))


def token(ana):
    return P.sifre_coz(ana.ayarlar.get("gh_token", ""))


def arka_plan(widget, is_, bitince):
    """is_() arka planda çalışır; bitince(sonuc, hata) arayüzde çağrılır."""
    kutu = {}

    def calis():
        try:
            kutu["s"] = is_()
        except Exception as e:  # noqa
            kutu["h"] = e
    t = threading.Thread(target=calis, daemon=True)
    t.start()

    def bekle():
        try:
            if not widget.winfo_exists():
                return
        except Exception:
            return
        if t.is_alive():
            widget.after(300, bekle)
        else:
            bitince(kutu.get("s"), kutu.get("h"))
    bekle()


# ====================================================================== açılış ve periyodik işler
GUNCELLEME_ARALIK_DK = 5      # yeni sürüm bu aralıkla denetlenir (program sürekli arka planda açık kalıyor)
DISK_ARALIK_SN = 60           # program dosyaları diskte değişti mi (elle kopyalama / yayınlama)
BOSTA_DK = 3                  # pencere açıkken: bu kadar işlem yapılmazsa yeni sürüme geçilir
KAYIT_DOSYASI = os.path.join(P.PROGRAM_KLASORU, "guncelleme_kaydi.txt")
DURUM = {"son": None, "sonuc": "henüz denetlenmedi", "hata": False}


def kayit(metin, hata=False):
    """Her güncelleme denetimi / kurulumu dosyaya yazılır (sorun olursa nedeni görülsün)."""
    zaman = dt.datetime.now().strftime("%d.%m.%Y %H:%M:%S")
    DURUM.update(son=zaman, sonuc=metin, hata=hata)
    try:
        satirlar = []
        if os.path.exists(KAYIT_DOSYASI):
            with open(KAYIT_DOSYASI, encoding="utf-8", errors="replace") as f:
                satirlar = f.read().splitlines()[-299:]
        satirlar.append("%s  [%s]  %s" % (zaman, SURUM, metin))
        with open(KAYIT_DOSYASI, "w", encoding="utf-8") as f:
            f.write("\n".join(satirlar) + "\n")
    except Exception:
        pass


def acilis_kontrolleri(ana):
    """Giriş yapıldıktan birkaç saniye sonra: kurulmuş güncellemenin bildirimi, güncelleme izleyicisi, yedek kontrolü."""
    bilgi = ana.ayarlar.pop("guncelleme_bildir", None)
    if bilgi:
        try:
            ana.ayarlar_kaydet()
            ana.uygulama.kutular.goster("Program güncellendi: sürüm %s" % bilgi.get("surum", SURUM),
                                        (bilgi.get("notlar") or "Yenilikler için Kullanım Kılavuzu'na bakın.")[:300],
                                        renk="#2E9E5B", ses=True)
        except Exception:
            pass
    uyg = getattr(ana, "uygulama", None)
    if uyg is not None:
        guncelleme_izle(uyg)
        if getattr(uyg, "_yeniden_bekliyor", False):
            ana.guncelleme_hazir(getattr(uyg, "_bekleyen_surum", ""))
    ana.after(20000, lambda: otomatik_yedek_kontrol(ana))


def guncelleme_izle(uyg):
    """Program açık olduğu sürece (giriş ekranında ve tepsideyken de) güncellemeleri izler. Bir kez başlatılır."""
    if getattr(uyg, "_guncelleme_izleniyor", False):
        return
    uyg._guncelleme_izleniyor = True
    uyg._son_denetim = 0
    kayit("Program açıldı (%s)" % ("arka planda" if uyg.gizli_mi() else "pencere açık"))
    uyg.root.after(5000, lambda: _periyodik(uyg))
    uyg.root.after(DISK_ARALIK_SN * 1000, lambda: _disk_izle(uyg))


def _periyodik(uyg):
    try:
        uyg.root.after(int(GUNCELLEME_ARALIK_DK * 60 * 1000), lambda: _periyodik(uyg))
    except Exception:
        return
    guncelleme_denetle(uyg)


def _disk_surumu():
    import re
    try:
        with open(os.path.join(P.PROGRAM_KLASORU, "st_tanim.py"), encoding="utf-8") as f:
            m = re.search(r'^SURUM = "(.*?)"', f.read(), re.M)
        return m.group(1) if m else None
    except Exception:
        return None


def _disk_izle(uyg):
    """Dosyalar başka yoldan yenilendiyse (elle kopyalama, bu bilgisayardan yayınlama) çalışan program da yenilenir."""
    try:
        uyg.root.after(DISK_ARALIK_SN * 1000, lambda: _disk_izle(uyg))
    except Exception:
        return
    if (getattr(uyg, "_guncelleme_suruyor", False) or getattr(uyg, "_yeniden_bekliyor", False)
            or getattr(uyg, "_yayin_suruyor", False)):
        return
    d = _disk_surumu()
    if d and d != SURUM:
        kayit("Program dosyaları diskte yenilenmiş (diskte %s, çalışan %s) – yeni sürüme geçilecek" % (d, SURUM))
        guncelleme_kuruldu(uyg, d, "")


def guncelleme_denetle(uyg, elle=False):
    """Yeni sürüm yayınlandıysa indirip kurar. elle=True: sonucu bildirimle söyler."""
    if getattr(uyg, "_guncelleme_suruyor", False) or getattr(uyg, "_yayin_suruyor", False):
        return
    if getattr(uyg, "_yeniden_bekliyor", False):
        if elle:
            uyg.kutular.goster("Yeni sürüm zaten kuruldu", "Program yeniden açılınca geçerli olur.",
                               tiklaninca=lambda: uyg.tam_kapat(yeniden=True), renk="#2E9E5B")
        return
    uyg._son_denetim = time.time()
    try:
        kaynak = uyg.db.meta_al("guncelleme_kaynagi")
        otomatik = uyg.db.meta_al("guncelleme_otomatik", "1") != "0"
    except Exception as e:
        kayit("Denetlenemedi: veritabanına ulaşılamadı (%s)" % str(e)[:120], hata=True)
        return
    if not kaynak:
        kayit("Denetlenmedi: henüz yayınlanmış güncelleme yok")
        return
    uyg._guncelleme_suruyor = True

    def bitti_hata(metin):
        uyg._guncelleme_suruyor = False
        kayit(metin, hata=True)
        if elle:
            uyg.kutular.goster("Güncelleme denetlenemedi", metin[:250], renk="#D64538")

    def denetlendi(bilgi, hata):
        if hata:
            return bitti_hata("Denetlenemedi (internet / GitHub): %s" % str(hata)[:200])
        yeni = (bilgi or {}).get("surum") or "0"
        diskte = _disk_surumu() or SURUM
        if P.daha_yeni(diskte, yeni) and diskte != SURUM:
            # bu bilgisayardaki dosyalar yayındakinden yeni (elle kopyalandı): eski paketle üzerine yazılmaz
            uyg._guncelleme_suruyor = False
            kayit("Diskteki dosyalar (%s) yayındakinden (%s) yeni – indirilmedi" % (diskte, yeni))
            return
        if not P.daha_yeni(yeni, SURUM) or not P.daha_yeni(yeni, diskte if P.daha_yeni(diskte, SURUM) else SURUM):
            uyg._guncelleme_suruyor = False
            kayit("Güncel (yayındaki %s)" % yeni)
            if elle:
                uyg.kutular.goster("Program güncel", "Sürüm %s · yayındaki sürüm %s" % (SURUM, yeni), renk="#2E9E5B")
            return
        if not otomatik and not elle:
            uyg._guncelleme_suruyor = False
            kayit("Yeni sürüm %s var; otomatik kurulum kapalı" % yeni)
            return
        kayit("Yeni sürüm %s bulundu, indiriliyor" % yeni)
        if uyg.ana is not None:
            try:
                uyg.ana.bildir("Yeni sürüm %s indiriliyor…" % yeni)
            except Exception:
                pass

        def kuruldu(surum, h):
            if h:
                return bitti_hata("Sürüm %s kurulamadı: %s" % (yeni, str(h)[:200]))
            uyg._guncelleme_suruyor = False
            kayit("Sürüm %s kuruldu" % (surum or yeni))
            guncelleme_kuruldu(uyg, surum or yeni, bilgi.get("notlar") or "")
        arka_plan(uyg.root, lambda: P.guncelleme_kur(bilgi), kuruldu)
    arka_plan(uyg.root, lambda: P.guncelleme_kontrol(kaynak), denetlendi)


def guncelleme_kuruldu(uyg, surum, notlar):
    """Dosyalar yenilendi: program yeni sürümle yeniden açılır. Pencere gizliyse (tepside) ya da giriş ekranındaysa
    hemen; pencere açıksa kullanıcı tıklayınca, pencereyi kapatınca ya da birkaç dakika işlem yapmayınca."""
    uyg.ayarlar["guncelleme_bildir"] = {"surum": surum, "notlar": (notlar or "").strip()}
    try:
        uyg.ayarlari_kaydet()
    except Exception:
        pass
    uyg._yeniden_bekliyor = True
    uyg._bekleyen_surum = surum
    if uyg.ana is not None:
        uyg.ana._yeniden_bekliyor = True
    if uyg.gizli_mi() or uyg.ana is None:
        kayit("Yeniden başlatılıyor (%s)" % ("arka planda" if uyg.gizli_mi() else "giriş ekranı"))
        uyg.tam_kapat(yeniden=True, arka_plan=uyg.gizli_mi())
        return
    try:
        uyg.ana.guncelleme_hazir(surum)
    except Exception:
        pass
    uyg.kutular.goster("Yeni sürüm %s kuruldu" % surum,
                       "Tıklayınca program yeni sürümle yeniden açılır (açık formdaki değişiklikler kaydedilir). "
                       "Tıklamazsanız pencereyi kapattığınızda ya da %d dakika işlem yapılmadığında kendiliğinden geçer."
                       % BOSTA_DK, tiklaninca=lambda: uyg.tam_kapat(yeniden=True, arka_plan=False), renk="#2E9E5B", ses=True)
    _bosta_bekle(uyg)


def _bosta_bekle(uyg):
    """Pencere açıkken: kullanıcı birkaç dakika klavye / fare kullanmazsa ya da pencere gizlenirse yeniden başlatır."""
    if getattr(uyg, "_bosta_izleniyor", False):
        return
    uyg._bosta_izleniyor = True
    uyg._son_hareket = time.time()

    def hareket(_e=None):
        uyg._son_hareket = time.time()
    uyg.root.bind_all("<Any-KeyPress>", hareket, add="+")
    uyg.root.bind_all("<Motion>", hareket, add="+")
    uyg.root.bind_all("<Button>", hareket, add="+")

    def bak():
        try:
            if getattr(uyg, "_yayin_suruyor", False):
                uyg.root.after(20000, bak)
                return
            if uyg.gizli_mi() or uyg.ana is None or time.time() - uyg._son_hareket > BOSTA_DK * 60:
                kayit("Yeni sürüme geçiliyor (pencere %s)" % ("gizli" if uyg.gizli_mi() else "boşta"))
                uyg.tam_kapat(yeniden=True, arka_plan=uyg.gizli_mi())
                return
            uyg.root.after(20000, bak)
        except Exception:
            pass
    uyg.root.after(20000, bak)


def otomatik_yedek_kontrol(ana):
    try:
        if not ana.winfo_exists():
            return
        if ayar(ana, "yedek_otomatik") == "1" and token(ana) and not getattr(ana, "_yedek_suruyor", False):
            son = M.db_zaman_coz(ana.db.meta_al("son_yedek"))
            aralik = float(ayar(ana, "yedek_aralik_saat") or 24)
            if not son or (dt.datetime.now() - son).total_seconds() >= aralik * 3600:
                simdi_yedekle(ana, sessiz=True)
    except Exception:
        pass
    try:
        ana.after(15 * 60 * 1000, lambda: otomatik_yedek_kontrol(ana))
    except Exception:
        pass


def simdi_yedekle(ana, sessiz=False, bitince=None):
    tk_ = token(ana)
    if not tk_:
        if not sessiz:
            messagebox.showwarning("Yedek", "Önce Programcı bölümünde GitHub token'ını girin.")
        return
    ana._yedek_suruyor = True
    sahip, depo = ayar(ana, "gh_kullanici"), ayar(ana, "gh_yedek_depo")
    if ana.db.bulut:
        # bulutta: veriler ayrı bir bağlantıyla arka planda indirilir, program donmaz
        from st_db import VeriTabani
        klasor, bulut = ana.db.klasor, ana.db.bulut

        def is_():
            kopya_db = VeriTabani(klasor, bulut=dict(bulut, zaman_asimi=120), ayna=False)  # ayrı, geçici bağlantı
            try:
                paket, ekler = P.yedek_paketi(kopya_db)
                return P.internete_yedekle(paket, sahip, depo, tk_, ekler=ekler, ek_okuyucu=kopya_db.ek_baytlari)
            finally:
                kopya_db.kapat()
        ana.bildir("İnternet yedeği arka planda alınıyor…")
    else:
        try:
            veri, ekler = P.yedek_paketi(ana.db)  # SQLite kopyası ana iş parçacığında alınır (yerelde hızlı)
        except Exception as e:
            ana._yedek_suruyor = False
            ana.db.meta_yaz("son_yedek_hata", "%s · %s" % (M.simdi_str(), e))
            if not sessiz:
                messagebox.showerror("Yedek alınamadı", str(e))
            return
        ana.bildir("İnternet yedeği yükleniyor… (%d KB)" % (len(veri) // 1024))

        klasor_ = ana.db.klasor

        def ek_oku(e):  # yerel ek dosyası (veritabanına dokunmaz; arka planda güvenle okunur)
            yol = os.path.join(klasor_, e["goreli_yol"])
            if os.path.exists(yol):
                with open(yol, "rb") as f:
                    return f.read()
            return None

        def is_():
            return P.internete_yedekle(veri, sahip, depo, tk_, ekler=ekler, ek_okuyucu=ek_oku)

    def bitti(sonuc, hata):
        ana._yedek_suruyor = False
        if hata:
            ana.db.meta_yaz("son_yedek_hata", "%s · %s" % (M.simdi_str(), hata))
            ana.bildir("İnternet yedeği alınamadı: %s" % hata)
            if not sessiz:
                messagebox.showerror("Yedek alınamadı", str(hata))
        else:
            ad, boyut = sonuc
            ana.db.meta_yaz("son_yedek", dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
            ana.db.meta_yaz("son_yedek_ad", ad)
            ana.db.meta_yaz("son_yedek_hata", "")
            ana.bildir("İnternet yedeği alındı: %s (%d KB)" % (ad, boyut // 1024))
            if not sessiz:
                messagebox.showinfo("Yedek alındı", "Yedek GitHub'a yüklendi:\n%s/%s/%s" % (sahip, depo, ad))
        if bitince:
            bitince()
    arka_plan(ana, is_, bitti)


def _guncelleme_sonucu(ana, bilgi, hata, sessiz=False):
    if hata:
        if not sessiz:
            messagebox.showerror("Güncelleme denetlenemedi", str(hata))
        return
    yeni = (bilgi or {}).get("surum")
    if not yeni or not P.daha_yeni(yeni, SURUM):
        if not sessiz:
            messagebox.showinfo("Güncelleme", "Program güncel (sürüm %s)." % SURUM)
        return
    notlar = (bilgi.get("notlar") or "").strip()
    if not messagebox.askyesno("Yeni sürüm var", "Yeni sürüm: %s  (bu bilgisayarda: %s)\nYayın: %s\n\n%s\n\n"
                                                 "Şimdi kurulsun mu? Program kapanıp yeniden açılacak."
                               % (yeni, SURUM, bilgi.get("tarih", ""), notlar or "")):
        return
    ana._bekleyeni_kaydet()
    ana.bildir("Güncelleme indiriliyor…")

    def bitti(surum, h):
        if h:
            messagebox.showerror("Güncelleme kurulamadı", "%s\n\nProgram eski sürümle çalışmaya devam ediyor." % h)
            return
        messagebox.showinfo("Güncelleme kuruldu", "Sürüm %s kuruldu. Program yeniden açılıyor." % surum)
        try:
            ana.db.kapat()
        finally:
            P.yeniden_baslat()
            ana.root.destroy()
    arka_plan(ana, lambda: P.guncelleme_kur(bilgi), bitti)


# ====================================================================== Programcı şifresi
def _sifre_ozeti(sifre, tuz):
    import hashlib
    return hashlib.pbkdf2_hmac("sha256", sifre.encode("utf-8"), bytes.fromhex(tuz), 200000).hex()


def sifre_kayitli(ana):
    return bool(ana.db.meta_al("programci_sifre"))


def sifre_ayarla(ana, sifre):
    import secrets
    tuz = secrets.token_hex(16)
    ana.db.meta_yaz("programci_sifre", tuz + ":" + _sifre_ozeti(sifre, tuz))


def sifre_dogru(ana, sifre):
    import hmac
    kayit = ana.db.meta_al("programci_sifre")
    if ":" not in kayit:
        return False
    tuz, ozet = kayit.split(":", 1)
    return hmac.compare_digest(_sifre_ozeti(sifre, tuz), ozet)


def sifre_ekrani(ana, ic):
    """Programcı sekmesi şifre girilmeden açılmaz. Şifre ilk kez burada belirlenir (tüm bilgisayarlarda geçerli)."""
    ilk = not sifre_kayitli(ana)
    k = kart(ic)
    k.pack(fill="x")
    gov = tk.Frame(k, bg=KART)
    gov.pack(anchor="w", padx=24, pady=20)
    lbl(gov, "🔒  Programcı bölümü şifreli", boy=14, kalin=True).pack(anchor="w")
    lbl(gov, "Programcı şifresini ilk kez belirleyin. Bu şifre tüm bilgisayarlarda geçerli olur; programa giriş "
             "şifrenizden ayrıdır. Unutmayacağınız bir şifre seçin (en az 6 karakter)." if ilk else
        "Devam etmek için programcı şifresini girin.", fg=SOLUK, wraplength=640).pack(anchor="w", pady=(4, 14))
    v1, v2 = tk.StringVar(), tk.StringVar()
    lbl(gov, "Yeni şifre" if ilk else "Şifre", boy=10, kalin=True).pack(anchor="w")
    e1 = ttk.Entry(gov, textvariable=v1, show="•", width=34)
    e1.pack(anchor="w", pady=(3, 10), ipady=3)
    if ilk:
        lbl(gov, "Yeni şifre (tekrar)", boy=10, kalin=True).pack(anchor="w")
        ttk.Entry(gov, textvariable=v2, show="•", width=34).pack(anchor="w", pady=(3, 10), ipady=3)
    mesaj = lbl(gov, "", fg="#9E2A21")
    mesaj.pack(anchor="w")
    deneme = {"n": 0}

    def tamam(_e=None):
        if ilk:
            if len(v1.get()) < 6:
                mesaj.configure(text="Şifre en az 6 karakter olmalı.")
                return
            if v1.get() != v2.get():
                mesaj.configure(text="Şifreler aynı değil.")
                return
            sifre_ayarla(ana, v1.get())
            ana.db._denetim(ana.k, "Programcı şifresi belirlendi")
            ana.db.c.commit()
        elif not sifre_dogru(ana, v1.get()):
            deneme["n"] += 1
            v1.set("")
            mesaj.configure(text="Şifre yanlış (%d. deneme)." % deneme["n"])
            ana.db._denetim(ana.k, "Programcı bölümüne hatalı şifre denemesi")
            ana.db.c.commit()
            return
        ana._programci_acik = True  # çıkış yapılana kadar açık kalır
        ana.goster("ayarlar", sekme=getattr(ana, "_son_kw", {}).get("sekme", "programci"))
    ttk.Button(gov, text="Şifreyi belirle ve aç" if ilk else "Aç", style="Vurgu.TButton", command=tamam).pack(anchor="w", pady=(6, 0))
    e1.bind("<Return>", tamam)
    e1.focus_set()


def sifre_degistir_penceresi(ana):
    p = tk.Toplevel(ana)
    p.title("Programcı şifresini değiştir")
    p.configure(bg=KART)
    p.transient(ana.root)
    p.grab_set()
    v0, v1, v2 = tk.StringVar(), tk.StringVar(), tk.StringVar()
    for i, (b, v) in enumerate((("Mevcut şifre", v0), ("Yeni şifre", v1), ("Yeni şifre (tekrar)", v2))):
        lbl(p, b, boy=9, kalin=True).grid(row=i, column=0, sticky="w", padx=18, pady=(14 if i == 0 else 6, 0))
        ttk.Entry(p, textvariable=v, show="•", width=30).grid(row=i, column=1, padx=18, pady=(14 if i == 0 else 6, 0))
    msj = lbl(p, "", fg="#9E2A21")
    msj.grid(row=3, column=0, columnspan=2, sticky="w", padx=18)

    def tamam():
        if not sifre_dogru(ana, v0.get()):
            msj.configure(text="Mevcut şifre yanlış.")
            return
        if len(v1.get()) < 6 or v1.get() != v2.get():
            msj.configure(text="Yeni şifre en az 6 karakter olmalı ve iki kez aynı yazılmalı.")
            return
        sifre_ayarla(ana, v1.get())
        ana.db._denetim(ana.k, "Programcı şifresi değiştirildi")
        ana.db.c.commit()
        p.destroy()
        ana.bildir("Programcı şifresi değiştirildi")
    ttk.Button(p, text="Kaydet", style="Vurgu.TButton", command=tamam).grid(row=4, column=1, sticky="e", padx=18, pady=14)
    from st_ortak import ortala
    ortala(p, ana.root)


# ====================================================================== bulut veritabanı
def bulut_bolumu(ana, ic):
    import st_bulut as B
    k = kart(ic)
    k.pack(fill="x", pady=(0, 12))
    lbl(k, "0 · Bulut veritabanı (bütün bilgisayarlar aynı veriyi kullansın)", boy=12, kalin=True).pack(anchor="w", padx=18, pady=(14, 2))
    simdi_ = ("✔ Bu bilgisayar BULUT veritabanını kullanıyor: %s" % ana.db.bulut.get("host")) if ana.db.bulut else \
        "Bu bilgisayar şu an YEREL veritabanını kullanıyor (veriler yalnızca bu bilgisayarda)."
    lbl(k, simdi_, kalin=True, fg="#17603A" if ana.db.bulut else "#8A4300").pack(anchor="w", padx=18)
    lbl(k, "Supabase'de ücretsiz proje açın (bölge: Frankfurt / eu-central-1). Proje sayfasında üstteki 'Connect' düğmesi → "
           "'Session pooler' adresini kopyalayıp aşağıya yapıştırın; şifre kısmına proje oluştururken belirlediğiniz veritabanı "
           "şifresini yazın. Kullanıcılar, yetkiler, siparişler, gemiler ve ekler buluta taşınır; kurulum .exe'si bu bağlantıyı "
           "yeni bilgisayarlara kendisi ekler.", fg=SOLUK, boy=9, wraplength=900).pack(anchor="w", padx=18, pady=(4, 0))
    f = tk.Frame(k, bg=KART)
    f.pack(fill="x", padx=18, pady=10)
    f.columnconfigure(0, weight=3)
    f.columnconfigure(1, weight=1)
    b = ana.ayarlar.get("bulut") or {}
    v_uri = tk.StringVar(value=b.get("uri", ""))
    v_sif = tk.StringVar(value=P.sifre_coz(b.get("sifre", "")))
    lbl(f, "Bağlantı adresi (Session pooler – postgresql://…)", boy=9, kalin=True).grid(row=0, column=0, sticky="w")
    lbl(f, "Veritabanı şifresi", boy=9, kalin=True).grid(row=0, column=1, sticky="w", padx=(10, 0))
    ttk.Entry(f, textvariable=v_uri).grid(row=1, column=0, sticky="ew", pady=(3, 0))
    ttk.Entry(f, textvariable=v_sif, show="•").grid(row=1, column=1, sticky="ew", padx=(10, 0), pady=(3, 0))
    durum = lbl(k, "", boy=9, wraplength=900)
    durum.pack(anchor="w", padx=18)

    def ayar_al():
        return B.uri_coz(v_uri.get(), v_sif.get().strip())

    def test():
        durum.configure(text="Bağlanılıyor… (ilk seferde bulut sürücüsü kurulur, 1 dakika sürebilir)", fg=SOLUK)

        def is_():
            if not B.surucu_hazir(kur=True):
                raise B.BulutHatasi("Bulut sürücüsü (pg8000) kurulamadı.")
            bg = B.Baglanti(ayar_al())
            try:
                B.sema_kur(bg)
                ku = bg.execute("SELECT COUNT(*) FROM kullanicilar").fetchone()[0]
                si = bg.execute("SELECT COUNT(*) FROM siparisler").fetchone()[0]
                return ku, si
            finally:
                bg.close()

        def bitti(s, h):
            if h:
                durum.configure(text="✖ %s" % h, fg="#9E2A21")
                return
            durum.configure(text="✔ Bağlantı tamam. Bulutta %d kullanıcı, %d sipariş var." % s, fg="#17603A")
        arka_plan(durum, is_, bitti)

    def bagla():
        try:
            ayar = ayar_al()
        except Exception as e:
            durum.configure(text="✖ %s" % e, fg="#9E2A21")
            return
        yerel = None
        if not ana.db.bulut:
            yerel = (ana.db.yol, ana.db.klasor, ana.db.kullanici_sayisi(), len(ana.db.siparis_listesi()))
        durum.configure(text="Bağlanılıyor…", fg=SOLUK)

        def is_():
            if not B.surucu_hazir(kur=True):
                raise B.BulutHatasi("Bulut sürücüsü (pg8000) kurulamadı.")
            bg = B.Baglanti(ayar)
            try:
                B.sema_kur(bg)
                return bg.execute("SELECT COUNT(*) FROM kullanicilar").fetchone()[0]
            finally:
                bg.close()

        def bitti(bulut_kul, h):
            if h:
                durum.configure(text="✖ %s" % h, fg="#9E2A21")
                return
            aktar = False
            if yerel and yerel[2] and not bulut_kul:
                aktar = messagebox.askyesno("Verileri buluta aktar", "Bulut veritabanı boş.\n\nBu bilgisayardaki veriler "
                                            "(%d kullanıcı, %d sipariş, ekler) buluta aktarılsın mı?\n\nÖnerilen: Evet. Yerel "
                                            "veriler silinmez, veri klasöründe kalır." % (yerel[2], yerel[3]))
            elif yerel and yerel[2] and bulut_kul:
                if not messagebox.askyesno("Bulutta veri var", "Bulutta zaten %d kullanıcı var. Bu bilgisayar bulut verisini "
                                           "kullanacak; bu bilgisayardaki yerel veriler buluta AKTARILMAZ (silinmez, veri "
                                           "klasöründe kalır).\n\nDevam edilsin mi?" % bulut_kul):
                    durum.configure(text="Vazgeçildi.", fg=SOLUK)
                    return

            def kaydet_ve_yeniden():
                ana.ayarlar["bulut"] = {"uri": B.uri_sifresiz(v_uri.get()), "sifre": P.sifre_sakla(ayar["password"])}
                ana.ayarlar_kaydet()
                messagebox.showinfo("Bulut veritabanı", "Bu bilgisayar artık bulut veritabanını kullanacak. Program yeniden "
                                                        "açılıyor; kullanıcı adınız ve şifrenizle giriş yapın.")
                ana._bekleyeni_kaydet()
                ana.db.kapat()
                P.yeniden_baslat()
                ana.root.destroy()
            if not aktar:
                kaydet_ve_yeniden()
                return
            durum.configure(text="Veriler buluta aktarılıyor… (birkaç dakika sürebilir, programı kapatmayın)", fg=SOLUK)
            ana.db.c.commit()

            def aktar_is():
                from st_db import VeriTabani
                hedef = VeriTabani(yerel[1], bulut=ayar)
                try:
                    hedef.ice_aktar(yerel[0], yerel[1], log=lambda m: None)
                finally:
                    hedef.kapat()

            def aktar_bitti(_s, h2):
                if h2:
                    durum.configure(text="✖ Aktarım hatası: %s" % h2, fg="#9E2A21")
                    messagebox.showerror("Aktarım", str(h2))
                    return
                durum.configure(text="✔ Veriler buluta aktarıldı.", fg="#17603A")
                kaydet_ve_yeniden()
            arka_plan(durum, aktar_is, aktar_bitti)
        arka_plan(durum, is_, bitti)

    def ayril():
        if not messagebox.askyesno("Buluttan ayrıl", "Bu bilgisayar bulut yerine yeniden YEREL veritabanını kullansın mı?\n"
                                                     "(Bulut verileri silinmez; diğer bilgisayarlar etkilenmez.)"):
            return
        ana.ayarlar.pop("bulut", None)
        ana.ayarlar_kaydet()
        ana._bekleyeni_kaydet()
        ana.db.kapat()
        P.yeniden_baslat()
        ana.root.destroy()
    dz = tk.Frame(k, bg=KART)
    dz.pack(fill="x", padx=18, pady=(6, 14))
    ttk.Button(dz, text="Bağlantıyı test et", command=test).pack(side="left")
    if ana.db.bulut:
        ttk.Button(dz, text="Bağlantı bilgisini güncelle", style="Vurgu.TButton", command=bagla).pack(side="left", padx=8)
        ttk.Button(dz, text="Buluttan ayrıl (yerel veriye dön)", style="Tehlike.TButton", command=ayril).pack(side="left")
    else:
        ttk.Button(dz, text="Bu bilgisayarı buluta bağla", style="Vurgu.TButton", command=bagla).pack(side="left", padx=8)
    if ana.db.bulut:
        ekip_kullanicisi_karti(ana, ic)


def ekip_kullanicisi_karti(ana, ic):
    """Güvenlik: ekip bilgisayarları yönetici (postgres) şifresiyle değil, kısıtlı bir kullanıcıyla bağlanır.
    Bu kullanıcı tablo silemez, işlem geçmişini değiştiremez / silemez, verileri kalıcı silemez."""
    import st_bulut as B
    k = kart(ic)
    k.pack(fill="x", pady=(0, 14))
    lbl(k, "0b · Güvenli ekip kullanıcısı", boy=13, kalin=True).pack(anchor="w", padx=18, pady=(14, 4))
    try:
        yonetici = B.yonetici_mi(ana.db.c)
        var = B.rol_var_mi(ana.db.c)
    except Exception as e:
        lbl(k, "Durum okunamadı (bağlantı yok?): %s" % e, fg="#9E2A21").pack(anchor="w", padx=18, pady=(0, 14))
        return
    if not yonetici:
        lbl(k, "✔ Bu bilgisayar kısıtlı ekip kullanıcısıyla bağlı (güvenli).", fg="#17603A", kalin=True).pack(
            anchor="w", padx=18, pady=(0, 14))
        return
    ekip = ana.ayarlar.get("bulut_ekip")
    lbl(k, ("✔ Ekip kullanıcısı hazır. Kurulum .exe'si yönetici şifresi yerine bu kullanıcıyı ekler."
            if (var and ekip) else
            "⚠ Henüz yok: kurulum .exe'si şu an YÖNETİCİ veritabanı şifresini içeriyor."),
        fg="#17603A" if (var and ekip) else "#8A4300", kalin=True).pack(anchor="w", padx=18)
    lbl(k, "Ekip bilgisayarları kısıtlı bir veritabanı kullanıcısıyla bağlanır: verileri okuyup yazabilir ama tabloları "
           "silemez, işlem geçmişini değiştiremez veya silemez, siparişleri kalıcı olarak silemez. Yönetici şifresi yalnızca "
           "bu bilgisayarda kalır. Oluşturduktan sonra yeni kurulum .exe'si üretip diğer bilgisayarlara yeniden kurun.",
        fg=SOLUK, wraplength=900).pack(anchor="w", padx=18, pady=(4, 8))
    durum = lbl(k, "", fg=SOLUK)

    def olustur():
        yenile = var and ekip
        if not messagebox.askyesno("Ekip kullanıcısı",
                                   ("Ekip kullanıcısının şifresi YENİLENSİN mi?\n\nEski kurulumlarla açılan bilgisayarlar "
                                    "bağlanamaz hale gelir; hepsine yeni kurulum .exe'si kurmanız gerekir."
                                    if yenile else
                                    "Güvenli ekip kullanıcısı oluşturulsun mu?\n\nSonra yeni kurulum .exe'si üretip "
                                    "diğer bilgisayarlara yeniden kurun.")):
            return
        try:
            sifre = B.rol_olustur(ana.db.c)
            b = ana.ayarlar.get("bulut") or {}
            m = B._uri_parcala(b.get("uri", ""))
            uri = "postgresql://%s@%s:%s/%s" % (B.rol_kullanici_adi(m.group("user")), m.group("host"),
                                                 m.group("port") or 5432, m.group("db") or "postgres")
            # bağlanabildiğini doğrula
            deneme = B.Baglanti(B.uri_coz(uri, sifre))
            deneme.taze("SELECT count(*) FROM siparisler")
            deneme.close()
        except Exception as e:
            messagebox.showerror("Ekip kullanıcısı", "Oluşturulamadı:\n%s" % e)
            return
        ana.ayarlar["bulut_ekip"] = {"uri": uri, "sifre": P.sifre_sakla(sifre)}
        ana.ayarlar_kaydet()
        durum.configure(text="✔ Ekip kullanıcısı hazır (%s). Şimdi 5. bölümden yeni kurulum .exe'si oluşturun." % uri,
                        fg="#17603A")
    ttk.Button(k, text=("Ekip kullanıcısının şifresini yenile" if (var and ekip) else "Güvenli ekip kullanıcısını oluştur"),
               style="Vurgu.TButton", command=olustur).pack(anchor="w", padx=18)
    durum.pack(anchor="w", padx=18, pady=(6, 14))


# ====================================================================== Programcı ekranı
def programci_bolumu(ana, ic):
    ust_ = tk.Frame(ic, bg=ZEMIN)
    ust_.pack(fill="x", pady=(0, 8))
    ttk.Button(ust_, text="🔒 Kilitle", command=lambda: (setattr(ana, "_programci_acik", False),
                                                       ana.goster("ayarlar", sekme="programci"))).pack(side="right")
    ttk.Button(ust_, text="Programcı şifresini değiştir", command=lambda: sifre_degistir_penceresi(ana)).pack(side="right", padx=8)
    bant(ic, "Bu bölüm programın bakımı içindir: güncellemeleri ekibe yayınlar ve verileri internete (GitHub, gizli depo) "
             "yedekler. GitHub token'ı yalnızca bu bilgisayarda şifreli saklanır.", "bilgi").pack(fill="x", pady=(0, 12))
    bulut_bolumu(ana, ic)

    # ---------------------------------------------------------------- GitHub bağlantısı
    k = kart(ic)
    k.pack(fill="x")
    lbl(k, "1 · GitHub bağlantısı", boy=12, kalin=True).pack(anchor="w", padx=18, pady=(14, 2))
    lbl(k, "Token almak için: github.com → Settings → Developer settings → Personal access tokens → Tokens (classic) → "
           "Generate new token → 'repo' iznini işaretleyin. Gemi Sefer Takibi'nde kullandığınız token da olur "
           "(gizli yedek deposu için 'repo' izni gerekli).", fg=SOLUK, boy=9, wraplength=900).pack(anchor="w", padx=18)
    f = tk.Frame(k, bg=KART)
    f.pack(fill="x", padx=18, pady=10)
    v = {}
    alanlar = [("gh_kullanici", "GitHub kullanıcı adı"), ("gh_guncelleme_depo", "Güncelleme deposu (herkese açık)"),
               ("gh_yedek_depo", "Yedek deposu (gizli)")]
    for i, (a, b) in enumerate(alanlar):
        f.columnconfigure(i, weight=1, uniform="gh")
        lbl(f, b, boy=9, kalin=True).grid(row=0, column=i, sticky="w", padx=(0, 10))
        v[a] = tk.StringVar(value=ayar(ana, a))
        ttk.Entry(f, textvariable=v[a]).grid(row=1, column=i, sticky="ew", padx=(0, 10), pady=(3, 0))
    lbl(f, "GitHub token (bu bilgisayar)", boy=9, kalin=True).grid(row=2, column=0, sticky="w", pady=(10, 0))
    v_tok = tk.StringVar(value=token(ana))
    ttk.Entry(f, textvariable=v_tok, show="•").grid(row=3, column=0, columnspan=2, sticky="ew", padx=(0, 10), pady=(3, 0))
    durum = lbl(k, "Token kayıtlı." if token(ana) else "Token girilmedi – güncelleme yayınlama ve internet yedeği çalışmaz.",
                fg="#17603A" if token(ana) else "#9E2A21", boy=9)
    durum.pack(anchor="w", padx=18)

    def kaydet(test=False):
        for a, var in v.items():
            ana.db.meta_yaz(a, var.get().strip())
        ana.ayarlar["gh_token"] = P.sifre_sakla(v_tok.get().strip())
        ana.ayarlar_kaydet()
        durum.configure(text="Kaydedildi.", fg="#17603A")
        if not test:
            return
        durum.configure(text="GitHub'a bağlanılıyor…", fg=SOLUK)
        sahip, tk_ = v["gh_kullanici"].get().strip(), v_tok.get().strip()

        def is_():
            m1 = P.depo_hazirla(sahip, v["gh_guncelleme_depo"].get().strip(), tk_, gizli=False)
            m2 = P.depo_hazirla(sahip, v["gh_yedek_depo"].get().strip(), tk_, gizli=True)
            return m1, m2

        def bitti(s, h):
            if h:
                durum.configure(text="✖ %s" % h, fg="#9E2A21")
                return
            (o1, m1), (o2, m2) = s
            durum.configure(text=("✔ " if o1 else "✖ ") + "Güncelleme: " + m1 + "     " + ("✔ " if o2 else "✖ ") + "Yedek: " + m2,
                            fg="#17603A" if (o1 and o2) else "#9E2A21")
        arka_plan(durum, is_, bitti)
    dz = tk.Frame(k, bg=KART)
    dz.pack(fill="x", padx=18, pady=(6, 14))
    ttk.Button(dz, text="Kaydet", command=kaydet).pack(side="left")
    ttk.Button(dz, text="Kaydet ve bağlantıyı test et", style="Vurgu.TButton", command=lambda: kaydet(True)).pack(side="left", padx=8)

    # ---------------------------------------------------------------- güncelleme yayınla
    k = kart(ic)
    k.pack(fill="x", pady=12)
    lbl(k, "2 · Güncelleme yayınla (ekibe gönder)", boy=12, kalin=True).pack(anchor="w", padx=18, pady=(14, 2))
    lbl(k, "Bu bilgisayardaki program dosyaları paketlenip güncelleme deposuna yüklenir. Ekipteki programlar açılışta yeni "
           "sürümü görür, kullanıcıya sorar, kurar ve yeniden açılır. Veriler ve ayarlar etkilenmez; eski dosyalar _yedek "
           "klasörüne alınır.", fg=SOLUK, boy=9, wraplength=900).pack(anchor="w", padx=18)
    f = tk.Frame(k, bg=KART)
    f.pack(fill="x", padx=18, pady=10)
    yayin_lbl = lbl(f, "Bu bilgisayar: %s   ·   Yayındaki sürüm: denetlenmedi" % SURUM, kalin=True)
    yayin_lbl.grid(row=0, column=0, columnspan=3, sticky="w")
    lbl(f, "Yeni sürüm numarası", boy=9, kalin=True).grid(row=1, column=0, sticky="w", pady=(10, 0))
    v_surum = tk.StringVar(value=P.sonraki_surum(SURUM))
    ttk.Entry(f, textvariable=v_surum, width=16).grid(row=2, column=0, sticky="w", pady=(3, 0))
    lbl(f, "Yenilikler (kullanıcılara gösterilir)", boy=9, kalin=True).grid(row=1, column=1, sticky="w", padx=(16, 0), pady=(10, 0))
    t_not = tk.Text(f, height=3, width=80, font=("Segoe UI", 10), relief="solid", bd=1)
    t_not.grid(row=2, column=1, sticky="ew", padx=(16, 0), pady=(3, 0))
    f.columnconfigure(1, weight=1)
    yayin_durum = lbl(k, "", boy=9)
    yayin_durum.pack(anchor="w", padx=18)

    def yayinda_ne_var():
        kaynak = ana.db.meta_al("guncelleme_kaynagi")
        if not kaynak:
            yayin_lbl.configure(text="Bu bilgisayar: %s   ·   Henüz güncelleme yayınlanmadı" % SURUM)
            return
        yayin_lbl.configure(text="Bu bilgisayar: %s   ·   Yayındaki sürüm denetleniyor…" % SURUM)
        arka_plan(yayin_lbl, lambda: P.guncelleme_kontrol(kaynak),
                  lambda b, h: yayin_lbl.configure(text="Bu bilgisayar: %s   ·   Yayındaki sürüm: %s" %
                                                   (SURUM, ("ulaşılamadı (%s)" % h) if h else "%s (%s)" % (b.get("surum"), b.get("tarih")))))

    def yayinla():
        tk_ = token(ana)
        if not tk_:
            messagebox.showwarning("Güncelleme", "Önce GitHub token'ını girip kaydedin (1. bölüm).")
            return
        surum = v_surum.get().strip()
        if not P.surum_tuple(surum) or not P.daha_yeni(surum, "0"):
            messagebox.showwarning("Sürüm", "Geçerli bir sürüm numarası yazın (örn. %s)." % P.sonraki_surum(SURUM))
            return
        notlar = t_not.get("1.0", "end").strip()
        if not messagebox.askyesno("Güncelleme yayınla", "Sürüm %s ekibe yayınlansın mı?\n\nEkipteki programlar (arka "
                                                         "plandakiler dahil) %d dakika içinde kendiliğinden kurar." % (surum, GUNCELLEME_ARALIK_DK)):
            return
        yayin_durum.configure(text="Yükleniyor…", fg=SOLUK)
        sahip, depo = ayar(ana, "gh_kullanici"), ayar(ana, "gh_guncelleme_depo")
        uyg_ = getattr(ana, "uygulama", None)
        if uyg_ is not None:
            uyg_._yayin_suruyor = True  # yükleme bitmeden bu bilgisayar kendini yeniden başlatmasın

        def bitti(s, h):
            if uyg_ is not None:
                uyg_._yayin_suruyor = False
            if h:
                yayin_durum.configure(text="✖ %s" % h, fg="#9E2A21")
                messagebox.showerror("Yayınlanamadı", str(h))
                return
            bilgi, kaynak = s
            ana.db.meta_yaz("guncelleme_kaynagi", kaynak)
            yayin_durum.configure(text="✔ Sürüm %s yayınlandı (%s). Program yeniden açılınca bu bilgisayar da %s olarak görünür."
                                  % (bilgi["surum"], bilgi["tarih"], bilgi["surum"]), fg="#17603A")
            messagebox.showinfo("Yayınlandı", "Sürüm %s ekibe yayınlandı." % bilgi["surum"])
        arka_plan(yayin_durum, lambda: P.guncelleme_yayinla(sahip, depo, tk_, surum, notlar, ana.k["ad"]), bitti)
    dz = tk.Frame(k, bg=KART)
    dz.pack(fill="x", padx=18, pady=(6, 14))
    ttk.Button(dz, text="Güncellemeyi yayınla", style="Vurgu.TButton", command=yayinla).pack(side="left")
    ttk.Button(dz, text="Yayındaki sürümü göster", command=yayinda_ne_var).pack(side="left", padx=8)

    # ---------------------------------------------------------------- güncelleme kontrolü
    k = kart(ic)
    k.pack(fill="x")
    lbl(k, "3 · Bu bilgisayarın güncellemeleri", boy=12, kalin=True).pack(anchor="w", padx=18, pady=(14, 2))
    kaynak = ana.db.meta_al("guncelleme_kaynagi")
    lbl(k, "Güncelleme kaynağı: %s" % (kaynak or "henüz yok (ilk güncelleme yayınlanınca otomatik ayarlanır)"),
        fg=SOLUK, boy=9).pack(anchor="w", padx=18)
    v_oto = tk.BooleanVar(value=ayar(ana, "guncelleme_otomatik") == "1")
    ttk.Checkbutton(k, text="Yeni sürümü otomatik kur (tüm bilgisayarlar · %d dakikada bir denetlenir, program arka "
                            "plandayken de)" % GUNCELLEME_ARALIK_DK, variable=v_oto,
                    command=lambda: ana.db.meta_yaz("guncelleme_otomatik", "1" if v_oto.get() else "0")).pack(anchor="w", padx=18, pady=(8, 0))
    durum_lbl = lbl(k, "", boy=9, wraplength=900)
    durum_lbl.pack(anchor="w", padx=18, pady=(8, 0))

    def durum_yaz():
        try:
            if not durum_lbl.winfo_exists():
                return
            durum_lbl.configure(text="Son denetim: %s  ·  %s" % (DURUM["son"] or "—", DURUM["sonuc"]),
                                fg="#9E2A21" if DURUM["hata"] else "#17603A")
            durum_lbl.after(3000, durum_yaz)
        except Exception:
            pass
    durum_yaz()
    dz3 = tk.Frame(k, bg=KART)
    dz3.pack(anchor="w", padx=18, pady=(8, 14))

    def denetle():
        uyg = getattr(ana, "uygulama", None)
        if uyg is None:
            messagebox.showinfo("Güncelleme", "Bu ekrandan denetlenemiyor.")
            return
        guncelleme_denetle(uyg, elle=True)
        ana.bildir("Güncelleme denetleniyor…")

    def kaydi_ac():
        if not os.path.exists(KAYIT_DOSYASI):
            messagebox.showinfo("Güncelleme kaydı", "Henüz kayıt yok.")
            return
        from st_arayuz import dosya_ac
        dosya_ac(KAYIT_DOSYASI)
    ttk.Button(dz3, text="Güncellemeleri şimdi denetle", command=denetle).pack(side="left")
    ttk.Button(dz3, text="Güncelleme kaydını aç", command=kaydi_ac).pack(side="left", padx=8)

    # ---------------------------------------------------------------- internet yedeği
    k = kart(ic)
    k.pack(fill="x", pady=12)
    lbl(k, "4 · İnternete otomatik yedek", boy=12, kalin=True).pack(anchor="w", padx=18, pady=(14, 2))
    lbl(k, "Veritabanı ve tüm ekler zip olarak GİZLİ GitHub deposuna yüklenir; son %d yedek tutulur. Yedeği, token'ı kayıtlı "
           "ve programı açık olan bilgisayar alır." % P.TUTULACAK_YEDEK, fg=SOLUK, boy=9, wraplength=900).pack(anchor="w", padx=18)
    f = tk.Frame(k, bg=KART)
    f.pack(fill="x", padx=18, pady=10)
    v_yo = tk.BooleanVar(value=ayar(ana, "yedek_otomatik") == "1")
    ttk.Checkbutton(f, text="Otomatik yedek açık", variable=v_yo,
                    command=lambda: ana.db.meta_yaz("yedek_otomatik", "1" if v_yo.get() else "0")).pack(side="left")
    lbl(f, "   Sıklık:").pack(side="left")
    ad_ = {d: a for a, d in ARALIKLAR}
    v_ar = tk.StringVar(value=ad_.get(ayar(ana, "yedek_aralik_saat"), "Her gün"))
    cb = ttk.Combobox(f, textvariable=v_ar, values=[a for a, _ in ARALIKLAR], state="readonly", width=18)
    cb.pack(side="left", padx=6)
    cb.bind("<<ComboboxSelected>>", lambda e: ana.db.meta_yaz("yedek_aralik_saat", dict(ARALIKLAR)[v_ar.get()]))
    son = ana.db.meta_al("son_yedek")
    hata = ana.db.meta_al("son_yedek_hata")
    lbl(k, "Son yedek: %s %s" % (M.db_zaman_goster(son) if son else "henüz alınmadı", ("· " + ana.db.meta_al("son_yedek_ad")) if son else ""),
        kalin=True).pack(anchor="w", padx=18)
    if hata:
        lbl(k, "Son hata: " + hata, fg="#9E2A21", boy=9, wraplength=900).pack(anchor="w", padx=18)

    liste_k = tk.Frame(k, bg=KART)
    liste_k.pack(fill="x", padx=18, pady=(8, 0))
    tv = ttk.Treeview(liste_k, columns=("ad", "boyut"), show="headings", height=6)
    tv.heading("ad", text="GitHub'daki yedekler")
    tv.heading("boyut", text="Boyut")
    tv.column("ad", width=420)
    tv.column("boyut", width=100)
    tv.pack(fill="x")
    yedekler = {}

    def listele():
        tk_ = token(ana)
        if not tk_:
            messagebox.showwarning("Yedek", "Önce GitHub token'ını girin.")
            return
        tv.delete(*tv.get_children())
        tv.insert("", "end", values=("Yükleniyor…", ""))

        def bitti(s, h):
            tv.delete(*tv.get_children())
            yedekler.clear()
            if h:
                tv.insert("", "end", values=("Liste alınamadı: %s" % h, ""))
                return
            if not s:
                tv.insert("", "end", values=("Henüz yedek yok", ""))
            for y in s:
                yedekler[y["path"]] = y
                tv.insert("", "end", iid=y["path"], values=(y["name"], "%d KB" % (y.get("size", 0) // 1024)))
        arka_plan(tv, lambda: P.yedekleri_listele(ayar(ana, "gh_kullanici"), ayar(ana, "gh_yedek_depo"), tk_), bitti)

    def geri_yukle():
        sec = tv.selection()
        if not sec or sec[0] not in yedekler:
            messagebox.showinfo("Geri yükle", "Önce listeden bir yedek seçin (listeyi yenileyin).")
            return
        yol = sec[0]
        if not messagebox.askyesno("Yedeği geri yükle", "%s geri yüklensin mi?\n\nŞu anki veriler SİLİNMEZ, veri klasöründe "
                                                         "_onceki_… klasörüne alınır. Program yeniden açılacak.\n\n"
                                                         "Ekipteki diğer bilgisayarlarda program açıksa önce kapatılmalı."
                                   % yedekler[yol]["name"]):
            return
        ana.bildir("Yedek indiriliyor…")

        def bitti(s, h):
            if h:
                messagebox.showerror("Geri yüklenemedi", str(h))
                return
            messagebox.showinfo("Geri yükleme", "Yedek indirildi. Program yeniden açılırken geri yüklenecek.")
            ana._bekleyeni_kaydet()
            ana.db.kapat()
            P.yeniden_baslat()
            ana.root.destroy()
        arka_plan(ana, lambda: P.yedegi_indir(ayar(ana, "gh_kullanici"), ayar(ana, "gh_yedek_depo"), token(ana),
                                              yol, ana.db.klasor), bitti)
    dz = tk.Frame(k, bg=KART)
    dz.pack(fill="x", padx=18, pady=(8, 14))
    ttk.Button(dz, text="Şimdi yedekle", style="Vurgu.TButton",
               command=lambda: simdi_yedekle(ana, bitince=lambda: ana.goster("ayarlar", sekme="programci"))).pack(side="left")
    ttk.Button(dz, text="Yedekleri listele", command=listele).pack(side="left", padx=8)
    ttk.Button(dz, text="Seçili yedeği geri yükle", style="Tehlike.TButton", command=geri_yukle).pack(side="left")

    # ---------------------------------------------------------------- oto kurulum .exe
    oto_kurulum_bolumu(ana, ic)


def oto_kurulum_bolumu(ana, ic):
    import os
    k = kart(ic)
    k.pack(fill="x")
    lbl(k, "5 · Oto Kurulum (.exe) – başka bilgisayara kurmak için", boy=12, kalin=True).pack(anchor="w", padx=18, pady=(14, 2))
    lbl(k, "Tek bir kurulum dosyası (.exe) oluşturur. Yeni bilgisayarda çift tıklanınca: Python yoksa indirip kurar, gerekli "
           "kütüphaneleri (openpyxl, requests, pywin32) kurar, programı kurulum klasörüne açar, masaüstüne simgeli kısayol "
           "koyar ve programı başlatır. Program açılınca GitHub'dan en son sürümü kendisi denetler. Yeni bilgisayarda "
           "internet gerekir; yönetici izni gerekmez.", fg=SOLUK, boy=9, wraplength=900).pack(anchor="w", padx=18)
    f = tk.Frame(k, bg=KART)
    f.pack(fill="x", padx=18, pady=10)
    f.columnconfigure(0, weight=1, uniform="ok")
    f.columnconfigure(1, weight=1, uniform="ok")
    v_cikti = tk.StringVar(value=ana.ayarlar.get("exe_cikti") or os.path.join(os.path.dirname(P.PROGRAM_KLASORU), "KURULUM"))
    v_hedef = tk.StringVar(value=ana.db.meta_al("exe_kurulum_klasoru", r"%USERPROFILE%\SiparisGemiTakip"))
    v_veri = tk.StringVar(value=ana.db.meta_al("exe_veri_klasoru", ""))
    for i, (b, v) in enumerate((("Yeni bilgisayarda kurulum klasörü", v_hedef),
                                ("Ortak veri klasörü (ekip aynı veriyi görecekse; boş = her bilgisayar kendi verisi)", v_veri),
                                (".exe'nin kaydedileceği klasör (bu bilgisayar)", v_cikti))):
        lbl(f, b, boy=9, kalin=True).grid(row=i * 2, column=0, columnspan=2, sticky="w", pady=(8 if i else 0, 0))
        ttk.Entry(f, textvariable=v).grid(row=i * 2 + 1, column=0, columnspan=2, sticky="ew", pady=(3, 0))
    v_bulut = tk.BooleanVar(value=bool(ana.db.bulut))
    cb_b = ttk.Checkbutton(k, text="Bulut veritabanı bağlantısını kurulum dosyasına ekle (yeni bilgisayar doğrudan ortak veriye bağlanır)",
                           variable=v_bulut)
    cb_b.pack(anchor="w", padx=18, pady=(0, 8))
    if not ana.db.bulut:
        cb_b.state(["disabled"])
    t = tk.Text(k, height=9, font=("Consolas", 9), bg="#F5F7F9", relief="flat")
    t.pack(fill="x", padx=18)
    t.insert("end", "Hazır. 'Kurulum .exe oluştur' düğmesine basın.\n")
    import queue
    q = queue.Queue()

    def log(m):
        q.put(m)

    def akit():
        try:
            if not t.winfo_exists():
                return
        except Exception:
            return
        try:
            while True:
                t.insert("end", q.get_nowait() + "\n")
                t.see("end")
        except queue.Empty:
            pass
        t.after(200, akit)
    akit()

    def olustur():
        ana.db.meta_yaz("exe_kurulum_klasoru", v_hedef.get().strip())
        ana.db.meta_yaz("exe_veri_klasoru", v_veri.get().strip())
        ana.ayarlar["exe_cikti"] = v_cikti.get().strip()
        ana.ayarlar_kaydet()
        btn.state(["disabled"])
        t.delete("1.0", "end")
        log("Oluşturma başladı (sürüm %s)…" % SURUM)

        def bitti(exe, h):
            try:
                btn.state(["!disabled"])
            except Exception:
                pass
            if h:
                log("\n✖ %s" % h)
                messagebox.showerror("Kurulum dosyası oluşturulamadı", str(h)[:900])
                return
            log("\nKurulum dosyasını USB bellek / e-posta / ortak klasörle yeni bilgisayara taşıyıp çift tıklayın.")
            if messagebox.askyesno("Hazır", "Kurulum dosyası oluşturuldu:\n%s\n\nKlasör açılsın mı?" % exe):
                import st_arayuz
                st_arayuz.dosya_ac(os.path.dirname(exe))
        bulut = None
        if v_bulut.get() and ana.db.bulut and ana.ayarlar.get("bulut"):
            kaynak = ana.ayarlar.get("bulut_ekip") or ana.ayarlar["bulut"]
            bulut = {"uri": kaynak["uri"], "sifre": P.sifre_coz(kaynak["sifre"])}
            if ana.ayarlar.get("bulut_ekip"):
                log("Kurulum dosyasına kısıtlı EKİP kullanıcısı ekleniyor (yönetici şifresi eklenmez).")
            else:
                log("UYARI: Güvenli ekip kullanıcısı oluşturulmamış; kurulum dosyasına YÖNETİCİ şifresi ekleniyor. "
                    "Programcı → 0b bölümünden oluşturmanız önerilir.")
        arka_plan(t, lambda: P.kurulum_exe_olustur(v_cikti.get().strip(), SURUM, v_hedef.get().strip(),
                                                    v_veri.get().strip(), log, bulut=bulut), bitti)
    dz = tk.Frame(k, bg=KART)
    dz.pack(fill="x", padx=18, pady=(8, 14))
    btn = ttk.Button(dz, text="Kurulum .exe oluştur", style="Vurgu.TButton", command=olustur)
    btn.pack(side="left")
    lbl(dz, "Not: Bazı antivirüs programları yeni oluşturulan .exe'yi ilk açılışta sorgulayabilir; 'yine de çalıştır' deyin.",
        fg=SOLUK, boy=8).pack(side="left", padx=12)
