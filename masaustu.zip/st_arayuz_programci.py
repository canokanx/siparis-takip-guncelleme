# -*- coding: utf-8 -*-
"""Ayarlar → Programcı bölümü: GitHub bağlantısı, güncelleme yayınlama / kurma, internete otomatik yedek."""
import datetime as dt
import threading
import tkinter as tk
from tkinter import ttk, messagebox

import st_programci as P
import st_mantik as M
from st_tanim import SURUM, ZEMIN, KART, SOLUK
from st_ortak import kart, lbl, bant

VARSAYILAN = {"gh_kullanici": "canokanx", "gh_guncelleme_depo": "siparis-takip-guncelleme",
              "gh_yedek_depo": "siparis-takip-yedek", "yedek_otomatik": "1", "yedek_aralik_saat": "24",
              "guncelleme_otomatik": "1"}
ARALIKLAR = [("Her 6 saatte bir", "6"), ("Her 12 saatte bir", "12"), ("Her gün", "24"), ("Haftada bir", "168")]


def ayar(ana, anahtar):
    return ana.db.meta_al(anahtar, VARSAYILAN.get(anahtar, ""))


def token(ana):
    return P.sifre_coz(ana.ayarlar.get("gh_token", ""))


def arka_plan(widget, is_, bitince):
    """is_() arka planda çalışır; bitince(sonuc, hata) arayüzde çağrılır."""
    kutu = {}

    def calis():
        try:
            kutu["s"] = is_()
        except Exception as e:  # noqa
            kutu["h"] = e
    t = threading.Thread(target=calis, daemon=True)
    t.start()

    def bekle():
        try:
            if not widget.winfo_exists():
                return
        except Exception:
            return
        if t.is_alive():
            widget.after(300, bekle)
        else:
            bitince(kutu.get("s"), kutu.get("h"))
    bekle()


# ====================================================================== açılış ve periyodik işler
def acilis_kontrolleri(ana):
    """Program açıldıktan birkaç saniye sonra: güncelleme denetimi. Sonra periyodik yedek kontrolü başlar."""
    kaynak = ana.db.meta_al("guncelleme_kaynagi")
    if kaynak and ayar(ana, "guncelleme_otomatik") == "1":
        arka_plan(ana, lambda: P.guncelleme_kontrol(kaynak),
                  lambda b, h: _guncelleme_sonucu(ana, b, h, sessiz=True))
    ana.after(20000, lambda: otomatik_yedek_kontrol(ana))


def otomatik_yedek_kontrol(ana):
    try:
        if not ana.winfo_exists():
            return
        if ayar(ana, "yedek_otomatik") == "1" and token(ana) and not getattr(ana, "_yedek_suruyor", False):
            son = M.db_zaman_coz(ana.db.meta_al("son_yedek"))
            aralik = float(ayar(ana, "yedek_aralik_saat") or 24)
            if not son or (dt.datetime.now() - son).total_seconds() >= aralik * 3600:
                simdi_yedekle(ana, sessiz=True)
    except Exception:
        pass
    try:
        ana.after(15 * 60 * 1000, lambda: otomatik_yedek_kontrol(ana))
    except Exception:
        pass


def simdi_yedekle(ana, sessiz=False, bitince=None):
    tk_ = token(ana)
    if not tk_:
        if not sessiz:
            messagebox.showwarning("Yedek", "Önce Programcı bölümünde GitHub token'ını girin.")
        return
    ana._yedek_suruyor = True
    try:
        veri = P.yedek_paketi(ana.db)  # veritabanı kopyası burada (ana iş parçacığında) alınır
    except Exception as e:
        ana._yedek_suruyor = False
        ana.db.meta_yaz("son_yedek_hata", "%s · %s" % (M.simdi_str(), e))
        if not sessiz:
            messagebox.showerror("Yedek alınamadı", str(e))
        return
    ana.bildir("İnternet yedeği yükleniyor… (%d KB)" % (len(veri) // 1024))
    sahip, depo = ayar(ana, "gh_kullanici"), ayar(ana, "gh_yedek_depo")

    def bitti(sonuc, hata):
        ana._yedek_suruyor = False
        if hata:
            ana.db.meta_yaz("son_yedek_hata", "%s · %s" % (M.simdi_str(), hata))
            ana.bildir("İnternet yedeği alınamadı: %s" % hata)
            if not sessiz:
                messagebox.showerror("Yedek alınamadı", str(hata))
        else:
            ad, boyut = sonuc
            ana.db.meta_yaz("son_yedek", dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
            ana.db.meta_yaz("son_yedek_ad", ad)
            ana.db.meta_yaz("son_yedek_hata", "")
            ana.bildir("İnternet yedeği alındı: %s (%d KB)" % (ad, boyut // 1024))
            if not sessiz:
                messagebox.showinfo("Yedek alındı", "Yedek GitHub'a yüklendi:\n%s/%s/%s" % (sahip, depo, ad))
        if bitince:
            bitince()
    arka_plan(ana, lambda: P.internete_yedekle(veri, sahip, depo, tk_), bitti)


def _guncelleme_sonucu(ana, bilgi, hata, sessiz=False):
    if hata:
        if not sessiz:
            messagebox.showerror("Güncelleme denetlenemedi", str(hata))
        return
    yeni = (bilgi or {}).get("surum")
    if not yeni or not P.daha_yeni(yeni, SURUM):
        if not sessiz:
            messagebox.showinfo("Güncelleme", "Program güncel (sürüm %s)." % SURUM)
        return
    notlar = (bilgi.get("notlar") or "").strip()
    if not messagebox.askyesno("Yeni sürüm var", "Yeni sürüm: %s  (bu bilgisayarda: %s)\nYayın: %s\n\n%s\n\n"
                                                 "Şimdi kurulsun mu? Program kapanıp yeniden açılacak."
                               % (yeni, SURUM, bilgi.get("tarih", ""), notlar or "")):
        return
    ana._bekleyeni_kaydet()
    ana.bildir("Güncelleme indiriliyor…")

    def bitti(surum, h):
        if h:
            messagebox.showerror("Güncelleme kurulamadı", "%s\n\nProgram eski sürümle çalışmaya devam ediyor." % h)
            return
        messagebox.showinfo("Güncelleme kuruldu", "Sürüm %s kuruldu. Program yeniden açılıyor." % surum)
        try:
            ana.db.kapat()
        finally:
            P.yeniden_baslat()
            ana.root.destroy()
    arka_plan(ana, lambda: P.guncelleme_kur(bilgi), bitti)


# ====================================================================== Programcı ekranı
def programci_bolumu(ana, ic):
    bant(ic, "Bu bölüm programın bakımı içindir: güncellemeleri ekibe yayınlar ve verileri internete (GitHub, gizli depo) "
             "yedekler. GitHub token'ı yalnızca bu bilgisayarda şifreli saklanır.", "bilgi").pack(fill="x", pady=(0, 12))

    # ---------------------------------------------------------------- GitHub bağlantısı
    k = kart(ic)
    k.pack(fill="x")
    lbl(k, "1 · GitHub bağlantısı", boy=12, kalin=True).pack(anchor="w", padx=18, pady=(14, 2))
    lbl(k, "Token almak için: github.com → Settings → Developer settings → Personal access tokens → Tokens (classic) → "
           "Generate new token → 'repo' iznini işaretleyin. Gemi Sefer Takibi'nde kullandığınız token da olur "
           "(gizli yedek deposu için 'repo' izni gerekli).", fg=SOLUK, boy=9, wraplength=900).pack(anchor="w", padx=18)
    f = tk.Frame(k, bg=KART)
    f.pack(fill="x", padx=18, pady=10)
    v = {}
    alanlar = [("gh_kullanici", "GitHub kullanıcı adı"), ("gh_guncelleme_depo", "Güncelleme deposu (herkese açık)"),
               ("gh_yedek_depo", "Yedek deposu (gizli)")]
    for i, (a, b) in enumerate(alanlar):
        f.columnconfigure(i, weight=1, uniform="gh")
        lbl(f, b, boy=9, kalin=True).grid(row=0, column=i, sticky="w", padx=(0, 10))
        v[a] = tk.StringVar(value=ayar(ana, a))
        ttk.Entry(f, textvariable=v[a]).grid(row=1, column=i, sticky="ew", padx=(0, 10), pady=(3, 0))
    lbl(f, "GitHub token (bu bilgisayar)", boy=9, kalin=True).grid(row=2, column=0, sticky="w", pady=(10, 0))
    v_tok = tk.StringVar(value=token(ana))
    ttk.Entry(f, textvariable=v_tok, show="•").grid(row=3, column=0, columnspan=2, sticky="ew", padx=(0, 10), pady=(3, 0))
    durum = lbl(k, "Token kayıtlı." if token(ana) else "Token girilmedi – güncelleme yayınlama ve internet yedeği çalışmaz.",
                fg="#17603A" if token(ana) else "#9E2A21", boy=9)
    durum.pack(anchor="w", padx=18)

    def kaydet(test=False):
        for a, var in v.items():
            ana.db.meta_yaz(a, var.get().strip())
        ana.ayarlar["gh_token"] = P.sifre_sakla(v_tok.get().strip())
        ana.ayarlar_kaydet()
        durum.configure(text="Kaydedildi.", fg="#17603A")
        if not test:
            return
        durum.configure(text="GitHub'a bağlanılıyor…", fg=SOLUK)
        sahip, tk_ = v["gh_kullanici"].get().strip(), v_tok.get().strip()

        def is_():
            m1 = P.depo_hazirla(sahip, v["gh_guncelleme_depo"].get().strip(), tk_, gizli=False)
            m2 = P.depo_hazirla(sahip, v["gh_yedek_depo"].get().strip(), tk_, gizli=True)
            return m1, m2

        def bitti(s, h):
            if h:
                durum.configure(text="✖ %s" % h, fg="#9E2A21")
                return
            (o1, m1), (o2, m2) = s
            durum.configure(text=("✔ " if o1 else "✖ ") + "Güncelleme: " + m1 + "     " + ("✔ " if o2 else "✖ ") + "Yedek: " + m2,
                            fg="#17603A" if (o1 and o2) else "#9E2A21")
        arka_plan(durum, is_, bitti)
    dz = tk.Frame(k, bg=KART)
    dz.pack(fill="x", padx=18, pady=(6, 14))
    ttk.Button(dz, text="Kaydet", command=kaydet).pack(side="left")
    ttk.Button(dz, text="Kaydet ve bağlantıyı test et", style="Vurgu.TButton", command=lambda: kaydet(True)).pack(side="left", padx=8)

    # ---------------------------------------------------------------- güncelleme yayınla
    k = kart(ic)
    k.pack(fill="x", pady=12)
    lbl(k, "2 · Güncelleme yayınla (ekibe gönder)", boy=12, kalin=True).pack(anchor="w", padx=18, pady=(14, 2))
    lbl(k, "Bu bilgisayardaki program dosyaları paketlenip güncelleme deposuna yüklenir. Ekipteki programlar açılışta yeni "
           "sürümü görür, kullanıcıya sorar, kurar ve yeniden açılır. Veriler ve ayarlar etkilenmez; eski dosyalar _yedek "
           "klasörüne alınır.", fg=SOLUK, boy=9, wraplength=900).pack(anchor="w", padx=18)
    f = tk.Frame(k, bg=KART)
    f.pack(fill="x", padx=18, pady=10)
    yayin_lbl = lbl(f, "Bu bilgisayar: %s   ·   Yayındaki sürüm: denetlenmedi" % SURUM, kalin=True)
    yayin_lbl.grid(row=0, column=0, columnspan=3, sticky="w")
    lbl(f, "Yeni sürüm numarası", boy=9, kalin=True).grid(row=1, column=0, sticky="w", pady=(10, 0))
    v_surum = tk.StringVar(value=P.sonraki_surum(SURUM))
    ttk.Entry(f, textvariable=v_surum, width=16).grid(row=2, column=0, sticky="w", pady=(3, 0))
    lbl(f, "Yenilikler (kullanıcılara gösterilir)", boy=9, kalin=True).grid(row=1, column=1, sticky="w", padx=(16, 0), pady=(10, 0))
    t_not = tk.Text(f, height=3, width=80, font=("Segoe UI", 10), relief="solid", bd=1)
    t_not.grid(row=2, column=1, sticky="ew", padx=(16, 0), pady=(3, 0))
    f.columnconfigure(1, weight=1)
    yayin_durum = lbl(k, "", boy=9)
    yayin_durum.pack(anchor="w", padx=18)

    def yayinda_ne_var():
        kaynak = ana.db.meta_al("guncelleme_kaynagi")
        if not kaynak:
            yayin_lbl.configure(text="Bu bilgisayar: %s   ·   Henüz güncelleme yayınlanmadı" % SURUM)
            return
        yayin_lbl.configure(text="Bu bilgisayar: %s   ·   Yayındaki sürüm denetleniyor…" % SURUM)
        arka_plan(yayin_lbl, lambda: P.guncelleme_kontrol(kaynak),
                  lambda b, h: yayin_lbl.configure(text="Bu bilgisayar: %s   ·   Yayındaki sürüm: %s" %
                                                   (SURUM, ("ulaşılamadı (%s)" % h) if h else "%s (%s)" % (b.get("surum"), b.get("tarih")))))

    def yayinla():
        tk_ = token(ana)
        if not tk_:
            messagebox.showwarning("Güncelleme", "Önce GitHub token'ını girip kaydedin (1. bölüm).")
            return
        surum = v_surum.get().strip()
        if not P.surum_tuple(surum) or not P.daha_yeni(surum, "0"):
            messagebox.showwarning("Sürüm", "Geçerli bir sürüm numarası yazın (örn. %s)." % P.sonraki_surum(SURUM))
            return
        notlar = t_not.get("1.0", "end").strip()
        if not messagebox.askyesno("Güncelleme yayınla", "Sürüm %s ekibe yayınlansın mı?\n\nEkipteki programlar açılışta bu "
                                                         "sürümü kurmayı önerecek." % surum):
            return
        yayin_durum.configure(text="Yükleniyor…", fg=SOLUK)
        sahip, depo = ayar(ana, "gh_kullanici"), ayar(ana, "gh_guncelleme_depo")

        def bitti(s, h):
            if h:
                yayin_durum.configure(text="✖ %s" % h, fg="#9E2A21")
                messagebox.showerror("Yayınlanamadı", str(h))
                return
            bilgi, kaynak = s
            ana.db.meta_yaz("guncelleme_kaynagi", kaynak)
            yayin_durum.configure(text="✔ Sürüm %s yayınlandı (%s). Program yeniden açılınca bu bilgisayar da %s olarak görünür."
                                  % (bilgi["surum"], bilgi["tarih"], bilgi["surum"]), fg="#17603A")
            messagebox.showinfo("Yayınlandı", "Sürüm %s ekibe yayınlandı." % bilgi["surum"])
        arka_plan(yayin_durum, lambda: P.guncelleme_yayinla(sahip, depo, tk_, surum, notlar, ana.k["ad"]), bitti)
    dz = tk.Frame(k, bg=KART)
    dz.pack(fill="x", padx=18, pady=(6, 14))
    ttk.Button(dz, text="Güncellemeyi yayınla", style="Vurgu.TButton", command=yayinla).pack(side="left")
    ttk.Button(dz, text="Yayındaki sürümü göster", command=yayinda_ne_var).pack(side="left", padx=8)

    # ---------------------------------------------------------------- güncelleme kontrolü
    k = kart(ic)
    k.pack(fill="x")
    lbl(k, "3 · Bu bilgisayarın güncellemeleri", boy=12, kalin=True).pack(anchor="w", padx=18, pady=(14, 2))
    kaynak = ana.db.meta_al("guncelleme_kaynagi")
    lbl(k, "Güncelleme kaynağı: %s" % (kaynak or "henüz yok (ilk güncelleme yayınlanınca otomatik ayarlanır)"),
        fg=SOLUK, boy=9).pack(anchor="w", padx=18)
    v_oto = tk.BooleanVar(value=ayar(ana, "guncelleme_otomatik") == "1")
    ttk.Checkbutton(k, text="Program açılırken yeni sürümü denetle (tüm bilgisayarlar)", variable=v_oto,
                    command=lambda: ana.db.meta_yaz("guncelleme_otomatik", "1" if v_oto.get() else "0")).pack(anchor="w", padx=18, pady=(8, 0))

    def denetle():
        kaynak_ = ana.db.meta_al("guncelleme_kaynagi")
        if not kaynak_:
            messagebox.showinfo("Güncelleme", "Henüz yayınlanmış bir güncelleme yok.")
            return
        arka_plan(k, lambda: P.guncelleme_kontrol(kaynak_), lambda b, h: _guncelleme_sonucu(ana, b, h))
    ttk.Button(k, text="Güncellemeleri şimdi denetle", command=denetle).pack(anchor="w", padx=18, pady=(8, 14))

    # ---------------------------------------------------------------- internet yedeği
    k = kart(ic)
    k.pack(fill="x", pady=12)
    lbl(k, "4 · İnternete otomatik yedek", boy=12, kalin=True).pack(anchor="w", padx=18, pady=(14, 2))
    lbl(k, "Veritabanı ve tüm ekler zip olarak GİZLİ GitHub deposuna yüklenir; son %d yedek tutulur. Yedeği, token'ı kayıtlı "
           "ve programı açık olan bilgisayar alır." % P.TUTULACAK_YEDEK, fg=SOLUK, boy=9, wraplength=900).pack(anchor="w", padx=18)
    f = tk.Frame(k, bg=KART)
    f.pack(fill="x", padx=18, pady=10)
    v_yo = tk.BooleanVar(value=ayar(ana, "yedek_otomatik") == "1")
    ttk.Checkbutton(f, text="Otomatik yedek açık", variable=v_yo,
                    command=lambda: ana.db.meta_yaz("yedek_otomatik", "1" if v_yo.get() else "0")).pack(side="left")
    lbl(f, "   Sıklık:").pack(side="left")
    ad_ = {d: a for a, d in ARALIKLAR}
    v_ar = tk.StringVar(value=ad_.get(ayar(ana, "yedek_aralik_saat"), "Her gün"))
    cb = ttk.Combobox(f, textvariable=v_ar, values=[a for a, _ in ARALIKLAR], state="readonly", width=18)
    cb.pack(side="left", padx=6)
    cb.bind("<<ComboboxSelected>>", lambda e: ana.db.meta_yaz("yedek_aralik_saat", dict(ARALIKLAR)[v_ar.get()]))
    son = ana.db.meta_al("son_yedek")
    hata = ana.db.meta_al("son_yedek_hata")
    lbl(k, "Son yedek: %s %s" % (M.db_zaman_goster(son) if son else "henüz alınmadı", ("· " + ana.db.meta_al("son_yedek_ad")) if son else ""),
        kalin=True).pack(anchor="w", padx=18)
    if hata:
        lbl(k, "Son hata: " + hata, fg="#9E2A21", boy=9, wraplength=900).pack(anchor="w", padx=18)

    liste_k = tk.Frame(k, bg=KART)
    liste_k.pack(fill="x", padx=18, pady=(8, 0))
    tv = ttk.Treeview(liste_k, columns=("ad", "boyut"), show="headings", height=6)
    tv.heading("ad", text="GitHub'daki yedekler")
    tv.heading("boyut", text="Boyut")
    tv.column("ad", width=420)
    tv.column("boyut", width=100)
    tv.pack(fill="x")
    yedekler = {}

    def listele():
        tk_ = token(ana)
        if not tk_:
            messagebox.showwarning("Yedek", "Önce GitHub token'ını girin.")
            return
        tv.delete(*tv.get_children())
        tv.insert("", "end", values=("Yükleniyor…", ""))

        def bitti(s, h):
            tv.delete(*tv.get_children())
            yedekler.clear()
            if h:
                tv.insert("", "end", values=("Liste alınamadı: %s" % h, ""))
                return
            if not s:
                tv.insert("", "end", values=("Henüz yedek yok", ""))
            for y in s:
                yedekler[y["path"]] = y
                tv.insert("", "end", iid=y["path"], values=(y["name"], "%d KB" % (y.get("size", 0) // 1024)))
        arka_plan(tv, lambda: P.yedekleri_listele(ayar(ana, "gh_kullanici"), ayar(ana, "gh_yedek_depo"), tk_), bitti)

    def geri_yukle():
        sec = tv.selection()
        if not sec or sec[0] not in yedekler:
            messagebox.showinfo("Geri yükle", "Önce listeden bir yedek seçin (listeyi yenileyin).")
            return
        yol = sec[0]
        if not messagebox.askyesno("Yedeği geri yükle", "%s geri yüklensin mi?\n\nŞu anki veriler SİLİNMEZ, veri klasöründe "
                                                         "_onceki_… klasörüne alınır. Program yeniden açılacak.\n\n"
                                                         "Ekipteki diğer bilgisayarlarda program açıksa önce kapatılmalı."
                                   % yedekler[yol]["name"]):
            return
        ana.bildir("Yedek indiriliyor…")

        def bitti(s, h):
            if h:
                messagebox.showerror("Geri yüklenemedi", str(h))
                return
            messagebox.showinfo("Geri yükleme", "Yedek indirildi. Program yeniden açılırken geri yüklenecek.")
            ana._bekleyeni_kaydet()
            ana.db.kapat()
            P.yeniden_baslat()
            ana.root.destroy()
        arka_plan(ana, lambda: P.yedegi_indir(ayar(ana, "gh_kullanici"), ayar(ana, "gh_yedek_depo"), token(ana),
                                              yol, ana.db.klasor), bitti)
    dz = tk.Frame(k, bg=KART)
    dz.pack(fill="x", padx=18, pady=(8, 14))
    ttk.Button(dz, text="Şimdi yedekle", style="Vurgu.TButton",
               command=lambda: simdi_yedekle(ana, bitince=lambda: ana.goster("ayarlar", sekme="programci"))).pack(side="left")
    ttk.Button(dz, text="Yedekleri listele", command=listele).pack(side="left", padx=8)
    ttk.Button(dz, text="Seçili yedeği geri yükle", style="Tehlike.TButton", command=geri_yukle).pack(side="left")
