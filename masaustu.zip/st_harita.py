# -*- coding: utf-8 -*-
"""Gemileri VesselFinder haritasında gösterir (ücretsiz gömülü harita, abonelik gerekmez).

VesselFinder'ın herkese açık 'harita yerleştirme' aracı kullanılır: IMO numarasıyla geminin son AIS konumu ve
son 24 saatlik rotası gösterilir. Program küçük bir HTML sayfası oluşturup varsayılan tarayıcıda açar."""
import html
import os
import re
import datetime as dt

DETAY_URL = "https://www.vesselfinder.com/vessels/details/%s"
GOMULU_JS = "https://www.vesselfinder.com/aismap.js"
EN_COK = 12  # tek sayfada gösterilecek harita sayısı (her harita ayrı yüklenir)


def imo_temiz(imo):
    imo = re.sub(r"\D", "", imo or "")
    return imo if len(imo) == 7 else ""


def detay_url(imo):
    return DETAY_URL % imo_temiz(imo)


def _harita(imo, yukseklik, zoom):
    return ('<script type="text/javascript">\n'
            'var width="100%%"; var height="%d"; var latitude="40.90"; var longitude="29.00"; var zoom="%d";\n'
            'var names=true; var imo="%s"; var show_track=true;\n'
            '</script>\n<script type="text/javascript" src="%s"></script>\n') % (yukseklik, zoom, imo, GOMULU_JS)


def harita_html(gemiler):
    """gemiler: [{'ad', 'imo', 'alt'(isteğe bağlı açıklama)}] – IMO'su olanlar gösterilir."""
    gemiler = [g for g in gemiler if imo_temiz(g.get("imo"))][:EN_COK]
    tek = len(gemiler) == 1
    zaman = dt.datetime.now().strftime("%d.%m.%Y %H:%M")
    parcalar = []
    for g in gemiler:
        imo = imo_temiz(g["imo"])
        parcalar.append(
            '<section class="kart%s">\n<div class="bas"><div><b>%s</b><span>IMO %s%s</span></div>'
            '<a href="%s" target="_blank">VesselFinder sayfası ↗</a></div>\n<div class="harita">%s</div>\n</section>'
            % (" tek" if tek else "", html.escape(g.get("ad") or ""), imo,
               (" · " + html.escape(g["alt"])) if g.get("alt") else "", detay_url(imo),
               _harita(imo, 640 if tek else 380, 9 if tek else 8)))
    if not parcalar:
        parcalar.append('<p class="bos">IMO numarası girilmiş gemi yok. Haritada göstermek için gemiye IMO ekleyin.</p>')
    baslik = (gemiler[0]["ad"] if tek else "Takipteki gemiler") + " – Harita"
    return """<!doctype html>
<html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>%s</title>
<style>
 body{margin:0;font-family:Segoe UI,Arial,sans-serif;background:#EEF1F4;color:#14202B}
 header{background:#0E2335;color:#fff;padding:14px 22px}
 header h1{margin:0;font-size:19px} header p{margin:4px 0 0;color:#C9D3DD;font-size:13px}
 main{display:grid;grid-template-columns:repeat(auto-fill,minmax(520px,1fr));gap:16px;padding:18px}
 .kart{background:#fff;border:1px solid #D5DBE2;border-radius:8px;overflow:hidden}
 .kart.tek{grid-column:1/-1}
 .bas{display:flex;justify-content:space-between;align-items:center;padding:10px 14px;border-bottom:1px solid #EEF1F4}
 .bas b{font-size:15px;margin-right:10px} .bas span{color:#55606E;font-size:13px}
 .bas a{color:#1F5F8B;font-size:13px;text-decoration:none;font-weight:600}
 .bos{padding:30px;color:#55606E}
 footer{padding:0 22px 18px;color:#55606E;font-size:12px}
</style></head><body>
<header><h1>%s</h1><p>Kaynak: VesselFinder (AIS) · son konum ve son 24 saatlik rota · oluşturma: %s</p></header>
<main>
%s
</main>
<footer>Konum, geminin AIS yayınına bağlıdır; uydu / kıyı istasyonu kapsamı dışındaysa son bilinen konum gösterilir.
Sayfayı yenileyince (F5) konum güncellenir.</footer>
</body></html>
""" % (html.escape(baslik), html.escape(baslik), zaman, "\n".join(parcalar))


def haritada_ac(klasor, gemiler, dosya_adi="gemi_haritasi.html"):
    """HTML'i veri klasörüne yazar ve tarayıcıda açar. (yol, gösterilen gemi sayısı)"""
    kl = os.path.join(klasor, "harita")
    os.makedirs(kl, exist_ok=True)
    yol = os.path.join(kl, dosya_adi)
    with open(yol, "w", encoding="utf-8") as f:
        f.write(harita_html(gemiler))
    import sys
    if sys.platform.startswith("win"):
        os.startfile(yol)  # noqa – varsayılan tarayıcıda açılır
    else:
        import webbrowser
        webbrowser.open("file://" + yol)
    return yol, len([g for g in gemiler if imo_temiz(g.get("imo"))][:EN_COK])
