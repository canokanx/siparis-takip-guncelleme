# -*- coding: utf-8 -*-
"""Arayüz yardımcıları: renkli etiketler, kaydırılabilir alan, stiller."""
import sys
import tkinter as tk
from tkinter import ttk

from st_tanim import RENK, LACIVERT, VURGU, ZEMIN, KART, CIZGI, YAZI, SOLUK

YAZI_TIPI = "Segoe UI" if sys.platform.startswith("win") else "DejaVu Sans"


def font(boy=10, kalin=False, alti=False):
    f = [YAZI_TIPI, boy]
    if kalin:
        f.append("bold")
    if alti:
        f.append("underline")
    return tuple(f)


def stilleri_kur(root):
    tekerlek_kur(root)
    st = ttk.Style(root)
    try:
        st.theme_use("clam")
    except tk.TclError:
        pass
    root.configure(bg=ZEMIN)
    st.configure(".", font=font(10), background=ZEMIN, foreground=YAZI)
    st.configure("TFrame", background=ZEMIN)
    st.configure("Kart.TFrame", background=KART)
    st.configure("TLabel", background=ZEMIN, foreground=YAZI)
    st.configure("Kart.TLabel", background=KART)
    st.configure("Soluk.TLabel", background=KART, foreground=SOLUK, font=font(9))
    st.configure("Baslik.TLabel", background=ZEMIN, font=font(17, True))
    st.configure("KartBaslik.TLabel", background=KART, font=font(12, True))
    st.configure("TButton", padding=(12, 7), font=font(10), background="#FFFFFF", bordercolor="#B9C2CC")
    st.map("TButton", background=[("active", "#E9EEF3"), ("disabled", "#F2F4F7")])
    st.configure("Vurgu.TButton", background=VURGU, foreground="#FFFFFF", font=font(10, True), bordercolor=VURGU)
    st.map("Vurgu.TButton", background=[("active", "#174A6E"), ("disabled", "#9BB5CA")],
           foreground=[("disabled", "#EEF3F7")])
    st.configure("Tehlike.TButton", foreground="#9E2A21")
    st.configure("TEntry", padding=5, fieldbackground="#FFFFFF", bordercolor="#B9C2CC")
    st.map("TEntry", fieldbackground=[("readonly", "#F2F4F7"), ("disabled", "#F2F4F7")])
    st.configure("Hata.TEntry", bordercolor="#D64538", fieldbackground="#FFF7F6")
    st.configure("TCombobox", padding=4)
    st.map("TCombobox", fieldbackground=[("readonly", "#FFFFFF"), ("disabled", "#F2F4F7")])
    st.configure("Treeview", rowheight=28, font=font(10), background="#FFFFFF", fieldbackground="#FFFFFF")
    st.configure("Treeview.Heading", font=font(9, True), background="#F5F7F9")
    st.configure("TCheckbutton", background=KART)
    st.configure("Zemin.TCheckbutton", background=ZEMIN)
    st.configure("TNotebook", background=ZEMIN)


def pill(parent, metin, renk="na", boy=9, bg_parent=KART):
    a, y, k = RENK[renk]
    return tk.Label(parent, text=metin, bg=a, fg=y, font=font(boy, True), padx=8, pady=2,
                    highlightthickness=1, highlightbackground=k, highlightcolor=k, bd=0)


def kart(parent, **kw):
    f = tk.Frame(parent, bg=KART, highlightthickness=1, highlightbackground=CIZGI, bd=0, **kw)
    return f


def link(parent, metin, komut, bg=KART, boy=10, kalin=True):
    l = tk.Label(parent, text=metin, bg=bg, fg=VURGU, font=font(boy, kalin, True), cursor="hand2")
    l.bind("<Button-1>", lambda e: komut())
    return l


def lbl(parent, metin="", bg=KART, fg=YAZI, boy=10, kalin=False, **kw):
    return tk.Label(parent, text=metin, bg=bg, fg=fg, font=font(boy, kalin), anchor="w", justify="left", **kw)


def bant(parent, metin, tur="bilgi"):
    """Bilgi / uyarı / kilit bandı."""
    renk = {"bilgi": ("#E9F1F8", "#1F3B55", "#A9C4DD"), "uyari": ("#FFF2C4", "#5C4300", "#E0A800"),
            "kilit": ("#F2F4F7", "#33404D", "#C9D1DA"), "hata": ("#FBE3E1", "#7A1F18", "#D64538")}[tur]
    f = tk.Frame(parent, bg=renk[0], highlightthickness=1, highlightbackground=renk[2])
    tk.Label(f, text=metin, bg=renk[0], fg=renk[1], font=font(10), justify="left", anchor="w",
             wraplength=760).pack(fill="x", padx=12, pady=9)
    return f


class KaydirmaliAlan(ttk.Frame):
    """Dikey kaydırılabilir alan. İçerik self.ic içine konur.
    Fare tekerleği / touchpad iki parmak kaydırma tek bir genel işleyiciyle yönetilir (tekerlek_kur)."""

    def __init__(self, parent, bg=ZEMIN):
        super().__init__(parent)
        self.canvas = tk.Canvas(self, bg=bg, highlightthickness=0, bd=0, yscrollincrement=1)
        self.canvas._kaydirma_alani = True
        self.sb = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.ic = tk.Frame(self.canvas, bg=bg)
        self._win = self.canvas.create_window((0, 0), window=self.ic, anchor="nw")
        self.canvas.configure(yscrollcommand=self.sb.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.sb.pack(side="right", fill="y")
        self.ic.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", lambda e: self.canvas.itemconfigure(self._win, width=e.width))

    def basa(self):
        self.canvas.yview_moveto(0)


_KENDI_KAYAN = ("Treeview", "Text", "Listbox")
_birikim = [0.0]


def _kaydirilabilir(w):
    try:
        a, b = w.yview()
        return not (a <= 0.0 and b >= 1.0)
    except Exception:
        return False


def _tekerlek_hedefi(root, x, y):
    """Fare altındaki widget'tan yukarı çıkarak kaydırılacak alanı bulur."""
    try:
        w = root.winfo_containing(x, y)
    except Exception:
        return None, None
    ilk = w
    while w is not None:
        sinif = w.winfo_class()
        if sinif in _KENDI_KAYAN and _kaydirilabilir(w):
            return w, "kendi"
        if getattr(w, "_kaydirma_alani", False):
            return w, "alan"
        w = w.master
    return ilk, None


def tekerlek_kur(root):
    """Programın her yerinde fare tekerleği ve touchpad (iki parmak) kaydırması.
    Fare tekerleği bir 'çentik' = 120 birim; touchpad küçük değerler gönderir, birikerek akıcı kayar."""

    def kaydir(e, delta):
        hedef, tur = _tekerlek_hedefi(root, e.x_root, e.y_root)
        if tur == "kendi":
            # liste / metin kutusu kendini kaydırır; sonuna geldiyse sayfa kaysın diye aşağı düşmez
            return "kendi"
        if tur != "alan" or not _kaydirilabilir(hedef):
            return
        _birikim[0] += -delta / 2.0  # 120 -> 60 piksel
        adim = int(_birikim[0])
        if adim:
            _birikim[0] -= adim
            hedef.yview_scroll(adim, "units")

    def windows(e):
        kaydir(e, e.delta)

    def linux_yukari(e):
        kaydir(e, 120)

    def linux_asagi(e):
        kaydir(e, -120)

    root.bind_all("<MouseWheel>", windows, add="+")
    root.bind_all("<Button-4>", linux_yukari, add="+")
    root.bind_all("<Button-5>", linux_asagi, add="+")

    # Açılır listelerde (Combobox) tekerlek değeri değiştirmesin, sayfayı kaydırsın
    def combobox(e, delta=None):
        kaydir(e, e.delta if delta is None else delta)
        return "break"
    root.bind_class("TCombobox", "<MouseWheel>", combobox)
    root.bind_class("TCombobox", "<Button-4>", lambda e: combobox(e, 120))
    root.bind_class("TCombobox", "<Button-5>", lambda e: combobox(e, -120))

    # Liste / metin kutusunda da touchpad küçük adımları birikerek çalışsın
    _ic = [0.0]

    def kendi(e, delta=None):
        d = e.delta if delta is None else delta
        w = e.widget
        if not _kaydirilabilir(w):
            # kutu kaydırılamıyorsa (kısa liste) sayfayı kaydır
            _sayfayi_kaydir(root, w, d)
            return "break"
        _ic[0] += -d / 40.0  # 120 -> 3 satır
        adim = int(_ic[0])
        if adim:
            _ic[0] -= adim
            w.yview_scroll(adim, "units")
        return "break"
    for sinif in _KENDI_KAYAN:
        root.bind_class(sinif, "<MouseWheel>", kendi)
        root.bind_class(sinif, "<Button-4>", lambda e: kendi(e, 120))
        root.bind_class(sinif, "<Button-5>", lambda e: kendi(e, -120))


def _sayfayi_kaydir(root, w, delta):
    while w is not None and not getattr(w, "_kaydirma_alani", False):
        w = w.master
    if w is None or not _kaydirilabilir(w):
        return
    _birikim[0] += -delta / 2.0
    adim = int(_birikim[0])
    if adim:
        _birikim[0] -= adim
        w.yview_scroll(adim, "units")


def ortala(pencere, ana=None, gen=None, yuk=None):
    pencere.update_idletasks()
    g = gen or pencere.winfo_width()
    y = yuk or pencere.winfo_height()
    if ana is not None:
        x = ana.winfo_rootx() + (ana.winfo_width() - g) // 2
        yy = ana.winfo_rooty() + (ana.winfo_height() - y) // 3
    else:
        x = (pencere.winfo_screenwidth() - g) // 2
        yy = (pencere.winfo_screenheight() - y) // 3
    pencere.geometry("%dx%d+%d+%d" % (g, y, max(x, 0), max(yy, 0)))


# ====================================================================== tarih / saat seçici
AYLAR = ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"]
GUNLER = ["Pt", "Sa", "Ça", "Pe", "Cu", "Ct", "Pz"]


def tarih_normalle(metin, tur):
    """Elle yazılanı düzgün biçime çevirir: 3.11.26 -> 03.11.2026 · 3/11/2026 9:5 -> 03.11.2026 09:05.
    Anlaşılamazsa olduğu gibi döner (kaydederken biçim uyarısı çıkar)."""
    import re
    import datetime as dt
    m = re.match(r"^\s*(\d{1,2})[./ -](\d{1,2})[./ -](\d{2}|\d{4})(?:\s+(\d{1,2})[:.](\d{1,2}))?\s*$", metin or "")
    if not m:
        return metin
    g, a, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
    if y < 100:
        y += 2000
    try:
        dt.date(y, a, g)
    except ValueError:
        return metin
    s = "%02d.%02d.%04d" % (g, a, y)
    if tur == "tarihsaat":
        if m.group(4) is None:
            return metin  # saat eksik: kullanıcı tamamlasın
        ss, dd = int(m.group(4)), int(m.group(5))
        if ss > 23 or dd > 59:
            return metin
        s += " %02d:%02d" % (ss, dd)
    return s


def tarih_alani(parent, var, tur="tarih", genislik=None, salt_okunur=False, bg=KART):
    """Elle yazılabilen tarih kutusu + 'Takvim' düğmesi (tarihsaat ise takvimde saat / dakika seçimi de var).
    (çerçeve, giriş kutusu) döner."""
    f = tk.Frame(parent, bg=bg)
    e = ttk.Entry(f, textvariable=var, state="readonly" if salt_okunur else "normal", width=genislik or 12)
    if not salt_okunur:
        b = ttk.Button(f, text="Takvim", width=7, command=lambda: takvim_ac(e, var, tur))
        b.pack(side="right", padx=(4, 0))
    e.pack(side="left", fill="x", expand=True)
    if not salt_okunur:
        e.bind("<FocusOut>", lambda ev: var.set(tarih_normalle(var.get(), tur)), add="+")
        e.bind("<Alt-Down>", lambda ev: takvim_ac(e, var, tur))
    return f, e


def takvim_ac(giris, var, tur="tarih"):
    """Giriş kutusunun altında takvim açar. Gün tıklanınca (tarihsaat'te 'Tamam' ile) kutuya yazılır."""
    import calendar
    import datetime as dt
    import re
    simdi = dt.datetime.now()
    mevcut = var.get() or ""
    m = re.match(r"^\s*(\d{1,2})\.(\d{1,2})\.(\d{4})(?:\s+(\d{1,2}):(\d{2}))?", tarih_normalle(mevcut, "tarihsaat")
                 if tur == "tarihsaat" else tarih_normalle(mevcut, "tarih"))
    secili = None
    saat, dakika = simdi.hour, (simdi.minute // 5) * 5
    if m:
        try:
            secili = dt.date(int(m.group(3)), int(m.group(2)), int(m.group(1)))
            if m.group(4) is not None:
                saat, dakika = int(m.group(4)), int(m.group(5))
        except ValueError:
            secili = None
    gorunen = [(secili or simdi.date()).year, (secili or simdi.date()).month]
    sec = {"g": secili}

    p = tk.Toplevel(giris)
    p.withdraw()
    p.overrideredirect(True)
    p.configure(bg=CIZGI)
    ic = tk.Frame(p, bg=KART, padx=10, pady=8)
    ic.pack(padx=1, pady=1)

    bas = tk.Frame(ic, bg=KART)
    bas.pack(fill="x")
    baslik = tk.Label(bas, text="", bg=KART, fg=YAZI, font=font(11, True))
    izgara = tk.Frame(ic, bg=KART)
    izgara.pack(pady=(6, 0))

    def ay_degis(n):
        y, a = gorunen
        a += n
        if a < 1:
            a, y = 12, y - 1
        elif a > 12:
            a, y = 1, y + 1
        gorunen[:] = [y, a]
        ciz()

    for metin, n in (("«", -12), ("‹", -1)):
        tk.Button(bas, text=metin, command=lambda n=n: ay_degis(n), relief="flat", bg=KART, fg=VURGU, font=font(11, True),
                  cursor="hand2", width=2, bd=0, activebackground="#E4ECF3").pack(side="left")
    for metin, n in (("»", 12), ("›", 1)):
        tk.Button(bas, text=metin, command=lambda n=n: ay_degis(n), relief="flat", bg=KART, fg=VURGU, font=font(11, True),
                  cursor="hand2", width=2, bd=0, activebackground="#E4ECF3").pack(side="right")
    baslik.pack(side="left", expand=True)

    v_saat = tk.StringVar(value="%02d" % saat)
    v_dak = tk.StringVar(value="%02d" % dakika)

    def yaz_ve_kapat(g=None):
        g = g or sec["g"]
        if g is None:
            return
        s = g.strftime("%d.%m.%Y")
        if tur == "tarihsaat":
            try:
                ss = max(0, min(23, int(v_saat.get() or 0)))
                dd = max(0, min(59, int(v_dak.get() or 0)))
            except ValueError:
                ss, dd = saat, dakika
            s += " %02d:%02d" % (ss, dd)
        var.set(s)
        kapat()

    def gun_sec(g):
        if tur == "tarihsaat":
            sec["g"] = g
            ciz()
        else:
            yaz_ve_kapat(g)

    def ciz():
        for w in izgara.winfo_children():
            w.destroy()
        y, a = gorunen
        baslik.configure(text="%s %d" % (AYLAR[a - 1], y))
        for i, gn in enumerate(GUNLER):
            tk.Label(izgara, text=gn, bg=KART, fg="#9E2A21" if i >= 5 else SOLUK, font=font(9, True), width=4).grid(row=0, column=i)
        bugun = simdi.date()
        for r, hafta in enumerate(calendar.Calendar(0).monthdatescalendar(y, a), start=1):
            for c, g in enumerate(hafta):
                bu_ay = g.month == a
                sec_mi = sec["g"] == g
                arka = VURGU if sec_mi else ("#E4ECF3" if g == bugun else KART)
                yazi = "#FFFFFF" if sec_mi else (YAZI if bu_ay else "#B0B7C0")
                l = tk.Label(izgara, text=str(g.day), bg=arka, fg=yazi, width=4, pady=3, cursor="hand2",
                             font=font(10, sec_mi or g == bugun))
                l.grid(row=r, column=c, padx=1, pady=1)
                l.bind("<Button-1>", lambda e, g=g: (gun_sec(g), "break")[1])
                if not sec_mi:
                    l.bind("<Enter>", lambda e, w=l: w.configure(bg="#D6E4F0"))
                    l.bind("<Leave>", lambda e, w=l, b=arka: w.configure(bg=b))

    alt = tk.Frame(ic, bg=KART)
    alt.pack(fill="x", pady=(8, 0))
    if tur == "tarihsaat":
        sf = tk.Frame(alt, bg=KART)
        sf.pack(fill="x", pady=(0, 8))
        tk.Label(sf, text="Saat", bg=KART, fg="#33404D", font=font(10, True)).pack(side="left")

        def kutu(v, ust, adim):
            sp = tk.Spinbox(sf, from_=0, to=ust, increment=adim, textvariable=v, width=3, wrap=True, format="%02.0f",
                            font=font(12, True), justify="center", relief="solid", bd=1)
            sp.pack(side="left", padx=(6, 0))

            def tekerlek(e, yon=None):
                d = yon if yon is not None else (1 if e.delta > 0 else -1)
                try:
                    n = (int(v.get() or 0) + d * adim) % (ust + 1)
                except ValueError:
                    n = 0
                v.set("%02d" % n)
                return "break"
            sp.bind("<MouseWheel>", tekerlek)
            sp.bind("<Button-4>", lambda e: tekerlek(e, 1))
            sp.bind("<Button-5>", lambda e: tekerlek(e, -1))
            sp.bind("<Return>", lambda e: yaz_ve_kapat())
            return sp
        kutu(v_saat, 23, 1)
        tk.Label(sf, text=":", bg=KART, font=font(12, True)).pack(side="left", padx=2)
        kutu(v_dak, 59, 5)
        hizli = tk.Frame(alt, bg=KART)
        hizli.pack(fill="x", pady=(0, 8))
        for hs in ("08:00", "09:00", "12:00", "14:00", "17:00", "20:00"):
            b = tk.Label(hizli, text=hs, bg="#F2F4F7", fg="#33404D", font=font(9), padx=6, pady=2, cursor="hand2")
            b.pack(side="left", padx=(0, 4))
            b.bind("<Button-1>", lambda e, hs=hs: (v_saat.set(hs[:2]), v_dak.set(hs[3:])))

    def bugune():
        if tur == "tarihsaat":
            n = dt.datetime.now()
            v_saat.set("%02d" % n.hour)
            v_dak.set("%02d" % n.minute)
            sec["g"] = n.date()
            gorunen[:] = [n.year, n.month]
            yaz_ve_kapat()
        else:
            yaz_ve_kapat(dt.date.today())

    dz = tk.Frame(alt, bg=KART)
    dz.pack(fill="x")
    ttk.Button(dz, text="Şimdi" if tur == "tarihsaat" else "Bugün", command=bugune).pack(side="left")
    ttk.Button(dz, text="Temizle", command=lambda: (var.set(""), kapat())).pack(side="left", padx=4)
    if tur == "tarihsaat":
        ttk.Button(dz, text="Tamam", style="Vurgu.TButton", command=yaz_ve_kapat).pack(side="right")
    ttk.Button(dz, text="Kapat", command=lambda: kapat()).pack(side="right", padx=(0, 4))

    def kapat():
        try:
            p.grab_release()
        except Exception:
            pass
        p.destroy()
        try:
            giris.focus_set()
        except Exception:
            pass

    def disari_tiklama(e):
        # takvimin dışına tıklanınca kapanır
        try:
            if not p.winfo_exists():
                return
            x, y = e.x_root, e.y_root
            if not (p.winfo_rootx() <= x <= p.winfo_rootx() + p.winfo_width() and
                    p.winfo_rooty() <= y <= p.winfo_rooty() + p.winfo_height()):
                kapat()
        except tk.TclError:
            pass
    ciz()
    p.update_idletasks()
    x = giris.winfo_rootx()
    y = giris.winfo_rooty() + giris.winfo_height() + 2
    if y + p.winfo_reqheight() > giris.winfo_screenheight() - 40:
        y = giris.winfo_rooty() - p.winfo_reqheight() - 2
    x = min(x, giris.winfo_screenwidth() - p.winfo_reqwidth() - 10)
    p.geometry("+%d+%d" % (max(0, x), max(0, y)))
    p.deiconify()
    p.lift()
    p.bind("<Escape>", lambda e: kapat())
    p.bind("<Button-1>", disari_tiklama, add="+")
    try:
        p.grab_set()
    except tk.TclError:
        pass
    p.focus_set()
    return p


# ====================================================================== saat / saat aralığı seçici
def saat_normalle(metin):
    """Elle yazılan saati düzeltir: 9 -> 09:00 · 2111 -> 21:11 · 9-12 -> 09:00 - 12:00 · 9:30-17 -> 09:30 - 17:00.
    Anlaşılamazsa olduğu gibi döner."""
    import re

    def tek(p):
        p = p.strip()
        m = re.match(r"^(\d{1,2})(?:[:.](\d{1,2}))?$", p) or re.match(r"^(\d{1,2})(\d{2})$", p)
        if not m:
            return None
        s, d = int(m.group(1)), int(m.group(2) or 0)
        if s > 23 or d > 59:
            return None
        return "%02d:%02d" % (s, d)
    m = (metin or "").strip()
    if not m:
        return metin
    parca = re.split(r"\s*(?:-|–|—|/| ile )\s*", m)
    if len(parca) == 1:
        return tek(parca[0]) or metin
    if len(parca) == 2:
        a, b = tek(parca[0]), tek(parca[1])
        if a and b:
            return "%s - %s" % (a, b)
    return metin


def saat_alani(parent, var, salt_okunur=False, bg=KART, aralik=True):
    """Elle yazılabilen saat (aralığı) kutusu + 'Saat' düğmesi. (çerçeve, giriş kutusu) döner."""
    f = tk.Frame(parent, bg=bg)
    e = ttk.Entry(f, textvariable=var, state="readonly" if salt_okunur else "normal", width=12)
    if not salt_okunur:
        ttk.Button(f, text="Saat", width=7, command=lambda: saat_secici_ac(e, var, aralik)).pack(side="right", padx=(4, 0))
    e.pack(side="left", fill="x", expand=True)
    if not salt_okunur:
        e.bind("<FocusOut>", lambda ev: var.set(saat_normalle(var.get())), add="+")
        e.bind("<Alt-Down>", lambda ev: saat_secici_ac(e, var, aralik))
    return f, e


def _saat_kutusu(ust, v, ust_sinir, adim, tamam):
    sp = tk.Spinbox(ust, from_=0, to=ust_sinir, increment=adim, textvariable=v, width=3, wrap=True, format="%02.0f",
                    font=font(12, True), justify="center", relief="solid", bd=1)

    def tekerlek(e, yon=None):
        d = yon if yon is not None else (1 if e.delta > 0 else -1)
        try:
            n = (int(v.get() or 0) + d * adim) % (ust_sinir + 1)
        except ValueError:
            n = 0
        v.set("%02d" % n)
        return "break"
    sp.bind("<MouseWheel>", tekerlek)
    sp.bind("<Button-4>", lambda e: tekerlek(e, 1))
    sp.bind("<Button-5>", lambda e: tekerlek(e, -1))
    sp.bind("<Return>", lambda e: tamam())
    return sp


def saat_secici_ac(giris, var, aralik=True):
    """Saat aralığı (başlangıç – bitiş) ya da tek saat seçici. Hazır aralıklar da var."""
    import re
    import datetime as dt
    simdi = dt.datetime.now()
    mevcut = saat_normalle(var.get() or "")
    saatler = re.findall(r"(\d{2}):(\d{2})", mevcut)
    bas_s, bas_d = saatler[0] if saatler else ("%02d" % simdi.hour, "00")
    bit_s, bit_d = saatler[1] if len(saatler) > 1 else ("%02d" % min(23, int(bas_s) + 3), bas_d)
    v = [tk.StringVar(value=bas_s), tk.StringVar(value=bas_d), tk.StringVar(value=bit_s), tk.StringVar(value=bit_d)]
    v_aralik = tk.BooleanVar(value=aralik and (len(saatler) != 1))

    p = tk.Toplevel(giris)
    p.withdraw()
    p.overrideredirect(True)
    p.configure(bg=CIZGI)
    ic = tk.Frame(p, bg=KART, padx=12, pady=10)
    ic.pack(padx=1, pady=1)
    tk.Label(ic, text="Saat aralığı" if aralik else "Saat", bg=KART, fg=YAZI, font=font(11, True)).pack(anchor="w")

    def kapat():
        try:
            p.grab_release()
        except Exception:
            pass
        p.destroy()
        try:
            giris.focus_set()
        except Exception:
            pass

    def yaz():
        try:
            a = "%02d:%02d" % (max(0, min(23, int(v[0].get() or 0))), max(0, min(59, int(v[1].get() or 0))))
            b = "%02d:%02d" % (max(0, min(23, int(v[2].get() or 0))), max(0, min(59, int(v[3].get() or 0))))
        except ValueError:
            return
        var.set("%s - %s" % (a, b) if v_aralik.get() else a)
        kapat()

    satirlar = tk.Frame(ic, bg=KART)
    satirlar.pack(fill="x", pady=(8, 0))
    bit_satiri = []
    for i, ad in enumerate(("Başlangıç", "Bitiş")):
        sf = tk.Frame(satirlar, bg=KART)
        sf.pack(fill="x", pady=2)
        tk.Label(sf, text=ad, bg=KART, fg="#33404D", font=font(10, True), width=9, anchor="w").pack(side="left")
        _saat_kutusu(sf, v[i * 2], 23, 1, yaz).pack(side="left")
        tk.Label(sf, text=":", bg=KART, font=font(12, True)).pack(side="left", padx=2)
        _saat_kutusu(sf, v[i * 2 + 1], 59, 5, yaz).pack(side="left")
        if i == 1:
            bit_satiri.append(sf)

    def aralik_goster(*_):
        if v_aralik.get():
            bit_satiri[0].pack(fill="x", pady=2)
        else:
            bit_satiri[0].pack_forget()
    if aralik:
        ttk.Checkbutton(ic, text="Bitiş saati de var (aralık)", variable=v_aralik, command=aralik_goster).pack(anchor="w", pady=(4, 0))
        hizli = tk.Frame(ic, bg=KART)
        hizli.pack(fill="x", pady=(6, 0))
        for i, (a_, b_) in enumerate((("08:00", "12:00"), ("09:00", "17:00"), ("13:00", "17:00"),
                                      ("08:00", "18:00"), ("18:00", "22:00"), ("00:00", "23:59"))):
            etiket = "Tüm gün" if a_ == "00:00" else "%s–%s" % (a_, b_)
            l_ = tk.Label(hizli, text=etiket, bg="#F2F4F7", fg="#33404D", font=font(9), padx=6, pady=2, cursor="hand2")
            l_.grid(row=i // 3, column=i % 3, padx=(0, 4), pady=2, sticky="ew")

            def sec(a_=a_, b_=b_):
                v[0].set(a_[:2]), v[1].set(a_[3:]), v[2].set(b_[:2]), v[3].set(b_[3:])
                v_aralik.set(True)
                yaz()
            l_.bind("<Button-1>", lambda e, f_=sec: (f_(), "break")[1])
    aralik_goster()

    dz = tk.Frame(ic, bg=KART)
    dz.pack(fill="x", pady=(10, 0))

    def simdi_():
        n = dt.datetime.now()
        v[0].set("%02d" % n.hour)
        v[1].set("%02d" % n.minute)
        if not v_aralik.get():
            yaz()
    ttk.Button(dz, text="Şimdi", command=simdi_).pack(side="left")
    ttk.Button(dz, text="Temizle", command=lambda: (var.set(""), kapat())).pack(side="left", padx=4)
    ttk.Button(dz, text="Tamam", style="Vurgu.TButton", command=yaz).pack(side="right")
    ttk.Button(dz, text="Kapat", command=kapat).pack(side="right", padx=(0, 4))

    def disari_tiklama(e):
        try:
            if not p.winfo_exists():
                return
            x, y = e.x_root, e.y_root
            if not (p.winfo_rootx() <= x <= p.winfo_rootx() + p.winfo_width() and
                    p.winfo_rooty() <= y <= p.winfo_rooty() + p.winfo_height()):
                kapat()
        except tk.TclError:
            pass
    p.update_idletasks()
    x = giris.winfo_rootx()
    y = giris.winfo_rooty() + giris.winfo_height() + 2
    if y + p.winfo_reqheight() > giris.winfo_screenheight() - 40:
        y = giris.winfo_rooty() - p.winfo_reqheight() - 2
    x = min(x, giris.winfo_screenwidth() - p.winfo_reqwidth() - 10)
    p.geometry("+%d+%d" % (max(0, x), max(0, y)))
    p.deiconify()
    p.lift()
    p.bind("<Escape>", lambda e: kapat())
    p.bind("<Button-1>", disari_tiklama, add="+")
    try:
        p.grab_set()
    except tk.TclError:
        pass
    p.focus_set()
    return p
