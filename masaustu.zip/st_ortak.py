# -*- coding: utf-8 -*-
"""Arayüz yardımcıları: renkli etiketler, kaydırılabilir alan, stiller."""
import sys
import tkinter as tk
from tkinter import ttk

from st_tanim import RENK, LACIVERT, VURGU, ZEMIN, KART, CIZGI, YAZI, SOLUK

YAZI_TIPI = "Segoe UI" if sys.platform.startswith("win") else "DejaVu Sans"


def font(boy=10, kalin=False, alti=False):
    f = [YAZI_TIPI, boy]
    if kalin:
        f.append("bold")
    if alti:
        f.append("underline")
    return tuple(f)


def stilleri_kur(root):
    st = ttk.Style(root)
    try:
        st.theme_use("clam")
    except tk.TclError:
        pass
    root.configure(bg=ZEMIN)
    st.configure(".", font=font(10), background=ZEMIN, foreground=YAZI)
    st.configure("TFrame", background=ZEMIN)
    st.configure("Kart.TFrame", background=KART)
    st.configure("TLabel", background=ZEMIN, foreground=YAZI)
    st.configure("Kart.TLabel", background=KART)
    st.configure("Soluk.TLabel", background=KART, foreground=SOLUK, font=font(9))
    st.configure("Baslik.TLabel", background=ZEMIN, font=font(17, True))
    st.configure("KartBaslik.TLabel", background=KART, font=font(12, True))
    st.configure("TButton", padding=(12, 7), font=font(10), background="#FFFFFF", bordercolor="#B9C2CC")
    st.map("TButton", background=[("active", "#E9EEF3"), ("disabled", "#F2F4F7")])
    st.configure("Vurgu.TButton", background=VURGU, foreground="#FFFFFF", font=font(10, True), bordercolor=VURGU)
    st.map("Vurgu.TButton", background=[("active", "#174A6E"), ("disabled", "#9BB5CA")],
           foreground=[("disabled", "#EEF3F7")])
    st.configure("Tehlike.TButton", foreground="#9E2A21")
    st.configure("TEntry", padding=5, fieldbackground="#FFFFFF", bordercolor="#B9C2CC")
    st.map("TEntry", fieldbackground=[("readonly", "#F2F4F7"), ("disabled", "#F2F4F7")])
    st.configure("Hata.TEntry", bordercolor="#D64538", fieldbackground="#FFF7F6")
    st.configure("TCombobox", padding=4)
    st.map("TCombobox", fieldbackground=[("readonly", "#FFFFFF"), ("disabled", "#F2F4F7")])
    st.configure("Treeview", rowheight=28, font=font(10), background="#FFFFFF", fieldbackground="#FFFFFF")
    st.configure("Treeview.Heading", font=font(9, True), background="#F5F7F9")
    st.configure("TCheckbutton", background=KART)
    st.configure("Zemin.TCheckbutton", background=ZEMIN)
    st.configure("TNotebook", background=ZEMIN)


def pill(parent, metin, renk="na", boy=9, bg_parent=KART):
    a, y, k = RENK[renk]
    return tk.Label(parent, text=metin, bg=a, fg=y, font=font(boy, True), padx=8, pady=2,
                    highlightthickness=1, highlightbackground=k, highlightcolor=k, bd=0)


def kart(parent, **kw):
    f = tk.Frame(parent, bg=KART, highlightthickness=1, highlightbackground=CIZGI, bd=0, **kw)
    return f


def link(parent, metin, komut, bg=KART, boy=10, kalin=True):
    l = tk.Label(parent, text=metin, bg=bg, fg=VURGU, font=font(boy, kalin, True), cursor="hand2")
    l.bind("<Button-1>", lambda e: komut())
    return l


def lbl(parent, metin="", bg=KART, fg=YAZI, boy=10, kalin=False, **kw):
    return tk.Label(parent, text=metin, bg=bg, fg=fg, font=font(boy, kalin), anchor="w", justify="left", **kw)


def bant(parent, metin, tur="bilgi"):
    """Bilgi / uyarı / kilit bandı."""
    renk = {"bilgi": ("#E9F1F8", "#1F3B55", "#A9C4DD"), "uyari": ("#FFF2C4", "#5C4300", "#E0A800"),
            "kilit": ("#F2F4F7", "#33404D", "#C9D1DA"), "hata": ("#FBE3E1", "#7A1F18", "#D64538")}[tur]
    f = tk.Frame(parent, bg=renk[0], highlightthickness=1, highlightbackground=renk[2])
    tk.Label(f, text=metin, bg=renk[0], fg=renk[1], font=font(10), justify="left", anchor="w",
             wraplength=760).pack(fill="x", padx=12, pady=9)
    return f


class KaydirmaliAlan(ttk.Frame):
    """Dikey kaydırılabilir alan. İçerik self.ic içine konur."""

    def __init__(self, parent, bg=ZEMIN):
        super().__init__(parent)
        self.canvas = tk.Canvas(self, bg=bg, highlightthickness=0, bd=0)
        self.sb = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.ic = tk.Frame(self.canvas, bg=bg)
        self._win = self.canvas.create_window((0, 0), window=self.ic, anchor="nw")
        self.canvas.configure(yscrollcommand=self.sb.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.sb.pack(side="right", fill="y")
        self.ic.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", lambda e: self.canvas.itemconfigure(self._win, width=e.width))
        self.bind("<Enter>", self._bagla)
        self.bind("<Leave>", self._coz)

    def _bagla(self, _e=None):
        self.canvas.bind_all("<MouseWheel>", self._tekerlek)
        self.canvas.bind_all("<Button-4>", lambda e: self.canvas.yview_scroll(-3, "units"))
        self.canvas.bind_all("<Button-5>", lambda e: self.canvas.yview_scroll(3, "units"))

    def _coz(self, _e=None):
        self.canvas.unbind_all("<MouseWheel>")
        self.canvas.unbind_all("<Button-4>")
        self.canvas.unbind_all("<Button-5>")

    def _tekerlek(self, e):
        if self.canvas.yview() == (0.0, 1.0):
            return
        self.canvas.yview_scroll(int(-e.delta / 120) * 3, "units")

    def basa(self):
        self.canvas.yview_moveto(0)


def ortala(pencere, ana=None, gen=None, yuk=None):
    pencere.update_idletasks()
    g = gen or pencere.winfo_width()
    y = yuk or pencere.winfo_height()
    if ana is not None:
        x = ana.winfo_rootx() + (ana.winfo_width() - g) // 2
        yy = ana.winfo_rooty() + (ana.winfo_height() - y) // 3
    else:
        x = (pencere.winfo_screenwidth() - g) // 2
        yy = (pencere.winfo_screenheight() - y) // 3
    pencere.geometry("%dx%d+%d+%d" % (g, y, max(x, 0), max(yy, 0)))
