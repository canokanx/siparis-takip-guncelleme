# -*- coding: utf-8 -*-
"""Sipariş ve Gemi Takip - Kullanım Kılavuzu (program içi ekran + yazdırılabilir HTML)."""
import os
import html
import tkinter as tk
from tkinter import ttk

from st_tanim import SURUM, PROGRAM_ADI, ZEMIN, KART, CIZGI, YAZI, SOLUK, VURGU, LACIVERT, tr_upper
from st_ortak import font

# Blok türleri: ("p", metin) paragraf · ("m", [madde, ...]) madde listesi · ("a", alt başlık)
#               ("i", metin) ipucu kutusu · ("u", metin) dikkat kutusu · ("adim", [adım, ...]) numaralı adımlar
# Bölüm: (anahtar, başlık, kimler için, [bloklar])
HERKES = ""
YONETICI = "Yönetici ve Üst Yönetici"
UST = "Yalnızca Üst Yönetici"

BOLUMLER = [
    ("baslarken", "Başlarken: giriş ve çıkış", HERKES, [
        ("p", "Program masaüstündeki \"Sipariş ve Gemi Takip\" simgesiyle açılır. Kullanıcı adınızı ve şifrenizi "
              "yazıp Giriş'e basın. Hesabınızı Üst Yönetici açar; şifrenizi unutursanız ona söyleyin, sıfırlar."),
        ("m", ["\"Bu bilgisayarda oturumum açık kalsın\" işaretliyse bir dahaki açılışta şifre sorulmaz. "
               "Ortak kullanılan bilgisayarlarda işaretlemeyin.",
               "Şifre en az 6 karakter olmalı. Büyük / küçük harf fark eder; Caps Lock açıksa ekranda uyarı çıkar.",
               "Arka arkaya 5 kez hatalı şifre girilirse o kullanıcı adı 60 saniye bekletilir.",
               "Sağ üstteki \"Çıkış\" oturumu kapatır ve giriş ekranına döner (hatırlanan oturum da silinir).",
               "Sağ üstteki \"↻ Yeniden başlat\" programı kapatıp hemen yeniden açar. Ekran takılırsa ya da "
               "güncelleme sonrası önce bunu deneyin."]),
        ("i", "Program zaten açıkken simgeye tekrar tıklarsanız ikinci bir program açılmaz; açık olan öne gelir."),
    ]),
    ("ekran", "Ekran düzeni", HERKES, [
        ("p", "Ekran üç parçadır: üstte lacivert çubuk, solda menü, ortada çalışma alanı."),
        ("a", "Üst çubuk"),
        ("m", ["Sol: program adı. Sağ: adınız, rolünüz, departmanınız, \"↻ Yeniden başlat\" ve \"Çıkış\".",
               "\"● Çevrimiçi\" (yeşil): ortak veritabanına bağlısınız. \"● Bağlantı yok\" (kırmızı): internet yok; "
               "ayrıntı için \"İnternet kesintisi ve aynı anda çalışma\" bölümüne bakın.",
               "\"· N kayıt gönderiliyor\": bağlantı yokken yaptığınız kayıtlar şu an gönderiliyor."]),
        ("a", "Sol menü"),
        ("m", ["Ana Panel · Siparişler · Gemi Takip · Boğaz Listeleri · Kullanım Kılavuzu: herkes görür.",
               "İşlem Geçmişi: Yönetici ve Üst Yönetici.",
               "Kullanıcılar / Yetki ve Ayarlar: Üst Yönetici.",
               "Ana Panel'in yanındaki kırmızı sayı, okunmamış uyarı sayısıdır.",
               "Menünün en altında program sürümü yazar."]),
        ("i", "Her ekranın sağ üstündeki \"? Kılavuz\" düğmesi bu kılavuzu o ekranın bölümünde açar."),
    ]),
    ("roller", "Roller ve yetkiler", HERKES, [
        ("p", "Her kullanıcının bir rolü (Kullanıcı / Yönetici / Üst Yönetici) ve bir departmanı (Satın Alma, Depo, "
              "Operasyon, Evrak, Finans, Yönetim) vardır."),
        ("a", "Kim neyi düzenler?"),
        ("m", ["Her aşamayı yalnızca o aşamanın sorumlu departmanı ve Üst Yönetici düzenler. Diğerleri aşamayı "
               "görüntüleme modunda görür (üstte açıklama yazar).",
               "8. aşama İade / İptal: Yönetici ve Üst Yönetici.",
               "Tamamlanmış (yeşil) aşamayı yalnızca Üst Yönetici yeniden açabilir.",
               "Siparişi genellikle Satın Alma açar; başka departman açmak isterse program bir kez sorar."]),
        ("a", "Kim neyi görür?"),
        ("m", ["Kullanıcı: Kullanıcıların girdiği bilgileri ve kendi departmanının aşamasındaki tüm bilgileri görür.",
               "Yönetici: Yönetici ve Kullanıcı girdilerini görür.",
               "Üst Yönetici: her şeyi görür.",
               "Göremediğiniz bir alan \"🔒 Gizli (Yönetici girdi)\" diye görünür.",
               "Sipariş no, müşteri, gemi, IMO ve termin herkese açıktır (iş akışı için gereklidir)."]),
    ]),
    ("ana", "Ana Panel", HERKES, [
        ("p", "Programın açılış ekranıdır: \"Bugün dikkat gerektiren işler\"."),
        ("a", "Üstteki dört kart"),
        ("m", ["Okunmamış uyarı: aşağıdaki listede henüz açmadığınız uyarılar.",
               "Açık sipariş: kapanmamış siparişler. \"Siparişlere git\" listeyi açar.",
               "Takipteki gemi: siparişi olan gemiler. \"Gemi Takip listesine git\".",
               "48 saatte gelecek gemi: ETA'sı 2 gün içinde olan gemiler. \"Listeyi aç\"."]),
        ("a", "Dikkat gerektirenler"),
        ("p", "Sipariş ve gemi hareketi birlikte değerlendirilir. Öncelik rengi: Kritik (kırmızı), Yüksek (turuncu), "
              "Normal (mavi), Bilgi (gri). Her satırda \"Siparişi aç\" ya da \"Gemiyi aç\" düğmesi vardır; "
              "açtığınız uyarı okundu sayılır ve soluklaşır."),
        ("m", ["Kritik: ETA'ya 24 saatten az kaldı ve depo hazır değil.",
               "ETA değişti · Depo hazır ve gemi yaklaşıyor · Gemi boğaz geçiş listesine girdi.",
               "IMO numarası eksik · Termin tarihi geçti.",
               "Depo kontrolü bekliyor: satın alma kalemleri tedarikçiden aldı, depo henüz işaretlemedi "
               "(depo, satın alma ve yöneticiler görür)."]),
    ]),
    ("siparisler", "Siparişler listesi", HERKES, [
        ("p", "Bütün siparişler ve her siparişin 8 aşamasının durumu bir arada görünür."),
        ("a", "Filtreler (üstteki kartlar)"),
        ("m", ["Açık sipariş: kapanmamış siparişler (varsayılan).",
               "Sevke hazır: depo paketlemeyi bitirmiş, operasyonu tamamlanmamış siparişler.",
               "Evrak bekliyor: depo paketlemeyi bitirmiş, evrakı tamamlanmamış siparişler.",
               "Depoya sevkiyatta: kaydı tamamlanmış, ürünleri depoya gelmekte olan siparişler.",
               "Ödeme bekliyor: gemiye teslim edilmiş, tahsilatı bitmemiş siparişler.",
               "Geciken: termin tarihi geçmiş açık siparişler.",
               "Tümü (kapananlar dahil).",
               "Silinenler: yalnızca Üst Yönetici görür."]),
        ("a", "Sütunlar ve renkler"),
        ("m", ["Sipariş No · Müşteri · Gemi · Termin (\"· gecikti\" kırmızı) · Aşamalar 1–8 · Genel durum · "
               "Sıradaki sorumlu · Son işlem.",
               "Aşama kutucukları: yeşil = Tamamlandı, sarı = Devam ediyor, kırmızı = Başlanmadı, gri = Pasif.",
               "Satıra tıklayınca sipariş açılır. Henüz kaydı yapılmamış siparişler \"— taslak —\" görünür."]),
        ("a", "Düğmeler"),
        ("m", ["\"+ Yeni Sipariş\": yeni sipariş numarası alır ve 1. aşamayı açar. Numara kendiliğinden verilir; "
               "aynı anda iki kişi açsa da numaralar çakışmaz.",
               "\"Excel'e aktar\": ekrandaki listeyi .xlsx dosyası olarak kaydeder.",
               "Arama kutusu: sipariş no, müşteri, gemi ya da IMO'nun bir parçasını yazın."]),
    ]),
    ("siparis", "Sipariş detayı ve aşama formu", HERKES, [
        ("p", "Sipariş açılınca üstte sipariş no, gemi, müşteri ve termin; altında 8 aşamanın kartları görünür. "
              "Bir karta tıklayınca o aşamanın formu açılır."),
        ("a", "Formu doldurmak"),
        ("m", ["Yıldızlı (*) alanlar zorunludur; aşama bunlar dolmadan tamamlanmaz.",
               "\"Kaydet\" (ya da \"Değişiklikleri kaydet\") yazdıklarınızı kaydeder. Başka ekrana geçerken kaydetmediğiniz "
               "değişiklikler de kendiliğinden kaydedilir.",
               "\"Aşamayı tamamla\": bütün koşullar sağlanınca aşamayı yeşile çevirir ve kilitler.",
               "Tamamlanan aşama kilitlidir. Düzeltme gerekirse Üst Yönetici \"Aşamayı yeniden aç\" ile açar.",
               "Her değişiklik eski ve yeni değeriyle İşlem Geçmişi'ne yazılır."]),
        ("a", "Sağ panel"),
        ("m", ["Tamamlanma koşulları: aşamayı tamamlamak için eksik olanlar maddeler halinde yazılır. "
               "\"✔ Tüm koşullar sağlandı\" yazınca tamamlayabilirsiniz. \"⚠ (zorunlu değil)\" maddeleri engellemez.",
               "Ekler: bu aşamaya yüklenen dosya ve fotoğraflar. Tıklayınca açılır. \"Dosya / fotoğraf ekle\".",
               "İşlem geçmişi: bu siparişte kim, ne zaman, neyi değiştirdi."]),
        ("a", "Sipariş silme"),
        ("m", ["\"Siparişi sil\": Üst Yönetici her siparişi; diğer kullanıcılar yalnızca kendi açtığı ve kaydı "
               "tamamlanmamış (taslak) siparişi silebilir. Silme nedeni yazılır.",
               "Silinen sipariş listelerden ve gemi takibinden kalkar ama yok edilmez. Üst Yönetici Siparişler → "
               "\"Silinenler\"den bulur ve \"Geri al (silmeyi kaldır)\" ile geri getirir."]),
        ("u", "Başka bir bilgisayarda silinen siparişe kayıt yapılamaz; program sizi uyarır."),
    ]),
    ("asamalar", "Aşamalar tek tek", HERKES, [
        ("p", "İş akışı: 1 Sipariş Kaydı → 2 Depoya Sevkiyat → 3 Depo & Paketleme → 4 Operasyon → 5 Evrak → "
              "6 Gemiye Sevkiyat → 7 Tahsilat. 8 İade / İptal yalnızca gerekirse açılır. "
              "Sipariş, 7. aşama (Tahsilat) tamamlanınca kapanır."),
        ("a", "1 · Sipariş Kaydı (Satın Alma)"),
        ("m", ["Sipariş tarihi, müşteri, gemi adı, siparişi alan, satış tutarı ve para birimi, komisyon, termin zorunlu.",
               "IMO numarası yazınca gemi adı kendiliğinden gelir (önce Kıyı Emniyeti listeleri, sonra VesselFinder). "
               "IMO 7 haneli olmalı; geçersizse kırmızı uyarı çıkar, adı elle yazın.",
               "Kaydedince gemi Gemi Takip listesine kendiliğinden eklenir.",
               "Tamamlamak için en az bir malzeme satırı eklenmiş olmalı (\"Malzeme satırları\" bölümüne bakın).",
               "Malzeme satırlarına birim fiyat girilir; satır tutarı (miktar × birim fiyat) ve listenin üstünde "
               "TOPLAM (siparişin para birimiyle) kendiliğinden hesaplanır. Fiyatı eksik satır varsa toplam kırmızı yazar."]),
        ("a", "2 · Depoya Sevkiyat (Satın Alma)"),
        ("m", ["Sade bir aşamadır: üstte yalnızca Depoya tahmini varış, Depoya varış, Depoda teslim alan ve Açıklama "
               "vardır (hepsi isteğe bağlı). \"Aşamayı tamamla\" yoktur; Kaydet yeter.",
               "Altta \"Malzeme listesi\" (fiyatsız): her kalem için 1. sütundaki açılır kutudan seçin: Alınacak (tedarikçiden biz "
               "alıyoruz) ya da Gönderilecek (tedarikçi depoya gönderiyor). Birden çok satırı seçip \"Seçilenler: Alınacak\" / "
               "\"Seçilenler: Gönderilecek\" de denebilir.",
               "Kalem alındı ya da gönderildiyse \"Tamam\" kutusuna tıklayın (☐ → ✔) ya da satırları seçip \"Seçilenler tamam\". "
               "Kaydedilmemiş satırların başında ● olur.",
               "Sonra \"Kaydet ve depoya bildir\". Liste depoya bildirim olarak düşer; depocunun Ana Panel'inde "
               "\"Depo kontrolü bekliyor\" uyarısı çıkar.",
               "Üstte \"Alınacak 12 · Gönderilecek 8 | Tamam: 15 / 20\" yazar. Hepsi ✔ olunca aşama kendiliğinden yeşile döner.",
               "Eski siparişlerde (depo işi bu aşama eklenmeden önce başlamışsa) bu aşama \"Pasif\" görünür."]),
        ("a", "3 · Depo & Paketleme (Depo)"),
        ("m", ["Bu aşamada da \"Aşamayı tamamla\" yoktur; Kaydet yeter.",
               "\"Depo kalem listesi\"nde her kalemin satın alma durumu (Alınacak / Gönderilecek, ✔ Alındı / ✔ Gönderildi) ve "
               "depo durumu görünür.",
               "Depocu satırları seçer (Ctrl / Shift ile birden çok) ve düğmeyle durum verir: Geldi – hazır · "
               "Geldi – hazırlanıyor · Bekleniyor · Eksik / gelmedi. \"Ayrıntı / not…\" ile gelen miktar ve not girilir. "
               "Sonra Kaydet.",
               "Renkler: yeşil = depoda hazır · turuncu = depoda ama hazırlanıyor / kısmi · sarı = satın alma aldı, depoya "
               "henüz gelmedi · kırmızı = eksik · beyaz = tedarikçide.",
               "Bütün kalemler \"Geldi – hazır\" olunca aşama kendiliğinden yeşile döner. Örneğin 20 kalemin 15'i hazır, 3'ü "
               "hazırlanıyor, 2'si bekleniyorsa aşama \"Devam ediyor\" kalır ve eksikler renkleriyle görünür.",
               "Paketleme bilgileri (KAP, brüt kilo, paketleme tarihi) isteğe bağlıdır; girilirse Evrak aşamasında KAP / kilo "
               "karşılaştırması yapılır."]),
        ("a", "4 · Operasyon (Operasyon)"),
        ("m", ["Sevk tarihi, saat aralığı, teslim noktası, sevk şekli, görevli, araç, giriş izni.",
               "Liman / tesis giriş izni \"Bekleniyor\" iken aşama tamamlanmaz."]),
        ("a", "5 · Evrak (Evrak)"),
        ("m", ["Kontrol durumu \"Tamamlandı\" olmalı.",
               "Evraktaki KAP ve brüt kilo, depo kaydıyla uyuşmazsa program uyarır ve tamamlatmaz.",
               "Evrak dosyası zorunlu değil; yüklenmediyse \"Belgesiz aşamayı tamamlamak istiyor musunuz?\" sorulur."]),
        ("a", "6 · Gemiye Sevkiyat (Operasyon)"),
        ("m", ["1–5. aşamalar tamamlanmadan (ya da Pasif olmadan) tamamlanamaz.",
               "Teslim durumu \"Gemiye teslim edildi\" ya da \"Kısmi teslim\" olmalı. Kısmi teslimde sevkiyat notuna "
               "eksikler yazılmalı."]),
        ("a", "7 · Tahsilat (Finans)"),
        ("m", ["Ödeme talebi, fatura ve tahsilat bilgileri. Ödeme talebi sevkiyattan önce de girilebilir.",
               "Tamamlamak için: 6. aşama (Gemiye Sevkiyat) tamamlanmış ve Tahsilat durumu \"Ödendi\" olmalı."]),
        ("a", "8 · İade / İptal (Yönetici)"),
        ("m", ["Standart akışta pasiftir. Gerekirse \"İade / Değişim / İptal sürecini başlat\" ile açılır.",
               "\"Süreci kapat (iptal et)\" siparişi iptal eder; iptal edilen siparişin kayıtları yalnızca görüntülenir."]),
    ]),
    ("tarih", "Tarih, saat ve saat aralığı girme", HERKES, [
        ("m", ["Tarih kutularına elle yazabilirsiniz: 03.11.2026 ya da kısaca 3.11.26 → program 03.11.2026'ya çevirir.",
               "Kutunun yanındaki \"Takvim\" düğmesi takvimi açar; güne tıklayın.",
               "Saatli alanlarda takvimin altında saat : dakika kutuları vardır (ok tuşları ya da fare tekerleği; dakika "
               "5'er artar) ve hazır saatler. \"Tamam\" ile yazılır.",
               "\"Şimdi / Bugün\" o anı yazar, \"Temizle\" kutuyu boşaltır. Esc ya da dışarı tıklamak kapatır.",
               "Saat aralığı (Operasyon): yanındaki \"Saat\" düğmesiyle başlangıç ve bitiş seçilir; hazır aralıklar "
               "08–12, 09–17, 13–17, 08–18, 18–22, Tüm gün. Elle de yazılır: 9-12 → 09:00 - 12:00, 2111 → 21:11."]),
    ]),
    ("malzeme", "Malzeme satırları ve toplama", HERKES, [
        ("p", "Malzeme satırları Sipariş Kaydı'nda (1. aşama) girilir. Aynı liste Depoya Sevkiyat (2) ve Depo & Paketleme (3) "
              "aşamalarında fiyatsız olarak görünür."),
        ("m", ["\"+ Satır ekle\": malzeme / açıklama ve miktar zorunlu; ürün kodu (IMPA), birim, birim fiyat, tedarikçi, "
               "termin isteğe bağlı. Fiyat 125,50 ya da 1.250,00 biçiminde yazılır.",
               "1. aşamada listenin üstünde TOPLAM yazar; her satırda Tutar = miktar × birim fiyat.",
               "\"Düzenle\" ya da satıra çift tıklama satırı düzeltir; \"Kaldır\" siler (geçmişte kalır).",
               "2. aşamada satın alma her kalemi açılır kutudan Alınacak / Gönderilecek seçer, alınan / gönderilen kalemi ✔ yapar ve "
               "\"Kaydet ve depoya bildir\"e basar.",
               "3. aşamada depo her kalemi işaretler: Geldi – hazır · Geldi – hazırlanıyor · Bekleniyor · Eksik / gelmedi; "
               "sonra Kaydet. Tamamlanmayan / kısmi kalemler turuncu görünür.",
               "Miktarda \"1.500\" 1,5 olarak okunur; bin beş yüz için 1500 yazın."]),
    ]),
    ("ekler", "Dosya ve fotoğraf ekleme", HERKES, [
        ("m", ["Sağ paneldeki \"Dosya / fotoğraf ekle\" ile her aşamaya dosya eklenir (PDF, Excel, Word, fotoğraf…).",
               "Fotoğraflar eklenirken kendiliğinden küçültülür (en uzun kenar 1600 piksel); PDF ve diğer dosyalara dokunulmaz.",
               "Eklenen dosyaya tıklayınca bilgisayarınızda açılır.",
               "Depo fotoğrafı ve evrak dosyası zorunlu değildir; eksikse aşama tamamlanırken sorulur."]),
    ]),
    ("gemiler", "Gemi Takip", HERKES, [
        ("p", "Siparişi olan gemilerin günlük operasyon listesi. Gemi, siparişe gemi adı ya da IMO yazılınca kendiliğinden eklenir."),
        ("a", "Liste"),
        ("m", ["Filtreler: Tümü · 48 saatte gelecek · ETA değişen · Boğaz geçişi · Deposu hazır · ETA belirsiz.",
               "Sütunlar: Gemi adı · Acente ETA · ETA değişimi · Depo durumu · Gemi hareketi · Kıyı Emniyeti (boğaz) · Siparişler.",
               "\"Excel'e aktar\" günlük operasyon listesini Excel'e yazar.",
               "Gemi adına tıklayınca gemi detayı açılır."]),
        ("a", "Gemi detayı"),
        ("m", ["\"Acenteden yeni ETA gir\": yeni ETA (gg.aa.yyyy ss:dd), bildiren acente ve hedef liman. Önceki ETA "
               "silinmez; fark otomatik hesaplanır ve operasyona uyarı düşer. ETA geçmişi tabloda görünür.",
               "Gemi bilgileri: IMO, bölge / mevcut konum, operasyon durumu, ikmal noktası, sorumlu personel. "
               "\"Gemi bilgilerini kaydet\".",
               "IMO girilmemişse ve Kıyı Emniyeti listesinde aynı adlı gemi varsa \"IMO … ekle\" önerisi çıkar.",
               "\"Geçiş geçmişini getir\": geminin Kıyı Emniyeti boğaz geçiş geçmişi.",
               "Bu gemiye bağlı siparişler ve gemi işlem geçmişi de bu ekrandadır."]),
        ("a", "Harita (VesselFinder)"),
        ("m", ["Listede \"⌖ Gemileri haritada gör\" (IMO'lu gemiler, en çok 12), gemi adının altında \"⌖ Harita\", "
               "gemi detayında \"⌖ Haritada göster (VesselFinder)\".",
               "Tarayıcıda geminin son AIS konumu ve son 24 saatlik rotası açılır; F5 ile güncellenir.",
               "Harita için IMO numarası gerekir."]),
    ]),
    ("bogaz", "Boğaz Listeleri (Kıyı Emniyeti)", HERKES, [
        ("p", "İstanbul ve Çanakkale Boğazı geçiş sırası listeleri 5 dakikada bir Kıyı Emniyeti'nden kendiliğinden alınır."),
        ("m", ["Sekmeler: İstanbul Boğazı · Çanakkale Boğazı · Son değişiklikler.",
               "Yeşil satırlar siparişi olan gemilerimizdir; çift tıklayınca gemi detayı açılır.",
               "\"Yalnızca siparişli gemilerimiz\" kutusu listeyi daraltır. \"Şimdi yenile\" beklemeden günceller.",
               "Son değişiklikler: listeye giren / çıkan gemiler, durum, plan zamanı ve yön değişiklikleri "
               "(son 1000, en yenisi üstte). Sıra numarası kaymaları değişiklik sayılmaz.",
               "Eşleştirme IMO ile yapılır; IMO yoksa birebir gemi adıyla."]),
    ]),
    ("bildirim", "Bildirimler ve arka planda çalışma", HERKES, [
        ("m", ["Pencerenin X'ine basınca program kapanmaz; saatin yanındaki simgede çalışmaya devam eder. "
               "Simgeye çift tıklayınca pencere açılır.",
               "Simgenin sağ tık menüsü: Aç · Bildirimleri duraklat · Güncellemeleri denetle · Yeniden başlat · Programı kapat.",
               "Program tepsideyken de güncellenir: yeni sürüm yayınlanınca birkaç dakika içinde kendiliğinden kurulur ve "
               "yeniden açılır.",
               "Windows açılınca program pencere açmadan kendiliğinden başlar.",
               "Başka kullanıcıların yaptıkları sağ altta bildirim olarak gelir (kendi yaptıklarınız gelmez). "
               "Bildirime tıklayınca ilgili sipariş ya da gemi açılır.",
               "Program kapalıyken olanlar açılışta \"Siz yokken N değişiklik\" diye özetlenir.",
               "Boğaz listeleri: siparişli gemilerimizin her değişikliği ayrı bildirim; diğer gemiler boğaz başına tek özet."]),
        ("a", "Hangi bildirimler gelsin?"),
        ("p", "Ayarlar → Genel → \"Arka planda çalışma ve bildirimler\" (Ayarlar'ı yalnızca Üst Yönetici açar; diğer "
              "bilgisayarlarda ayarı Üst Yönetici yapar). Seçenekler: depo listeleri · yeni sipariş · aşama durumları · bilgi değişiklikleri · "
              "dosyalar · silme / iptal · gemi ve ETA · kritik uyarılar · boğaz listeleri; ses açık / kapalı; Windows "
              "açılışında başlama."),
    ]),
    ("cevrimdisi", "İnternet kesintisi ve aynı anda çalışma", HERKES, [
        ("m", ["İnternet yokken üstte \"● Bağlantı yok\" yazar. Ana Panel, Siparişler ve Gemi Takip son bilinen haliyle açılır.",
               "Bu sırada yaptığınız kayıtlar bilgisayarda saklanır (program kapansa da kaybolmaz) ve bağlantı gelince "
               "kendiliğinden gönderilir.",
               "Başka bilgisayardaki değişiklikler 3–5 saniye içinde ekranınıza gelir.",
               "İki kişi aynı alanı değiştirirse ikinci kaydeden uyarılır: kimin ne yazdığı gösterilir, hangisinin "
               "kalacağını siz seçersiniz. Farklı alanlar birbirini etkilemez.",
               "Pasif yapılan kullanıcının oturumu birkaç saniyede kapanır; rol değişikliği hemen geçerli olur.",
               "Kayıt saatleri sunucu saatine göre yazılır; bilgisayar saati yanlış olsa da sıra bozulmaz."]),
    ]),
    ("gecmis", "İşlem Geçmişi", YONETICI, [
        ("p", "Programda yapılan her değişiklik burada listelenir: tarih, kullanıcı, sipariş, aşama, alan, eski ve yeni değer. "
              "Yönetici, Yönetici ve Kullanıcı kayıtlarını; Üst Yönetici hepsini görür. Bir siparişin yalnızca kendi geçmişi "
              "sipariş detayının sağ panelinde de görünür."),
    ]),
    ("kullanicilar", "Kullanıcılar / Yetki", UST, [
        ("m", ["\"+ Yeni kullanıcı\": ad soyad, kullanıcı adı, şifre (en az 6 karakter), rol ve departman.",
               "Listede kullanıcıya çift tıklayın ya da \"Düzenle\": rol, departman, Aktif / Pasif.",
               "\"Şifre sıfırla\": kullanıcıya yeni şifre verir.",
               "Ayrılan çalışanı silmek yerine Pasif yapın; geçmiş kayıtlarında adı kalır, giriş yapamaz."]),
    ]),
    ("ayarlar", "Ayarlar – Genel", UST, [
        ("m", ["Veriler bulutta: bu bilgisayarın hangi ortak veritabanına bağlı olduğunu gösterir.",
               "Veri klasörü: bulut kullanılmıyorsa verilerin tutulduğu klasör.",
               "Yedek al: veritabanının o anki kopyasını seçtiğiniz yere kaydeder.",
               "Masaüstü kısayolu: program simgeli kısayol oluşturur.",
               "Arka planda çalışma ve bildirimler: bildirim türleri, ses, X'e basınca arka planda kalma, Windows açılışı."]),
    ]),
    ("programci", "Programcı bölümü", UST, [
        ("p", "Ayarlar → \"Programcı (güncelleme · yedek)\". Programcı şifresiyle açılır (giriş şifresinden ayrıdır); "
              "\"Kilitle\" ile hemen kapanır."),
        ("m", ["0 Bulut veritabanı: Supabase bağlantısı (Session pooler adresi + veritabanı şifresi).",
               "0b Güvenli ekip kullanıcısı: ekip bilgisayarları kısıtlı kullanıcıyla bağlanır (tablo silemez, işlem "
               "geçmişini değiştiremez). Oluşturduktan sonra yeni kurulum .exe'si üretin.",
               "1 GitHub bağlantısı: kullanıcı adı, depolar ve token (bu bilgisayarda şifreli saklanır).",
               "2 Güncelleme yayınla: sürüm numarası + yenilikler → \"Güncellemeyi yayınla\".",
               "3 Otomatik güncelleme: ekipteki programlar yeni sürümü 5 dakikada bir arar (tepsideyken ve giriş "
               "ekranındayken de), indirip kurar. Program gizliyse hemen yeni sürümle açılır; pencere açıksa üstteki düğme "
               "yeşil \"Yeni sürüm … şimdi geç\" olur ve 3 dakika işlem yapılmazsa ya da pencere kapatılınca kendiliğinden "
               "geçer. \"Son denetim\" satırı sonucu gösterir; \"Güncelleme kaydını aç\" her denetimin kaydını açar.",
               "4 İnternete otomatik yedek: veritabanı + ekler gizli GitHub deposuna (varsayılan her gün, son 30). "
               "\"Şimdi yedekle\", \"Yedekleri listele\", \"Seçili yedeği geri yükle\".",
               "5 Kurulum .exe oluştur: yeni bilgisayar için tek dosyalık kurulum."]),
        ("u", "Kurulum .exe'sinin içinde veritabanı bağlantısı vardır. Ekip dışına vermeyin."),
    ]),
    ("mudahale", "Programa müdahale", UST, [
        ("p", "Ayarlar → \"Programa müdahale (bakım · silme)\", programcı şifresiyle. Her silmeden önce veriler bu "
              "bilgisayara yedeklenir (veri\\_mudahale_yedekleri, son 10) ve onay için kutuya SİL yazılması istenir. "
              "Her müdahale İşlem Geçmişi'ne yazılır."),
        ("m", ["1 Veritabanı durumu: kayıt sayıları, kullanılan alan.",
               "2 İşlem geçmişini sil: belirli tarihten eski / bir siparişin / tümü (\"Kaç kayıt var?\" ile önizleme).",
               "3 Silinen siparişleri kalıcı sil.",
               "4 Kaldırılmış ek dosyalarını kalıcı sil.",
               "5 Gemi kayıtları: siparişi olmayan gemileri sil · iki gemi kaydını birleştir.",
               "6 Sipariş düzeltme: aşama durumunu değiştir · sipariş numarasını düzelt · iptali kaldır.",
               "7 Bakım: onarım, sıkıştırma, bütün bilgisayarlarda verileri yeniden yükle, giriş kilitlerini kaldır.",
               "8 Bekleyen kayıtlar: şimdi gönder / sil.",
               "9 Hata kaydı: görüntüle, temizle."]),
        ("u", "Kalıcı silme geri alınamaz (yalnızca yedekten dönülür). Emin değilseniz yapmayın."),
    ]),
    ("sss", "Sık sorulanlar ve sorun giderme", HERKES, [
        ("a", "Aşamayı tamamlayamıyorum"),
        ("p", "Sağdaki \"Tamamlanma koşulları\" kutusuna bakın; eksik maddeler orada yazar. Aşama başka departmanınsa "
              "düzenleyemezsiniz (formun üstünde yazar)."),
        ("a", "Yanlışlıkla tamamladım"),
        ("p", "Üst Yöneticiden \"Aşamayı yeniden aç\" istemeniz gerekir."),
        ("a", "Bir alan \"🔒 Gizli\" görünüyor"),
        ("p", "O bilgiyi sizden üst rolde biri girmiş. Yetkiniz yoksa göremezsiniz; gerekirse yöneticinize sorun."),
        ("a", "\"● Bağlantı yok\" yazıyor"),
        ("p", "İnternetinizi kontrol edin. Çalışmaya devam edebilirsiniz; kayıtlarınız bağlantı gelince gönderilir. "
              "Uzun sürerse \"↻ Yeniden başlat\"."),
        ("a", "Başkasının yaptığı değişiklik ekranıma gelmedi"),
        ("p", "Birkaç saniye bekleyin ya da ekranı değiştirip geri gelin. Gelmezse \"↻ Yeniden başlat\"."),
        ("a", "\"Başka bir kullanıcı aynı alanı değiştirdi\" uyarısı"),
        ("p", "Siz formu açtıktan sonra aynı alanı başka biri kaydetmiş. Pencerede iki değer de görünür. EVET: sizin "
              "yazdığınız kaydedilir. HAYIR: onlarınki kalır (diğer değişiklikleriniz yine kaydedilir)."),
        ("a", "Gemi adı IMO'dan gelmedi"),
        ("p", "IMO'yu kontrol edin (7 rakam). Bulunamazsa gemi adını elle yazın; program engellemez."),
        ("a", "Yeni sürüm gelmedi"),
        ("p", "Saatin yanındaki simgeye sağ tıklayıp \"Güncellemeleri denetle\" deyin; sonuç sağ altta yazar. Üstte yeşil "
              "\"Yeni sürüm … şimdi geç\" düğmesi varsa ona basın. Hata olursa program klasöründeki guncelleme_kaydi.txt "
              "dosyasını yöneticiye gönderin."),
        ("a", "Bildirim gelmiyor"),
        ("p", "Saatin yanındaki simgede \"Bildirimleri duraklat\" açık olabilir. Ayarlar → Genel'de bildirim türlerine bakılır."),
        ("a", "Program açılmıyor / hata verdi"),
        ("p", "Masaüstü simgesine tekrar tıklayın. Olmazsa bilgisayarı yeniden başlatın. Hata devam ederse program "
              "klasöründeki hata_kaydi.txt dosyasını yöneticiye gönderin."),
    ]),
]

BOLUM = dict((b[0], b) for b in BOLUMLER)

# Ekran -> ilgili kılavuz bölümü ("? Kılavuz" düğmesi için)
EKRAN_BOLUM = {"ana": "ana", "siparisler": "siparisler", "siparis": "siparis", "gemiler": "gemiler", "gemi": "gemiler",
               "bogaz": "bogaz", "gecmis": "gecmis", "kullanicilar": "kullanicilar", "ayarlar": "ayarlar",
               "ayarlar:programci": "programci", "ayarlar:mudahale": "mudahale"}


def _metin_parcalari(bolum):
    out = [bolum[1]]
    for tur, ic in bolum[3]:
        if isinstance(ic, (list, tuple)):
            out.extend(ic)
        else:
            out.append(ic)
    return out


def bolum_metni(bolum):
    return "\n".join(_metin_parcalari(bolum))


def ara(sorgu):
    """Aranan sözcüğü içeren bölümlerin anahtarları."""
    s = tr_upper((sorgu or "").strip())
    if not s:
        return [b[0] for b in BOLUMLER]
    return [b[0] for b in BOLUMLER if s in tr_upper(bolum_metni(b))]


# ------------------------------------------------------------------ HTML (yazdırılabilir)
def html_uret():
    e = html.escape
    p = []
    p.append("<!doctype html><html lang='tr'><head><meta charset='utf-8'><title>%s – Kullanım Kılavuzu</title>" % e(PROGRAM_ADI))
    p.append("<style>body{font-family:'Segoe UI',Arial,sans-serif;color:#14202B;max-width:860px;margin:32px auto;"
             "padding:0 20px;line-height:1.55;font-size:15px}h1{color:#0E2335;margin-bottom:2px}"
             ".alt{color:#55606E;margin-top:0}h2{color:#0E2335;border-bottom:2px solid #1F5F8B;padding-bottom:4px;"
             "margin-top:36px;page-break-after:avoid}h3{color:#1F5F8B;margin:18px 0 4px}.kim{font-size:12px;"
             "background:#E1ECF7;color:#1F4E79;padding:2px 8px;border-radius:10px;margin-left:8px;vertical-align:middle;"
             "font-weight:normal}.ipucu{background:#E1ECF7;border-left:4px solid #3E7CB8;padding:8px 12px;margin:10px 0}"
             ".dikkat{background:#FFF2C4;border-left:4px solid #E0A800;padding:8px 12px;margin:10px 0}"
             "ul,ol{padding-left:22px}li{margin:3px 0}.icindekiler{columns:2;font-size:14px}"
             "@media print{body{margin:0}a{color:inherit;text-decoration:none}}</style></head><body>")
    p.append("<h1>%s</h1><p class='alt'>Kullanım Kılavuzu · Sürüm %s</p>" % (e(PROGRAM_ADI), e(SURUM)))
    p.append("<h2>İçindekiler</h2><ol class='icindekiler'>")
    for b in BOLUMLER:
        p.append("<li><a href='#%s'>%s</a></li>" % (b[0], e(b[1])))
    p.append("</ol>")
    for i, b in enumerate(BOLUMLER, 1):
        kim = (" <span class='kim'>%s</span>" % e(b[2])) if b[2] else ""
        p.append("<h2 id='%s'>%d. %s%s</h2>" % (b[0], i, e(b[1]), kim))
        for tur, ic in b[3]:
            if tur == "p":
                p.append("<p>%s</p>" % e(ic))
            elif tur == "a":
                p.append("<h3>%s</h3>" % e(ic))
            elif tur == "m":
                p.append("<ul>" + "".join("<li>%s</li>" % e(x) for x in ic) + "</ul>")
            elif tur == "adim":
                p.append("<ol>" + "".join("<li>%s</li>" % e(x) for x in ic) + "</ol>")
            elif tur == "i":
                p.append("<div class='ipucu'>💡 %s</div>" % e(ic))
            elif tur == "u":
                p.append("<div class='dikkat'>⚠ %s</div>" % e(ic))
    p.append("<p class='alt' style='margin-top:40px'>Yazdırmak ya da PDF olarak kaydetmek için Ctrl+P.</p></body></html>")
    return "".join(p)


def html_kaydet(klasor):
    os.makedirs(klasor, exist_ok=True)
    yol = os.path.join(klasor, "kullanim_kilavuzu.html")
    with open(yol, "w", encoding="utf-8") as f:
        f.write(html_uret())
    return yol


# ------------------------------------------------------------------ Ekran
def ekran_kilavuz(self, bolum=None, arama=""):
    from st_arayuz import dosya_ac
    ic = tk.Frame(self.icerik, bg=ZEMIN)
    ic.pack(fill="both", expand=True, padx=24, pady=18)
    bas = tk.Frame(ic, bg=ZEMIN)
    bas.pack(fill="x", pady=(0, 12))
    sol_b = tk.Frame(bas, bg=ZEMIN)
    sol_b.pack(side="left")
    tk.Label(sol_b, text="Kullanım Kılavuzu", bg=ZEMIN, fg=YAZI, font=font(18, True)).pack(anchor="w")
    tk.Label(sol_b, text="Programın bütün bölümleri adım adım · Sürüm %s" % SURUM, bg=ZEMIN, fg=SOLUK,
             font=font(10)).pack(anchor="w")

    def yazdir():
        try:
            klasor = os.path.join(getattr(self.db, "klasor", None) or os.path.dirname(os.path.abspath(__file__)), "kilavuz")
            dosya_ac(html_kaydet(klasor))
        except Exception as ex:
            from tkinter import messagebox
            messagebox.showerror("Kılavuz açılamadı", str(ex))
    ttk.Button(bas, text="Yazdırılabilir kılavuzu aç", command=yazdir).pack(side="right")

    govde = tk.Frame(ic, bg=ZEMIN)
    govde.pack(fill="both", expand=True)

    # sol: arama + bölüm listesi
    sol = tk.Frame(govde, bg=KART, highlightthickness=1, highlightbackground=CIZGI, width=250)
    sol.pack(side="left", fill="y")
    sol.pack_propagate(False)
    tk.Label(sol, text="Kılavuzda ara", bg=KART, fg=SOLUK, font=font(9)).pack(anchor="w", padx=12, pady=(12, 2))
    ara_var = tk.StringVar(value=arama)
    ara_kutu = ttk.Entry(sol, textvariable=ara_var)
    ara_kutu.pack(fill="x", padx=12)
    liste = tk.Frame(sol, bg=KART)
    liste.pack(fill="both", expand=True, pady=(10, 6))

    # sağ: içerik (salt okunur Text)
    sag = tk.Frame(govde, bg=KART, highlightthickness=1, highlightbackground=CIZGI)
    sag.pack(side="left", fill="both", expand=True, padx=(12, 0))
    kay = ttk.Scrollbar(sag, orient="vertical")
    kay.pack(side="right", fill="y")
    t = tk.Text(sag, wrap="word", bg=KART, fg=YAZI, relief="flat", bd=0, padx=26, pady=20, font=font(11),
                yscrollcommand=kay.set, cursor="arrow", spacing1=2, spacing3=2)
    t.pack(side="left", fill="both", expand=True)
    kay.configure(command=t.yview)
    t.tag_configure("baslik", font=font(17, True), foreground=LACIVERT, spacing3=4)
    t.tag_configure("kim", font=font(9, True), foreground="#1F4E79", spacing3=10)
    t.tag_configure("alt", font=font(12, True), foreground=VURGU, spacing1=12, spacing3=4)
    t.tag_configure("p", spacing3=8)
    t.tag_configure("m", lmargin1=8, lmargin2=26, spacing3=4)
    t.tag_configure("i", background="#E1ECF7", foreground="#1F4E79", lmargin1=10, lmargin2=10, rmargin=10,
                    spacing1=6, spacing3=8)
    t.tag_configure("u", background="#FFF2C4", foreground="#6B4E00", lmargin1=10, lmargin2=10, rmargin=10,
                    spacing1=6, spacing3=8)
    t.tag_configure("bul", background="#FFE08A")
    t.tag_configure("bagla", foreground=VURGU, underline=True)
    t.tag_bind("bagla", "<Enter>", lambda e: t.configure(cursor="hand2"))
    t.tag_bind("bagla", "<Leave>", lambda e: t.configure(cursor="arrow"))

    durum = {"bolum": bolum if bolum in BOLUM else BOLUMLER[0][0], "satirlar": {}}

    def ekle(metin, *etiket):
        # Tk 8.6 metin kutusunda BMP dışı karakterler (ör. emoji) aramada çökmeye yol açar: ayıkla
        t.insert("end", "".join(c for c in metin if ord(c) <= 0xFFFF), etiket)

    def yaz(anahtar):
        durum["bolum"] = anahtar
        b = BOLUM[anahtar]
        t.configure(state="normal")
        t.delete("1.0", "end")
        sira = [x[0] for x in BOLUMLER].index(anahtar) + 1
        ekle("%d. %s\n" % (sira, b[1]), "baslik")
        ekle(("Kimler için: %s\n" % b[2]) if b[2] else "Herkes için\n", "kim")
        for tur, icerik in b[3]:
            if tur == "p":
                ekle(icerik + "\n", "p")
            elif tur == "a":
                ekle(icerik + "\n", "alt")
            elif tur == "m":
                for x in icerik:
                    ekle("•  " + x + "\n", "m")
                ekle("\n", "p")
            elif tur == "adim":
                for j, x in enumerate(icerik, 1):
                    ekle("%d.  %s\n" % (j, x), "m")
                ekle("\n", "p")
            elif tur == "i":
                ekle("ℹ  " + icerik + "\n", "i")
                ekle("\n", "p")
            elif tur == "u":
                ekle("⚠  " + icerik + "\n", "u")
                ekle("\n", "p")
        # sonraki bölüme geçiş
        sirali = [x[0] for x in BOLUMLER]
        i = sirali.index(anahtar)
        if i + 1 < len(sirali):
            sonraki = sirali[i + 1]
            ekle("\nSonraki bölüm: %s  →" % BOLUM[sonraki][1], "bagla", "sonraki")
            t.tag_bind("sonraki", "<Button-1>", lambda e, s=sonraki: (yaz(s), liste_kur()))
        vurgula()
        t.configure(state="disabled")
        t.yview_moveto(0)

    def vurgula():
        t.tag_remove("bul", "1.0", "end")
        s = ara_var.get().strip()
        if not s:
            return
        ilk = None
        bas_ = "1.0"
        while True:
            konum = t.search(s, bas_, stopindex="end", nocase=True)
            if not konum:
                break
            son = "%s+%dc" % (konum, len(s))
            t.tag_add("bul", konum, son)
            ilk = ilk or konum
            bas_ = son
        if ilk:
            t.see(ilk)

    def liste_kur():
        for w in liste.winfo_children():
            w.destroy()
        uygun = ara(ara_var.get())
        if not uygun:
            tk.Label(liste, text="Eşleşen bölüm yok.", bg=KART, fg=SOLUK, font=font(10)).pack(anchor="w", padx=12)
            return
        for j, b in enumerate(BOLUMLER, 1):
            if b[0] not in uygun:
                continue
            sec = b[0] == durum["bolum"]
            renk = "#E4ECF3" if sec else KART
            l = tk.Label(liste, text="%d. %s" % (j, b[1]), bg=renk, fg=YAZI, font=font(10, sec), anchor="w",
                         padx=12, pady=5, cursor="hand2", wraplength=220, justify="left")
            l.pack(fill="x")
            l.bind("<Button-1>", lambda e, a=b[0]: (yaz(a), liste_kur()))
        if durum["bolum"] not in uygun:
            yaz(uygun[0])
            liste_kur()

    def aramada(*_):
        liste_kur()
        t.configure(state="normal")
        vurgula()
        t.configure(state="disabled")
    ara_var.trace_add("write", aramada)

    yaz(durum["bolum"])
    liste_kur()
    t.bind("<MouseWheel>", lambda e: t.yview_scroll(int(-e.delta / 120), "units"))
    t.bind("<Button-4>", lambda e: t.yview_scroll(-3, "units"))
    t.bind("<Button-5>", lambda e: t.yview_scroll(3, "units"))
    self._kaydet_cb = None


def kilavuz_ekle(Ana):
    Ana.ekran_kilavuz = ekran_kilavuz
