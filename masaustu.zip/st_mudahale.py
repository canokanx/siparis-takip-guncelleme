# -*- coding: utf-8 -*-
"""Programa müdahale (bakım) işlemleri – yalnızca Programcı sekmesinden, şifreyle.

Her silme işleminden önce verilerin tamamı bu bilgisayara yedeklenir (veri\\_mudahale_yedekleri, son 10 yedek).
Bulutta silme yalnızca YÖNETİCİ bağlantısıyla yapılabilir (ekip kullanıcısının silme yetkisi yoktur).
Her müdahale İşlem Geçmişi'ne yazılır."""
import os
import glob
import shutil
import datetime as dt

YEDEK_KLASORU = "_mudahale_yedekleri"
TUTULACAK = 10


class MudahaleHatasi(Exception):
    pass


# ------------------------------------------------------------------ yardımcılar
def _say(db, sql, params=()):
    r = db._taze(sql, params).fetchone()
    return int(r[0] or 0) if r else 0


def _bulut_sonrasi(db):
    """Toplu silmeden sonra bütün bilgisayarlar sipariş kopyalarını baştan yükler."""
    if db.bulut:
        from st_bulut import veri_nesli_yenile
        veri_nesli_yenile(db.c)


def silme_yetkisi(db):
    """(yetkili mi, açıklama)"""
    if not db.bulut:
        return True, ""
    from st_bulut import yonetici_mi
    if yonetici_mi(db.c):
        return True, ""
    return False, ("Bu bilgisayar kısıtlı ekip kullanıcısıyla bağlı; kalıcı silme yapamaz. "
                   "Silme işlemlerini yönetici bilgisayarından yapın.")


def oncesi_yedek(db, etiket):
    """Müdahaleden önce verilerin tamamını yerel bir SQLite dosyasına yedekler. Yedek yolunu döner."""
    kl = os.path.join(db.klasor, YEDEK_KLASORU)
    os.makedirs(kl, exist_ok=True)
    ad = "oncesi_%s_%s.db" % (dt.datetime.now().strftime("%Y%m%d_%H%M%S"), "".join(
        ch for ch in etiket.lower() if ch.isascii() and ch.isalnum())[:30])
    yol = os.path.join(kl, ad)
    db.sqlite_kopyasi(yol)
    eski = sorted(glob.glob(os.path.join(kl, "oncesi_*.db")))
    for f in eski[:-TUTULACAK]:
        try:
            os.remove(f)
        except OSError:
            pass
    return yol


def _not(db, kullanici, aciklama, siparis_id=None, gemi_id=None):
    db._denetim(kullanici, "Programcı müdahalesi: " + aciklama, siparis_id=siparis_id, gemi_id=gemi_id)
    db.c.commit()


# ------------------------------------------------------------------ durum özeti
TABLO_ADLARI = [("siparisler", "Sipariş"), ("asama_veri", "Aşama bilgisi"), ("satirlar", "Malzeme satırı"),
                ("ekler", "Ek dosya kaydı"), ("denetim", "İşlem geçmişi kaydı"), ("gemiler", "Gemi"),
                ("etalar", "ETA kaydı"), ("kullanicilar", "Kullanıcı"), ("okundu", "Okundu işareti")]


def durum_ozeti(db):
    d = {"tablolar": [(ad, _say(db, "SELECT COUNT(*) FROM %s" % t)) for t, ad in TABLO_ADLARI]}
    d["silinen_siparis"] = _say(db, "SELECT COUNT(*) FROM siparisler WHERE silindi=1")
    d["kaldirilan_ek"] = _say(db, "SELECT COUNT(*) FROM ekler WHERE silindi=1")
    d["sahipsiz_gemi"] = len(sahipsiz_gemiler(db))
    if db.bulut:
        d["boyut"] = int(db._taze("SELECT pg_database_size(current_database())").fetchone()[0] or 0)
        d["ek_boyut"] = int(db._taze("SELECT COALESCE(SUM(octet_length(veri)), 0) FROM ek_dosyalar").fetchone()[0] or 0)
        d["sinir"] = 500 * 1024 * 1024
    else:
        d["boyut"] = os.path.getsize(db.yol) if os.path.exists(db.yol) else 0
        top = 0
        for kok, _, dosyalar in os.walk(db.ek_klasoru):
            for f in dosyalar:
                try:
                    top += os.path.getsize(os.path.join(kok, f))
                except OSError:
                    pass
        d["ek_boyut"] = top
        d["sinir"] = None
    return d


# ------------------------------------------------------------------ işlem geçmişi
def gecmis_kosul(tur, tarih=None, siparis_id=None):
    """(WHERE metni, parametreler). tur: 'once' (tarihten eski) · 'siparis' · 'tumu'"""
    if tur == "once":
        return "zaman < ?", (tarih.strftime("%Y-%m-%d"),)
    if tur == "siparis":
        return "siparis_id = ?", (siparis_id,)
    return "1=1", ()


def gecmis_say(db, tur, tarih=None, siparis_id=None):
    w, p = gecmis_kosul(tur, tarih, siparis_id)
    return _say(db, "SELECT COUNT(*) FROM denetim WHERE " + w, p)


def gecmis_sil(db, kullanici, tur, tarih=None, siparis_id=None, aciklama=""):
    w, p = gecmis_kosul(tur, tarih, siparis_id)
    with db.islem():
        n = _say(db, "SELECT COUNT(*) FROM denetim WHERE " + w, p)
        db.c.execute("DELETE FROM denetim WHERE " + w, p)
    _not(db, kullanici, "%d işlem geçmişi kaydı silindi (%s)" % (n, aciklama), siparis_id=siparis_id)
    _bulut_sonrasi(db)
    return n


# ------------------------------------------------------------------ silinen siparişler
def silinen_siparisler(db):
    return [dict(r) for r in db._taze("SELECT id, no, silinme, silme_nedeni FROM siparisler WHERE silindi=1 ORDER BY id DESC")]


def siparis_kalici_sil(db, kullanici, sids):
    """Silinmiş siparişleri bütün bilgileriyle (aşama bilgileri, malzeme, ekler, işlem geçmişi) kalıcı siler."""
    if not sids:
        return 0
    yer = ",".join("?" * len(sids))
    nolar = [r[0] for r in db._taze("SELECT no FROM siparisler WHERE silindi=1 AND id IN (%s)" % yer, sids)]
    sids = [r[0] for r in db._taze("SELECT id FROM siparisler WHERE silindi=1 AND id IN (%s)" % yer, sids)]
    if not sids:
        return 0
    yer = ",".join("?" * len(sids))
    yollar = [r[0] for r in db._taze("SELECT goreli_yol FROM ekler WHERE siparis_id IN (%s)" % yer, sids)]
    with db.islem():
        if db.bulut:
            db.c.execute("DELETE FROM ek_dosyalar WHERE ek_id IN (SELECT id FROM ekler WHERE siparis_id IN (%s))" % yer, sids)
        for t in ("ekler", "satirlar", "asama_veri", "asama_durum", "denetim"):
            db.c.execute("DELETE FROM %s WHERE siparis_id IN (%s)" % (t, yer), sids)
        db.c.execute("DELETE FROM siparisler WHERE id IN (%s)" % yer, sids)
    if not db.bulut:
        for g in yollar:
            try:
                os.remove(os.path.join(db.klasor, g))
            except OSError:
                pass
    _not(db, kullanici, "%d silinmiş sipariş kalıcı olarak silindi: %s" % (len(sids), ", ".join(nolar)[:400]))
    _bulut_sonrasi(db)
    return len(sids)


# ------------------------------------------------------------------ kaldırılmış ekler
def kaldirilan_ekleri_temizle(db, kullanici):
    """'Kaldırıldı' işaretli eklerin dosyalarını kalıcı siler (yer açar)."""
    ekler = [dict(r) for r in db._taze("SELECT id, goreli_yol, dosya_adi FROM ekler WHERE silindi=1")]
    if not ekler:
        return 0, 0
    bayt = 0
    if db.bulut:
        bayt = int(db._taze("SELECT COALESCE(SUM(octet_length(veri)),0) FROM ek_dosyalar WHERE ek_id IN "
                            "(SELECT id FROM ekler WHERE silindi=1)").fetchone()[0] or 0)
        with db.islem():
            db.c.execute("DELETE FROM ek_dosyalar WHERE ek_id IN (SELECT id FROM ekler WHERE silindi=1)")
            db.c.execute("DELETE FROM ekler WHERE silindi=1")
    else:
        for e in ekler:
            yol = os.path.join(db.klasor, e["goreli_yol"])
            try:
                bayt += os.path.getsize(yol)
                os.remove(yol)
            except OSError:
                pass
        db.c.execute("DELETE FROM ekler WHERE silindi=1")
        db.c.commit()
    _not(db, kullanici, "%d kaldırılmış ek dosyası kalıcı silindi (%.1f MB)" % (len(ekler), bayt / 1048576.0))
    _bulut_sonrasi(db)
    return len(ekler), bayt


# ------------------------------------------------------------------ gemiler
def sahipsiz_gemiler(db):
    """Hiçbir (silinmemiş) siparişe bağlı olmayan gemiler."""
    return [dict(r) for r in db._taze(
        "SELECT g.id, g.ad, g.imo FROM gemiler g WHERE NOT EXISTS "
        "(SELECT 1 FROM siparisler s WHERE s.gemi_id = g.id AND s.silindi = 0) ORDER BY g.ad")]


def gemileri_sil(db, kullanici, gids):
    if not gids:
        return 0
    yer = ",".join("?" * len(gids))
    adlar = [r[0] for r in db._taze("SELECT ad FROM gemiler WHERE id IN (%s)" % yer, gids)]
    with db.islem():
        db.c.execute("UPDATE siparisler SET gemi_id=NULL WHERE gemi_id IN (%s)" % yer, gids)
        db.c.execute("DELETE FROM etalar WHERE gemi_id IN (%s)" % yer, gids)
        db.c.execute("DELETE FROM gemiler WHERE id IN (%s)" % yer, gids)
    _not(db, kullanici, "%d gemi kaydı silindi: %s" % (len(gids), ", ".join(adlar)[:400]))
    _bulut_sonrasi(db)
    return len(gids)


def gemi_birlestir(db, kullanici, kaynak, hedef):
    """'kaynak' geminin siparişleri, ETA'ları ve geçmişi 'hedef' gemiye aktarılır, kaynak silinir."""
    if kaynak == hedef:
        raise MudahaleHatasi("Aynı gemi seçildi.")
    k, h = db.gemi(kaynak), db.gemi(hedef)
    if not k or not h:
        raise MudahaleHatasi("Gemi bulunamadı.")
    with db.islem():
        db.c.execute("UPDATE siparisler SET gemi_id=? WHERE gemi_id=?", (hedef, kaynak))
        db.c.execute("UPDATE etalar SET gemi_id=? WHERE gemi_id=?", (hedef, kaynak))
        db.c.execute("UPDATE denetim SET gemi_id=? WHERE gemi_id=?", (hedef, kaynak))
        if k.get("imo") and not h.get("imo"):
            db.c.execute("UPDATE gemiler SET imo=? WHERE id=?", (k["imo"], hedef))
        db.c.execute("DELETE FROM gemiler WHERE id=?", (kaynak,))
    _not(db, kullanici, "Gemi birleştirildi: %s → %s" % (k["ad"], h["ad"]), gemi_id=hedef)
    _bulut_sonrasi(db)


# ------------------------------------------------------------------ sipariş düzeltme
def siparis_bul(db, no):
    r = db._taze("SELECT * FROM siparisler WHERE UPPER(no)=?", ((no or "").strip().upper(),)).fetchone()
    return dict(r) if r else None


def asama_durumlarini_yaz(db, kullanici, sid, durumlar):
    """durumlar: {asama: 'todo'|'prog'|'done'|'na'} – kurallara bakmadan doğrudan yazar."""
    from st_tanim import DURUM
    eski = db.durumlar(sid)
    degisen = []
    with db.islem():
        for n, d in durumlar.items():
            if eski.get(n) == d:
                continue
            if n in eski:
                db.c.execute("UPDATE asama_durum SET durum=?, guncelleyen_id=?, zaman=? WHERE siparis_id=? AND asama=?",
                             (d, kullanici["id"], _simdi(), sid, n))
            else:
                db.c.execute("INSERT INTO asama_durum (siparis_id, asama, durum, guncelleyen_id, zaman) VALUES (?,?,?,?,?)",
                             (sid, n, d, kullanici["id"], _simdi()))
            db._denetim(kullanici, "Programcı müdahalesi: Aşama %d durumu %s → %s" % (
                n, DURUM.get(eski.get(n), eski.get(n) or "yok"), DURUM.get(d, d)),
                siparis_id=sid, asama=n, alan="durum", eski=eski.get(n), yeni=d)
            degisen.append(n)
    return degisen


def siparis_no_degistir(db, kullanici, sid, yeni_no):
    yeni_no = (yeni_no or "").strip().upper()
    if not yeni_no:
        raise MudahaleHatasi("Yeni sipariş numarası boş.")
    if _say(db, "SELECT COUNT(*) FROM siparisler WHERE UPPER(no)=? AND id<>?", (yeni_no, sid)):
        raise MudahaleHatasi("%s numaralı başka bir sipariş var." % yeni_no)
    eski = db._taze("SELECT no FROM siparisler WHERE id=?", (sid,)).fetchone()[0]
    with db.islem():
        db.c.execute("UPDATE siparisler SET no=? WHERE id=?", (yeni_no, sid))
        db._denetim(kullanici, "Programcı müdahalesi: sipariş numarası %s → %s" % (eski, yeni_no), siparis_id=sid,
                    alan="no", eski=eski, yeni=yeni_no)


def iptali_kaldir(db, kullanici, sid):
    with db.islem():
        db.c.execute("UPDATE siparisler SET iptal=0 WHERE id=?", (sid,))
        db._denetim(kullanici, "Programcı müdahalesi: sipariş iptali kaldırıldı", siparis_id=sid)


def _simdi():
    from st_db import simdi
    return simdi()


# ------------------------------------------------------------------ onarım / bakım
def eksik_asamalari_onar(db, kullanici):
    """Aşama durum kaydı eksik siparişlere eksik aşamaları ekler."""
    eksik = 0
    var_ = {}
    for r in db._taze("SELECT siparis_id, asama FROM asama_durum"):
        var_.setdefault(r[0], set()).add(r[1])
    for (sid,) in [(r[0],) for r in db._taze("SELECT id FROM siparisler")]:
        var = var_.get(sid, set())
        for n in range(1, 7):
            if n not in var:
                db.c.execute("INSERT INTO asama_durum (siparis_id, asama, durum, guncelleyen_id, zaman) VALUES (?,?,?,?,?)",
                             (sid, n, "na" if n == 6 else "todo", kullanici["id"], _simdi()))
                eksik += 1
    db.c.commit()
    if eksik:
        _not(db, kullanici, "%d eksik aşama kaydı onarıldı" % eksik)
    return eksik


def gemi_baglarini_onar(db, kullanici, kegm=None):
    import st_mantik as M
    once = len(db.gemiler())
    M.gemileri_esitle(db, kullanici, kegm)
    return once, len(db.gemiler())


def okundu_temizle(db, kullanici):
    n = _say(db, "SELECT COUNT(*) FROM okundu")
    db.c.execute("DELETE FROM okundu")
    db.c.commit()
    _not(db, kullanici, "%d okundu işareti temizlendi (uyarılar herkese yeniden okunmamış görünür)" % n)
    return n


def sikistir(db):
    """Veritabanını sıkıştırır (silinen kayıtların yeri geri kazanılır)."""
    if db.bulut:
        for t in ("denetim", "ek_dosyalar", "asama_veri", "siparisler", "ekler"):
            try:
                db.c._calistir_ham_yaz("VACUUM ANALYZE %s" % t)
            except Exception:
                pass
    else:
        db.c.commit()
        db.c.execute("VACUUM")


def yerel_onbellegi_temizle(db, program_klasoru):
    """Bu bilgisayardaki önbellek dosyalarını siler (veriler silinmez). Program yeniden açılınca baştan iner."""
    silinen = []
    if db.bulut:
        for f in glob.glob(os.path.join(db.klasor, "ayna_*.dat*")):
            silinen.append(f)
        for f in glob.glob(os.path.join(db.klasor, "ek_onbellek", "*")):
            silinen.append(f)
    for ad in ("imo_onbellek.json", "kegm_onbellek.json"):
        f = os.path.join(program_klasoru, ad)
        if os.path.exists(f):
            silinen.append(f)
    n = 0
    for f in silinen:
        try:
            os.remove(f)
            n += 1
        except OSError:
            pass
    if db.bulut and db.c.ayna is not None:
        db.c.ayna.dosya = None  # kapanışta yeniden yazılmasın
    return n


def hata_kaydi(program_klasoru, son=6000):
    yol = os.path.join(program_klasoru, "hata_kaydi.txt")
    if not os.path.exists(yol):
        return yol, ""
    with open(yol, encoding="utf-8", errors="replace") as f:
        metin = f.read()
    return yol, metin[-son:]


def hata_kaydini_temizle(program_klasoru):
    yol = os.path.join(program_klasoru, "hata_kaydi.txt")
    if os.path.exists(yol):
        shutil.move(yol, yol + ".eski")


def mudahale_yedekleri(db):
    kl = os.path.join(db.klasor, YEDEK_KLASORU)
    return kl, sorted(glob.glob(os.path.join(kl, "oncesi_*.db")), reverse=True)
