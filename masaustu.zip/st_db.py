# -*- coding: utf-8 -*-
"""Sipariş ve Gemi Takip - veri katmanı (SQLite).

Veritabanı dosyası bir ağ / ortak klasöre konursa ekip aynı veriyi kullanır.
İleride bulut (Supabase) bağlantısı bu katmanın yerine geçecek şekilde tasarlandı.
"""
import os
import shutil
import sqlite3
import hashlib
import secrets
import datetime as dt

from st_tanim import ASAMA, SEVIYE, gemi_anahtar

SEMA = """
CREATE TABLE IF NOT EXISTS kullanicilar (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    kadi TEXT UNIQUE NOT NULL,
    ad TEXT NOT NULL,
    sifre_hash TEXT NOT NULL,
    tuz TEXT NOT NULL,
    rol TEXT NOT NULL,
    departman TEXT NOT NULL,
    aktif INTEGER NOT NULL DEFAULT 1,
    olusturma TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS siparisler (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    no TEXT UNIQUE NOT NULL,
    olusturan_id INTEGER,
    olusturma TEXT NOT NULL,
    iptal INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS asama_durum (
    siparis_id INTEGER NOT NULL,
    asama INTEGER NOT NULL,
    durum TEXT NOT NULL,
    guncelleyen_id INTEGER,
    zaman TEXT,
    PRIMARY KEY (siparis_id, asama)
);
CREATE TABLE IF NOT EXISTS asama_veri (
    siparis_id INTEGER NOT NULL,
    asama INTEGER NOT NULL,
    alan TEXT NOT NULL,
    deger TEXT,
    giren_id INTEGER,
    giren_seviye INTEGER NOT NULL DEFAULT 1,
    zaman TEXT,
    PRIMARY KEY (siparis_id, asama, alan)
);
CREATE TABLE IF NOT EXISTS satirlar (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    siparis_id INTEGER NOT NULL,
    malzeme TEXT, kod TEXT, miktar TEXT, birim TEXT, tedarikci TEXT, termin TEXT,
    toplama TEXT DEFAULT 'Bekliyor', toplanan TEXT, satir_notu TEXT,
    silindi INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS ekler (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    siparis_id INTEGER NOT NULL,
    asama INTEGER NOT NULL,
    dosya_adi TEXT NOT NULL,
    goreli_yol TEXT NOT NULL,
    ekleyen_id INTEGER,
    ekleyen_seviye INTEGER NOT NULL DEFAULT 1,
    zaman TEXT,
    silindi INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS denetim (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    siparis_id INTEGER,
    gemi_id INTEGER,
    asama INTEGER,
    alan TEXT,
    eski TEXT,
    yeni TEXT,
    aciklama TEXT,
    kullanici_id INTEGER,
    seviye INTEGER NOT NULL DEFAULT 1,
    zaman TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS gemiler (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    anahtar TEXT UNIQUE NOT NULL,
    ad TEXT NOT NULL,
    imo TEXT,
    bolge TEXT, op_durum TEXT, ikmal TEXT, hareket TEXT,
    bogaz TEXT, sorumlu TEXT, notlar TEXT,
    olusturma TEXT
);
CREATE TABLE IF NOT EXISTS etalar (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    gemi_id INTEGER NOT NULL,
    eta TEXT NOT NULL,
    liman TEXT,
    bildiren TEXT,
    notu TEXT,
    giren_id INTEGER,
    giren_seviye INTEGER NOT NULL DEFAULT 1,
    alinma TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS meta (
    anahtar TEXT PRIMARY KEY,
    deger TEXT
);
CREATE TABLE IF NOT EXISTS okundu (
    kullanici_id INTEGER NOT NULL,
    anahtar TEXT NOT NULL,
    zaman TEXT,
    PRIMARY KEY (kullanici_id, anahtar)
);
"""


def simdi():
    return dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def sifre_ozet(sifre, tuz):
    return hashlib.pbkdf2_hmac("sha256", sifre.encode("utf-8"), bytes.fromhex(tuz), 200000).hex()


class VeriTabani:
    def __init__(self, klasor):
        self.klasor = klasor
        os.makedirs(klasor, exist_ok=True)
        self.ek_klasoru = os.path.join(klasor, "ekler")
        os.makedirs(self.ek_klasoru, exist_ok=True)
        self.yol = os.path.join(klasor, "siparis_takip.db")
        self.c = sqlite3.connect(self.yol, timeout=20)
        self.c.row_factory = sqlite3.Row
        self.c.execute("PRAGMA foreign_keys=ON")
        self.c.executescript(SEMA)
        self._guncelle_sema()
        self.c.commit()

    def _guncelle_sema(self):
        """Eski veritabanlarına yeni sütunları ekler (veri kaybı olmadan)."""
        var = {r["name"] for r in self.c.execute("PRAGMA table_info(siparisler)")}
        for sutun, tip in (("silindi", "INTEGER NOT NULL DEFAULT 0"), ("silen_id", "INTEGER"), ("silinme", "TEXT"),
                           ("silme_nedeni", "TEXT"), ("gemi_id", "INTEGER")):
            if sutun not in var:
                self.c.execute("ALTER TABLE siparisler ADD COLUMN %s %s" % (sutun, tip))

    def kapat(self):
        try:
            self.c.close()
        except Exception:
            pass

    # ------------------------------------------------------------ kullanıcılar
    def kullanici_sayisi(self):
        return self.c.execute("SELECT COUNT(*) FROM kullanicilar").fetchone()[0]

    def kullanici_ekle(self, kadi, ad, sifre, rol, departman):
        tuz = secrets.token_hex(16)
        cur = self.c.execute(
            "INSERT INTO kullanicilar (kadi, ad, sifre_hash, tuz, rol, departman, olusturma) VALUES (?,?,?,?,?,?,?)",
            (kadi.strip(), ad.strip(), sifre_ozet(sifre, tuz), tuz, rol, departman, simdi()))
        self.c.commit()
        return cur.lastrowid

    def giris(self, kadi, sifre):
        r = self.c.execute("SELECT * FROM kullanicilar WHERE kadi=?", (kadi.strip(),)).fetchone()
        if not r or not r["aktif"]:
            return None
        if sifre_ozet(sifre, r["tuz"]) != r["sifre_hash"]:
            return None
        return dict(r)

    def kullanicilar(self):
        return [dict(r) for r in self.c.execute("SELECT * FROM kullanicilar ORDER BY aktif DESC, ad")]

    def kullanici(self, kid):
        r = self.c.execute("SELECT * FROM kullanicilar WHERE id=?", (kid,)).fetchone()
        return dict(r) if r else None

    def kullanici_guncelle(self, kid, ad, rol, departman, aktif):
        self.c.execute("UPDATE kullanicilar SET ad=?, rol=?, departman=?, aktif=? WHERE id=?",
                       (ad, rol, departman, 1 if aktif else 0, kid))
        self.c.commit()

    def sifre_degistir(self, kid, sifre):
        tuz = secrets.token_hex(16)
        self.c.execute("UPDATE kullanicilar SET sifre_hash=?, tuz=? WHERE id=?", (sifre_ozet(sifre, tuz), tuz, kid))
        self.c.commit()

    def kullanici_adlari(self):
        return {r["id"]: r["ad"] for r in self.c.execute("SELECT id, ad FROM kullanicilar")}

    # ------------------------------------------------------------ denetim
    def _denetim(self, kullanici, aciklama, siparis_id=None, gemi_id=None, asama=None, alan=None, eski=None, yeni=None):
        self.c.execute(
            "INSERT INTO denetim (siparis_id, gemi_id, asama, alan, eski, yeni, aciklama, kullanici_id, seviye, zaman) "
            "VALUES (?,?,?,?,?,?,?,?,?,?)",
            (siparis_id, gemi_id, asama, alan, eski, yeni, aciklama,
             kullanici["id"] if kullanici else None, SEVIYE.get(kullanici["rol"], 1) if kullanici else 1, simdi()))

    def denetim(self, siparis_id=None, gemi_id=None, limit=300):
        if siparis_id is not None:
            q = self.c.execute("SELECT * FROM denetim WHERE siparis_id=? ORDER BY id DESC LIMIT ?", (siparis_id, limit))
        elif gemi_id is not None:
            q = self.c.execute("SELECT * FROM denetim WHERE gemi_id=? ORDER BY id DESC LIMIT ?", (gemi_id, limit))
        else:
            q = self.c.execute("SELECT * FROM denetim ORDER BY id DESC LIMIT ?", (limit,))
        return [dict(r) for r in q]

    # ------------------------------------------------------------ siparişler
    def yeni_siparis_no(self):
        yil = dt.date.today().year
        on = "SP-%d-" % yil
        r = self.c.execute("SELECT no FROM siparisler WHERE no LIKE ? ORDER BY no DESC LIMIT 1", (on + "%",)).fetchone()
        sira = int(r["no"].split("-")[-1]) + 1 if r else 1
        return "%s%04d" % (on, sira)

    def siparis_olustur(self, kullanici):
        no = self.yeni_siparis_no()
        cur = self.c.execute("INSERT INTO siparisler (no, olusturan_id, olusturma) VALUES (?,?,?)",
                             (no, kullanici["id"], simdi()))
        sid = cur.lastrowid
        for n in range(1, 7):
            self.c.execute("INSERT INTO asama_durum (siparis_id, asama, durum, guncelleyen_id, zaman) VALUES (?,?,?,?,?)",
                           (sid, n, "na" if n == 6 else "todo", kullanici["id"], simdi()))
        self._denetim(kullanici, "Sipariş oluşturuldu (%s)" % no, siparis_id=sid, asama=1)
        self.c.commit()
        return sid

    def siparis(self, sid):
        r = self.c.execute("SELECT * FROM siparisler WHERE id=?", (sid,)).fetchone()
        return dict(r) if r else None

    def siparis_sil(self, sid, kullanici, neden):
        self.c.execute("UPDATE siparisler SET silindi=1, silen_id=?, silinme=?, silme_nedeni=? WHERE id=?",
                       (kullanici["id"], simdi(), neden, sid))
        self._denetim(kullanici, "Sipariş silindi" + (" – neden: %s" % neden if neden else ""), siparis_id=sid)
        self.c.commit()

    def siparis_geri_al(self, sid, kullanici):
        self.c.execute("UPDATE siparisler SET silindi=0 WHERE id=?", (sid,))
        self._denetim(kullanici, "Silinen sipariş geri alındı", siparis_id=sid)
        self.c.commit()

    def siparis_gemiye_bagla(self, sid, gid):
        self.c.execute("UPDATE siparisler SET gemi_id=? WHERE id=?", (gid, sid))
        self.c.commit()

    def siparis_listesi(self, silinenler=False):
        """Her sipariş: temel bilgiler + durumlar + aşama verisi. silinenler=True ise yalnızca silinenler."""
        sip = [dict(r) for r in self.c.execute(
            "SELECT s.*, g.ad AS gemi_ad, g.imo AS gemi_imo FROM siparisler s LEFT JOIN gemiler g ON g.id = s.gemi_id "
            "WHERE s.silindi=? ORDER BY s.id DESC", (1 if silinenler else 0,))]
        durum = {}
        for r in self.c.execute("SELECT siparis_id, asama, durum, zaman FROM asama_durum"):
            durum.setdefault(r["siparis_id"], {})[r["asama"]] = r["durum"]
        veri = {}
        for r in self.c.execute("SELECT siparis_id, asama, alan, deger, giren_seviye, zaman FROM asama_veri"):
            veri.setdefault(r["siparis_id"], {}).setdefault(r["asama"], {})[r["alan"]] = (r["deger"], r["giren_seviye"])
        son = {}
        for r in self.c.execute("SELECT siparis_id, MAX(zaman) z FROM denetim WHERE siparis_id IS NOT NULL GROUP BY siparis_id"):
            son[r["siparis_id"]] = r["z"]
        for s in sip:
            s["durum"] = durum.get(s["id"], {})
            s["veri"] = veri.get(s["id"], {})
            s["son_islem"] = son.get(s["id"], s["olusturma"])
        return sip

    def durumlar(self, sid):
        return {r["asama"]: r["durum"] for r in
                self.c.execute("SELECT asama, durum FROM asama_durum WHERE siparis_id=?", (sid,))}

    def durum_ayarla(self, sid, asama, durum, kullanici, aciklama=None):
        eski = self.durumlar(sid).get(asama)
        if eski == durum:
            return
        self.c.execute("UPDATE asama_durum SET durum=?, guncelleyen_id=?, zaman=? WHERE siparis_id=? AND asama=?",
                       (durum, kullanici["id"], simdi(), sid, asama))
        from st_tanim import DURUM
        self._denetim(kullanici, aciklama or "Aşama %d durumu: %s → %s" % (asama, DURUM.get(eski, eski), DURUM.get(durum, durum)),
                      siparis_id=sid, asama=asama, alan="durum", eski=eski, yeni=durum)
        self.c.commit()

    def iptal_et(self, sid, kullanici):
        self.c.execute("UPDATE siparisler SET iptal=1 WHERE id=?", (sid,))
        self._denetim(kullanici, "Sipariş iptal edildi", siparis_id=sid, asama=6)
        self.c.commit()

    def alan_degerleri(self, sid, asama):
        return {r["alan"]: dict(r) for r in
                self.c.execute("SELECT * FROM asama_veri WHERE siparis_id=? AND asama=?", (sid, asama))}

    def alanlari_kaydet(self, sid, asama, degerler, kullanici):
        """degerler: {alan: yeni_deger}. Değişenleri kaydeder ve denetime yazar. Değişen alan sayısını döner."""
        mevcut = self.alan_degerleri(sid, asama)
        seviye = SEVIYE.get(kullanici["rol"], 1)
        degisen = 0
        tanim = {a[0]: a[1] for a in ASAMA[asama]["alanlar"]}
        for alan, yeni in degerler.items():
            yeni = (yeni or "").strip()
            if asama == 1 and alan == "gemi":
                yeni = gemi_anahtar(yeni)  # gemi adı hep büyük harf
            eski = (mevcut.get(alan) or {}).get("deger") or ""
            if yeni == eski:
                continue
            degisen += 1
            self.c.execute(
                "INSERT INTO asama_veri (siparis_id, asama, alan, deger, giren_id, giren_seviye, zaman) VALUES (?,?,?,?,?,?,?) "
                "ON CONFLICT(siparis_id, asama, alan) DO UPDATE SET deger=excluded.deger, giren_id=excluded.giren_id, "
                "giren_seviye=excluded.giren_seviye, zaman=excluded.zaman",
                (sid, asama, alan, yeni, kullanici["id"], seviye, simdi()))
            self._denetim(kullanici, "%s değişti" % tanim.get(alan, alan), siparis_id=sid, asama=asama,
                          alan=alan, eski=eski, yeni=yeni)
        self.c.commit()
        return degisen

    # ------------------------------------------------------------ malzeme satırları
    def satirlar(self, sid):
        return [dict(r) for r in self.c.execute("SELECT * FROM satirlar WHERE siparis_id=? AND silindi=0 ORDER BY id", (sid,))]

    def satir_ekle(self, sid, kullanici, **v):
        cur = self.c.execute(
            "INSERT INTO satirlar (siparis_id, malzeme, kod, miktar, birim, tedarikci, termin) VALUES (?,?,?,?,?,?,?)",
            (sid, v.get("malzeme"), v.get("kod"), v.get("miktar"), v.get("birim"), v.get("tedarikci"), v.get("termin")))
        self._denetim(kullanici, "Malzeme satırı eklendi: %s" % v.get("malzeme"), siparis_id=sid, asama=1)
        self.c.commit()
        return cur.lastrowid

    def satir_guncelle(self, satir_id, kullanici, asama, **v):
        r = self.c.execute("SELECT * FROM satirlar WHERE id=?", (satir_id,)).fetchone()
        if not r:
            return
        for k, yeni in v.items():
            eski = r[k] or ""
            if (yeni or "") != eski:
                self.c.execute("UPDATE satirlar SET %s=? WHERE id=?" % k, (yeni, satir_id))
                self._denetim(kullanici, "%s · %s değişti" % (r["malzeme"], k), siparis_id=r["siparis_id"],
                              asama=asama, alan=k, eski=eski, yeni=yeni)
        self.c.commit()

    def satir_sil(self, satir_id, kullanici):
        r = self.c.execute("SELECT * FROM satirlar WHERE id=?", (satir_id,)).fetchone()
        if not r:
            return
        self.c.execute("UPDATE satirlar SET silindi=1 WHERE id=?", (satir_id,))
        self._denetim(kullanici, "Malzeme satırı kaldırıldı: %s" % r["malzeme"], siparis_id=r["siparis_id"], asama=1)
        self.c.commit()

    # ------------------------------------------------------------ ekler
    def ekler(self, sid, asama=None):
        if asama is None:
            q = self.c.execute("SELECT * FROM ekler WHERE siparis_id=? AND silindi=0 ORDER BY id", (sid,))
        else:
            q = self.c.execute("SELECT * FROM ekler WHERE siparis_id=? AND asama=? AND silindi=0 ORDER BY id", (sid, asama))
        return [dict(r) for r in q]

    def ek_ekle(self, sid, asama, kaynak, kullanici):
        s = self.siparis(sid)
        hedef_kl = os.path.join(self.ek_klasoru, s["no"])
        os.makedirs(hedef_kl, exist_ok=True)
        ad = os.path.basename(kaynak)
        govde, uzanti = os.path.splitext(ad)
        hedef = os.path.join(hedef_kl, ad)
        i = 2
        while os.path.exists(hedef):
            hedef = os.path.join(hedef_kl, "%s_%d%s" % (govde, i, uzanti))
            i += 1
        shutil.copy2(kaynak, hedef)
        goreli = os.path.relpath(hedef, self.klasor)
        self.c.execute(
            "INSERT INTO ekler (siparis_id, asama, dosya_adi, goreli_yol, ekleyen_id, ekleyen_seviye, zaman) VALUES (?,?,?,?,?,?,?)",
            (sid, asama, os.path.basename(hedef), goreli, kullanici["id"], SEVIYE.get(kullanici["rol"], 1), simdi()))
        self._denetim(kullanici, "Dosya eklendi: %s" % os.path.basename(hedef), siparis_id=sid, asama=asama)
        self.c.commit()

    def ek_sil(self, ek_id, kullanici):
        r = self.c.execute("SELECT * FROM ekler WHERE id=?", (ek_id,)).fetchone()
        if not r:
            return
        self.c.execute("UPDATE ekler SET silindi=1 WHERE id=?", (ek_id,))
        self._denetim(kullanici, "Dosya kaldırıldı: %s" % r["dosya_adi"], siparis_id=r["siparis_id"], asama=r["asama"])
        self.c.commit()

    def ek_tam_yol(self, ek):
        return os.path.join(self.klasor, ek["goreli_yol"])

    # ------------------------------------------------------------ gemiler
    def gemi_bul_veya_olustur(self, ad, imo, kullanici, siparis_id=None, kaynak_ad=None):
        """Siparişteki gemi adı / IMO'ya göre gemi kaydını bulur, yoksa oluşturur.
        IMO varsa önce IMO ile aranır; siparişteki IMO esas alınır (gemi kaydı ona göre güncellenir)."""
        ad = gemi_anahtar(ad)
        imo = (imo or "").strip()
        if not ad and not imo:
            return None
        r = None
        if imo:
            r = self.c.execute("SELECT * FROM gemiler WHERE imo=? ORDER BY id LIMIT 1", (imo,)).fetchone()
        if r is None and ad:
            r = self.c.execute("SELECT * FROM gemiler WHERE anahtar=?", (ad,)).fetchone()
            if r is not None and imo and r["imo"] and r["imo"] != imo:
                # aynı adlı ama başka IMO'lu gemi kaydı var: bu sipariş başka gemi olabilir
                bagli = self.c.execute("SELECT COUNT(*) FROM siparisler WHERE gemi_id=? AND silindi=0 AND id<>?",
                                       (r["id"], siparis_id or -1)).fetchone()[0]
                if bagli:
                    r = None
        if r is not None:
            gid = r["id"]
            if imo and r["imo"] != imo:
                self.c.execute("UPDATE gemiler SET imo=? WHERE id=?", (imo, gid))
                self._denetim(kullanici, "IMO siparişe göre güncellendi", gemi_id=gid, siparis_id=siparis_id,
                              alan="imo", eski=r["imo"] or "", yeni=imo)
            yeni_ad = ad or gemi_anahtar(kaynak_ad)
            if yeni_ad and yeni_ad != r["ad"] and r["ad"].startswith("IMO "):
                if not self.c.execute("SELECT 1 FROM gemiler WHERE anahtar=? AND id<>?", (yeni_ad, gid)).fetchone():
                    self.c.execute("UPDATE gemiler SET ad=?, anahtar=? WHERE id=?", (yeni_ad, yeni_ad, gid))
                    self._denetim(kullanici, "Gemi adı güncellendi", gemi_id=gid, alan="ad", eski=r["ad"], yeni=yeni_ad)
            self.c.commit()
            return gid
        yeni_ad = ad or gemi_anahtar(kaynak_ad) or ("IMO " + imo)
        anahtar = yeni_ad
        if self.c.execute("SELECT 1 FROM gemiler WHERE anahtar=?", (anahtar,)).fetchone():
            anahtar = "%s (IMO %s)" % (yeni_ad, imo)
        cur = self.c.execute(
            "INSERT INTO gemiler (anahtar, ad, imo, bolge, op_durum, ikmal, hareket, olusturma) VALUES (?,?,?,?,?,?,?,?)",
            (anahtar, yeni_ad, imo, "Belirsiz", "Teknik malzeme", "", "Bilinmiyor", simdi()))
        gid = cur.lastrowid
        self._denetim(kullanici, "Gemi takibe alındı (sipariş açıldı)", gemi_id=gid, siparis_id=siparis_id)
        self.c.commit()
        return gid

    def gemiler(self):
        return [dict(r) for r in self.c.execute("SELECT * FROM gemiler ORDER BY ad")]

    def gemi(self, gid):
        r = self.c.execute("SELECT * FROM gemiler WHERE id=?", (gid,)).fetchone()
        return dict(r) if r else None

    def gemi_guncelle(self, gid, degerler, kullanici):
        r = self.gemi(gid)
        etiket = {"imo": "IMO", "bolge": "Bölge", "op_durum": "Operasyon durumu", "ikmal": "İkmal noktası",
                  "hareket": "Gemi hareketi", "bogaz": "Boğaz / Kıyı Emniyeti bilgisi", "sorumlu": "Sorumlu personel",
                  "notlar": "Notlar"}
        for k, yeni in degerler.items():
            yeni = (yeni or "").strip()
            eski = r.get(k) or ""
            if yeni != eski:
                self.c.execute("UPDATE gemiler SET %s=? WHERE id=?" % k, (yeni, gid))
                self._denetim(kullanici, "%s değişti" % etiket.get(k, k), gemi_id=gid, alan=k, eski=eski, yeni=yeni)
        self.c.commit()

    def etalar(self, gid):
        return [dict(r) for r in self.c.execute("SELECT * FROM etalar WHERE gemi_id=? ORDER BY id DESC", (gid,))]

    def tum_etalar(self):
        d = {}
        for r in self.c.execute("SELECT * FROM etalar ORDER BY id DESC"):
            d.setdefault(r["gemi_id"], []).append(dict(r))
        return d

    def eta_ekle(self, gid, eta, liman, bildiren, notu, kullanici):
        self.c.execute(
            "INSERT INTO etalar (gemi_id, eta, liman, bildiren, notu, giren_id, giren_seviye, alinma) VALUES (?,?,?,?,?,?,?,?)",
            (gid, eta, liman, bildiren, notu, kullanici["id"], SEVIYE.get(kullanici["rol"], 1), simdi()))
        self._denetim(kullanici, "Acente ETA girildi: %s" % eta, gemi_id=gid, alan="eta", yeni=eta)
        self.c.commit()

    # ------------------------------------------------------------ ortak ayarlar (tüm bilgisayarlar)
    def meta_al(self, anahtar, varsayilan=""):
        r = self.c.execute("SELECT deger FROM meta WHERE anahtar=?", (anahtar,)).fetchone()
        return r["deger"] if r and r["deger"] is not None else varsayilan

    def meta_yaz(self, anahtar, deger):
        self.c.execute("INSERT INTO meta (anahtar, deger) VALUES (?,?) ON CONFLICT(anahtar) DO UPDATE SET deger=excluded.deger",
                       (anahtar, deger))
        self.c.commit()

    # ------------------------------------------------------------ okundu
    def okunanlar(self, kid):
        return {r["anahtar"] for r in self.c.execute("SELECT anahtar FROM okundu WHERE kullanici_id=?", (kid,))}

    def okundu_isaretle(self, kid, anahtar):
        self.c.execute("INSERT OR IGNORE INTO okundu (kullanici_id, anahtar, zaman) VALUES (?,?,?)", (kid, anahtar, simdi()))
        self.c.commit()
