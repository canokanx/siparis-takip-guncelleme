# -*- coding: utf-8 -*-
"""Sipariş ve Gemi Takip - veri katmanı (SQLite).

Veritabanı dosyası bir ağ / ortak klasöre konursa ekip aynı veriyi kullanır.
İleride bulut (Supabase) bağlantısı bu katmanın yerine geçecek şekilde tasarlandı.
"""
import os
import shutil
import sqlite3
import hashlib
import secrets
import datetime as dt
import contextlib

from st_tanim import ASAMA, SEVIYE, SIRA_IDLER, IADE, asama_no, gemi_anahtar


class CakismaHatasi(Exception):
    """Kullanıcı formu açtıktan sonra başka biri aynı alanları değiştirdi. cakismalar: [dict]"""

    def __init__(self, cakismalar):
        Exception.__init__(self, "Başka bir kullanıcı aynı alanları değiştirdi.")
        self.cakismalar = cakismalar


class SiparisSilindiHatasi(Exception):
    pass


class KullaniciHatasi(Exception):
    pass

SEMA = """
CREATE TABLE IF NOT EXISTS kullanicilar (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    kadi TEXT UNIQUE NOT NULL,
    ad TEXT NOT NULL,
    sifre_hash TEXT NOT NULL,
    tuz TEXT NOT NULL,
    rol TEXT NOT NULL,
    departman TEXT NOT NULL,
    aktif INTEGER NOT NULL DEFAULT 1,
    olusturma TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS siparisler (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    no TEXT UNIQUE NOT NULL,
    olusturan_id INTEGER,
    olusturma TEXT NOT NULL,
    iptal INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS asama_durum (
    siparis_id INTEGER NOT NULL,
    asama INTEGER NOT NULL,
    durum TEXT NOT NULL,
    guncelleyen_id INTEGER,
    zaman TEXT,
    PRIMARY KEY (siparis_id, asama)
);
CREATE TABLE IF NOT EXISTS asama_veri (
    siparis_id INTEGER NOT NULL,
    asama INTEGER NOT NULL,
    alan TEXT NOT NULL,
    deger TEXT,
    giren_id INTEGER,
    giren_seviye INTEGER NOT NULL DEFAULT 1,
    zaman TEXT,
    PRIMARY KEY (siparis_id, asama, alan)
);
CREATE TABLE IF NOT EXISTS satirlar (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    siparis_id INTEGER NOT NULL,
    malzeme TEXT, kod TEXT, miktar TEXT, birim TEXT, tedarikci TEXT, termin TEXT,
    toplama TEXT DEFAULT 'Bekliyor', toplanan TEXT, satir_notu TEXT,
    silindi INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS ekler (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    siparis_id INTEGER NOT NULL,
    asama INTEGER NOT NULL,
    dosya_adi TEXT NOT NULL,
    goreli_yol TEXT NOT NULL,
    ekleyen_id INTEGER,
    ekleyen_seviye INTEGER NOT NULL DEFAULT 1,
    zaman TEXT,
    silindi INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS denetim (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    siparis_id INTEGER,
    gemi_id INTEGER,
    asama INTEGER,
    alan TEXT,
    eski TEXT,
    yeni TEXT,
    aciklama TEXT,
    kullanici_id INTEGER,
    seviye INTEGER NOT NULL DEFAULT 1,
    zaman TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS gemiler (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    anahtar TEXT UNIQUE NOT NULL,
    ad TEXT NOT NULL,
    imo TEXT,
    bolge TEXT, op_durum TEXT, ikmal TEXT, hareket TEXT,
    bogaz TEXT, sorumlu TEXT, notlar TEXT,
    olusturma TEXT
);
CREATE TABLE IF NOT EXISTS etalar (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    gemi_id INTEGER NOT NULL,
    eta TEXT NOT NULL,
    liman TEXT,
    bildiren TEXT,
    notu TEXT,
    giren_id INTEGER,
    giren_seviye INTEGER NOT NULL DEFAULT 1,
    alinma TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS meta (
    anahtar TEXT PRIMARY KEY,
    deger TEXT
);
CREATE TABLE IF NOT EXISTS okundu (
    kullanici_id INTEGER NOT NULL,
    anahtar TEXT NOT NULL,
    zaman TEXT,
    PRIMARY KEY (kullanici_id, anahtar)
);
"""


def simdi():
    """Kayıt saati. Bulutta bilgisayar saati sunucu saatine göre düzeltilir (saati yanlış bilgisayar sırayı bozmasın)."""
    fark = 0.0
    try:
        from st_bulut import SAAT_FARKI
        fark = SAAT_FARKI[0]
    except Exception:
        pass
    return (dt.datetime.now() + dt.timedelta(seconds=fark)).strftime("%Y-%m-%d %H:%M:%S")


FOTO_UZANTILARI = (".jpg", ".jpeg", ".png", ".bmp", ".webp", ".tif", ".tiff", ".heic")
FOTO_KENAR = 1600


def _pil():
    try:
        from PIL import Image  # noqa
        return Image
    except ImportError:
        pass
    try:  # yoksa bir kez kurmayı dene (kurulum .exe'si zaten kurar)
        import subprocess
        import sys
        exe = sys.executable
        if exe.lower().endswith("pythonw.exe"):
            exe = exe[:-len("pythonw.exe")] + "python.exe"
        subprocess.run([exe, "-m", "pip", "install", "--disable-pip-version-check", "pillow"], capture_output=True,
                       timeout=180, creationflags=0x08000000 if sys.platform.startswith("win") else 0)
        import importlib
        importlib.invalidate_caches()
        from PIL import Image  # noqa: F811
        return Image
    except Exception:
        return None


def fotograf_kucult(yol):
    """(bayt, dosya_adı). Fotoğrafsa en uzun kenarı 1600 piksel JPEG yapılır (genelde 200–400 KB);
    zaten küçükse ya da fotoğraf değilse dosya olduğu gibi döner."""
    ad = os.path.basename(yol)
    with open(yol, "rb") as f:
        veri = f.read()
    if not ad.lower().endswith(FOTO_UZANTILARI) or len(veri) < 500 * 1024:
        return veri, ad
    Image = _pil()
    if Image is None:
        return veri, ad
    try:
        import io
        from PIL import ImageOps
        im = Image.open(io.BytesIO(veri))
        im = ImageOps.exif_transpose(im)  # telefon fotoğrafı yan dönmesin
        if im.mode not in ("RGB", "L"):
            im = im.convert("RGB")
        im.thumbnail((FOTO_KENAR, FOTO_KENAR))
        cikti = io.BytesIO()
        im.save(cikti, "JPEG", quality=82, optimize=True)
        yeni = cikti.getvalue()
        if len(yeni) >= len(veri):
            return veri, ad
        return yeni, os.path.splitext(ad)[0] + ".jpg"
    except Exception:
        return veri, ad


def sifre_yeterli_mi(sifre):
    """Yeni şifre kuralı: en az 6 karakter. (Eski kısa şifreler girişte çalışmaya devam eder.)"""
    return len(sifre or "") >= 6


def sifre_ozet(sifre, tuz):
    return hashlib.pbkdf2_hmac("sha256", sifre.encode("utf-8"), bytes.fromhex(tuz), 200000).hex()


class VeriTabani:
    """klasor: yerel veri klasörü (SQLite). bulut verilirse ({host, port, user, password, database}) veriler
    bulut veritabanında (Supabase/PostgreSQL) tutulur; klasör yalnızca ek dosyaların önbelleği olur."""

    def __init__(self, klasor, bulut=None, ayna=True):
        self.klasor = klasor
        self.bulut = bulut
        os.makedirs(klasor, exist_ok=True)
        self.yol = os.path.join(klasor, "siparis_takip.db")
        if bulut:
            from st_bulut import Baglanti, sema_kur, _ayna_bagla
            self.c = Baglanti(bulut, zaman_asimi=bulut.get("zaman_asimi"))
            sema_kur(self.c)
            self.asama_duzeni_gecisi()
            if ayna:
                _ayna_bagla(self.c, klasor)
            self.ek_klasoru = os.path.join(klasor, "ek_onbellek")
            os.makedirs(self.ek_klasoru, exist_ok=True)
            return
        self.ek_klasoru = os.path.join(klasor, "ekler")
        os.makedirs(self.ek_klasoru, exist_ok=True)
        self.c = sqlite3.connect(self.yol, timeout=20)
        self.c.row_factory = sqlite3.Row
        self.c.execute("PRAGMA foreign_keys=ON")
        self.c.executescript(SEMA)
        self._guncelle_sema()
        self.c.commit()
        self.asama_duzeni_gecisi()

    def asama_duzeni_gecisi(self):
        """1.9.0 aşama düzeni (her açılışta, zararsız tekrar edilir – eski sürümlerin yazdıklarını da toparlar):
        eski 'Sevkiyat & Tahsilat' (5) içindeki tahsilat alanları yeni 'Tahsilat' (8) aşamasına taşınır;
        her siparişe 'Depoya Sevkiyat' (7) ve 'Tahsilat' (8) durum kaydı eklenir. Tahsilat durumu eski 5'ten alınır;
        depo işi başlamış eski siparişlerde Depoya Sevkiyat 'Pasif' olur."""
        from st_tanim import TAHSILAT_ALANLARI
        komutlar = [
            ("UPDATE asama_veri SET asama=8 WHERE asama=5 AND alan IN (%s) AND NOT EXISTS (SELECT 1 FROM asama_veri x "
             "WHERE x.siparis_id=asama_veri.siparis_id AND x.asama=8 AND x.alan=asama_veri.alan)"
             % ",".join("?" * len(TAHSILAT_ALANLARI)), TAHSILAT_ALANLARI),
            ("INSERT INTO asama_durum (siparis_id, asama, durum, guncelleyen_id, zaman) SELECT d.siparis_id, 8, d.durum, "
             "d.guncelleyen_id, d.zaman FROM asama_durum d WHERE d.asama=5 AND NOT EXISTS (SELECT 1 FROM asama_durum x "
             "WHERE x.siparis_id=d.siparis_id AND x.asama=8)", ()),
            ("INSERT INTO asama_durum (siparis_id, asama, durum, guncelleyen_id, zaman) SELECT d.siparis_id, 7, "
             "CASE WHEN d.durum='todo' THEN 'todo' ELSE 'na' END, d.guncelleyen_id, d.zaman FROM asama_durum d "
             "WHERE d.asama=2 AND NOT EXISTS (SELECT 1 FROM asama_durum x WHERE x.siparis_id=d.siparis_id AND x.asama=7)", ()),
        ]
        for sql, p in komutlar:
            try:
                self.c.execute(sql, p)
                self.c.commit()
            except Exception:
                try:
                    if not self.bulut:
                        self.c.rollback()
                except Exception:
                    pass

    # ------------------------------------------------------------ işlem / okuma yardımcıları
    @contextlib.contextmanager
    def islem(self):
        """İçindeki yazmaların hepsi ya da hiçbiri kaydedilir (bağlantı yarıda koparsa yarım kayıt kalmaz)."""
        if self.bulut:
            self.c.islem_baslat()
            basarili = False
            try:
                yield
                basarili = True
            finally:
                self.c.islem_bitir(basarili)
        else:
            try:
                yield
                self.c.commit()
            except Exception:
                self.c.rollback()
                raise

    def _taze(self, sql, params=()):
        """Önbelleğe bakmadan okur (kayıt öncesi kontroller – başka bilgisayarın son değişikliği görülsün)."""
        if self.bulut:
            return self.c.taze(sql, params)
        return self.c.execute(sql, params)

    def _ayna(self):
        a = self.c.ayna
        if a is None:
            from st_bulut import _ayna_bagla
            a = _ayna_bagla(self.c, None)  # dosyasız (geçici bağlantılar için)
        a.hazirla(self.c)
        return a

    @property
    def cevrimici(self):
        return getattr(self.c, "cevrimici", True)

    def siparis_kontrol(self, sid, kullanici=None):
        """Kayıttan önce (tek sorgu): sipariş başka bilgisayarda silindi mi, kullanıcının hesabı pasif yapıldı mı?"""
        kid = kullanici["id"] if kullanici else -1
        r = self._taze("SELECT s.silindi, (SELECT aktif FROM kullanicilar WHERE id=?) FROM siparisler s WHERE s.id=?",
                       (kid, sid)).fetchone()
        if r is None or r[0]:
            raise SiparisSilindiHatasi("Bu sipariş başka bir kullanıcı tarafından silindi. Değişiklik kaydedilmedi.")
        if kullanici and not r[1]:
            raise KullaniciHatasi("Hesabınız pasif yapıldı. Değişiklik kaydedilmedi.")

    @property
    def konum_metni(self):
        if self.bulut:
            return "Bulut veritabanı (%s)" % self.bulut.get("host", "")
        return self.klasor

    # ------------------------------------------------------------ yedek / aktarım
    def sqlite_kopyasi(self, hedef_yol):
        """Verilerin tamamını tek bir SQLite dosyasına yazar (yedek için; bulutta da çalışır)."""
        if os.path.exists(hedef_yol):
            os.remove(hedef_yol)
        if not self.bulut:
            hedef = sqlite3.connect(hedef_yol)
            self.c.backup(hedef)
            hedef.close()
            return
        import tempfile
        from st_bulut import tablolari_kopyala
        tmp = tempfile.mkdtemp(prefix="st_kopya_")
        gecici = VeriTabani(tmp)  # boş SQLite şeması
        gecici.c.close()
        shutil.move(gecici.yol, hedef_yol)
        shutil.rmtree(tmp, ignore_errors=True)
        h = sqlite3.connect(hedef_yol)
        h.row_factory = sqlite3.Row
        tablolari_kopyala(self.c, h, log=lambda m: None)
        h.commit()
        h.close()

    def ek_listesi(self):
        """[{id, goreli_yol, dosya_adi}] – yedekte ekler ayrı ayrı (yalnızca yeni olanlar) yüklenir."""
        return [dict(r) for r in self._taze("SELECT id, goreli_yol, dosya_adi FROM ekler ORDER BY id")]

    def ek_baytlari(self, ek):
        if self.bulut:
            r = self._taze("SELECT veri FROM ek_dosyalar WHERE ek_id=?", (ek["id"],)).fetchone()
            return bytes(r["veri"]) if r and r["veri"] is not None else None
        yol = os.path.join(self.klasor, ek["goreli_yol"])
        if os.path.exists(yol):
            with open(yol, "rb") as f:
                return f.read()
        return None

    def ek_dosyalari(self):
        """[(goreli_yol, bayt)] – yedek paketine konacak ek dosyalar."""
        out = []
        for e in self.c.execute("SELECT id, goreli_yol FROM ekler"):
            if self.bulut:
                r = self.c.execute("SELECT veri FROM ek_dosyalar WHERE ek_id=?", (e["id"],)).fetchone()
                if r and r["veri"] is not None:
                    out.append((e["goreli_yol"], bytes(r["veri"])))
            else:
                yol = os.path.join(self.klasor, e["goreli_yol"])
                if os.path.exists(yol):
                    with open(yol, "rb") as f:
                        out.append((e["goreli_yol"], f.read()))
        return out

    def ice_aktar(self, kaynak_sqlite, ek_kok, log=print):
        """Bir SQLite veritabanındaki (yerel veri ya da yedek) her şeyi bu veritabanına aktarır; buradakiler silinir.
        ek_kok: ek dosyaların bulunduğu kök klasör (goreli_yol buna göre)."""
        from st_bulut import tablolari_kopyala
        k = sqlite3.connect(kaynak_sqlite)
        k.row_factory = sqlite3.Row
        try:
            var = {r["name"] for r in k.execute("PRAGMA table_info(siparisler)")}
            for sutun, tip in (("silindi", "INTEGER NOT NULL DEFAULT 0"), ("silen_id", "INTEGER"), ("silinme", "TEXT"),
                               ("silme_nedeni", "TEXT"), ("gemi_id", "INTEGER")):
                if sutun not in var:
                    k.execute("ALTER TABLE siparisler ADD COLUMN %s %s" % (sutun, tip))
            k.execute("CREATE TABLE IF NOT EXISTS meta (anahtar TEXT PRIMARY KEY, deger TEXT)")
            tablolari_kopyala(k, self.c, log=log)
            ekler = [dict(r) for r in k.execute("SELECT id, goreli_yol FROM ekler")]
        finally:
            k.close()
        if self.bulut:
            self.c.execute("DELETE FROM ek_dosyalar")
        n = 0
        for e in ekler:
            yol = os.path.join(ek_kok, e["goreli_yol"])
            if not os.path.exists(yol):
                continue
            if self.bulut:
                with open(yol, "rb") as f:
                    self.c.execute("INSERT INTO ek_dosyalar (ek_id, veri) VALUES (?, ?)", (e["id"], f.read()))
            else:
                hedef = os.path.join(self.klasor, e["goreli_yol"])
                os.makedirs(os.path.dirname(hedef), exist_ok=True)
                if os.path.abspath(yol) != os.path.abspath(hedef):
                    shutil.copy2(yol, hedef)
            n += 1
        log("   ek dosya: %d" % n)
        self.c.commit()

    def _guncelle_sema(self):  # yalnızca SQLite
        """Eski veritabanlarına yeni sütunları ekler (veri kaybı olmadan)."""
        var = {r["name"] for r in self.c.execute("PRAGMA table_info(siparisler)")}
        for sutun, tip in (("silindi", "INTEGER NOT NULL DEFAULT 0"), ("silen_id", "INTEGER"), ("silinme", "TEXT"),
                           ("silme_nedeni", "TEXT"), ("gemi_id", "INTEGER")):
            if sutun not in var:
                self.c.execute("ALTER TABLE siparisler ADD COLUMN %s %s" % (sutun, tip))

    def kapat(self):
        try:
            self.c.close()
        except Exception:
            pass

    # ------------------------------------------------------------ kullanıcılar
    def kullanici_sayisi(self):
        return self.c.execute("SELECT COUNT(*) FROM kullanicilar").fetchone()[0]

    def kullanici_ekle(self, kadi, ad, sifre, rol, departman):
        tuz = secrets.token_hex(16)
        try:
            cur = self.c.execute(
                "INSERT INTO kullanicilar (kadi, ad, sifre_hash, tuz, rol, departman, olusturma) VALUES (?,?,?,?,?,?,?)",
                (kadi.strip(), ad.strip(), sifre_ozet(sifre, tuz), tuz, rol, departman, simdi()))
        except Exception as e:
            from st_bulut import tekil_ihlali_mi
            if tekil_ihlali_mi(e):
                raise KullaniciHatasi("'%s' kullanıcı adı zaten var." % kadi.strip())
            raise
        self.c.commit()
        return cur.lastrowid

    def kullanici_durumu(self, kid):
        """Açık oturum için: hesap pasif yapıldı mı, rolü / departmanı değişti mi?"""
        r = self.c.execute("SELECT id, ad, rol, departman, aktif FROM kullanicilar WHERE id=?", (kid,)).fetchone()
        return dict(r) if r else None

    def giris(self, kadi, sifre):
        r = self._taze("SELECT * FROM kullanicilar WHERE kadi=?", (kadi.strip(),)).fetchone()
        if not r or not r["aktif"]:
            return None
        if sifre_ozet(sifre, r["tuz"]) != r["sifre_hash"]:
            return None
        return dict(r)

    def kullanicilar(self):
        return [dict(r) for r in self.c.execute("SELECT * FROM kullanicilar ORDER BY aktif DESC, ad")]

    def kullanici(self, kid):
        r = self.c.execute("SELECT * FROM kullanicilar WHERE id=?", (kid,)).fetchone()
        return dict(r) if r else None

    def kullanici_guncelle(self, kid, ad, rol, departman, aktif):
        self.c.execute("UPDATE kullanicilar SET ad=?, rol=?, departman=?, aktif=? WHERE id=?",
                       (ad, rol, departman, 1 if aktif else 0, kid))
        self.c.commit()

    def sifre_degistir(self, kid, sifre):
        tuz = secrets.token_hex(16)
        self.c.execute("UPDATE kullanicilar SET sifre_hash=?, tuz=? WHERE id=?", (sifre_ozet(sifre, tuz), tuz, kid))
        self.c.commit()

    def kullanici_adlari(self):
        return {r["id"]: r["ad"] for r in self.c.execute("SELECT id, ad FROM kullanicilar")}

    # ------------------------------------------------------------ denetim
    def _denetim(self, kullanici, aciklama, siparis_id=None, gemi_id=None, asama=None, alan=None, eski=None, yeni=None):
        self.c.execute(
            "INSERT INTO denetim (siparis_id, gemi_id, asama, alan, eski, yeni, aciklama, kullanici_id, seviye, zaman) "
            "VALUES (?,?,?,?,?,?,?,?,?,?)",
            (siparis_id, gemi_id, asama, alan, eski, yeni, aciklama,
             kullanici["id"] if kullanici else None, SEVIYE.get(kullanici["rol"], 1) if kullanici else 1, simdi()))

    def denetim(self, siparis_id=None, gemi_id=None, limit=300):
        if siparis_id is not None:
            q = self.c.execute("SELECT * FROM denetim WHERE siparis_id=? ORDER BY id DESC LIMIT ?", (siparis_id, limit))
        elif gemi_id is not None:
            q = self.c.execute("SELECT * FROM denetim WHERE gemi_id=? ORDER BY id DESC LIMIT ?", (gemi_id, limit))
        else:
            q = self.c.execute("SELECT * FROM denetim ORDER BY id DESC LIMIT ?", (limit,))
        return [dict(r) for r in q]

    # ------------------------------------------------------------ siparişler
    def yeni_siparis_no(self, atla=0):
        yil = int(simdi()[:4])
        on = "SP-%d-" % yil
        r = self._taze("SELECT no FROM siparisler WHERE no LIKE ? ORDER BY LENGTH(no) DESC, no DESC LIMIT 1", (on + "%",)).fetchone()
        sira = int(r["no"].split("-")[-1]) + 1 if r else 1
        return "%s%04d" % (on, sira + atla)

    def siparis_olustur(self, kullanici):
        """Aynı anda birden çok bilgisayar sipariş açarsa numara çakışabilir: program kendiliğinden sonraki
        numarayı dener (kullanıcı hata görmez)."""
        import random
        import time as _t
        from st_bulut import tekil_ihlali_mi
        for deneme in range(12):
            try:
                with self.islem():
                    return self._siparis_olustur(kullanici, deneme)
            except Exception as e:
                if not tekil_ihlali_mi(e) or deneme == 11:
                    raise
                _t.sleep(random.uniform(0.05, 0.3))

    def _siparis_olustur(self, kullanici, deneme):
        no = self.yeni_siparis_no(atla=deneme // 3)
        cur = self.c.execute("INSERT INTO siparisler (no, olusturan_id, olusturma) VALUES (?,?,?)",
                             (no, kullanici["id"], simdi()))
        sid = cur.lastrowid
        z = simdi()
        self.c.execute("INSERT INTO asama_durum (siparis_id, asama, durum, guncelleyen_id, zaman) VALUES " +
                       ", ".join(["(?,?,?,?,?)"] * len(SIRA_IDLER)),
                       [x for n in SIRA_IDLER for x in (sid, n, "na" if n == IADE else "todo", kullanici["id"], z)])
        self._denetim(kullanici, "Sipariş oluşturuldu (%s)" % no, siparis_id=sid, asama=1)
        return sid

    def siparis(self, sid):
        if self.bulut:
            r = self._ayna().tablolar["siparisler"].get((sid,))
            return dict(r) if r else None
        r = self.c.execute("SELECT * FROM siparisler WHERE id=?", (sid,)).fetchone()
        return dict(r) if r else None

    def siparis_sil(self, sid, kullanici, neden):
        self.siparis_kontrol(sid, kullanici)
        self.c.execute("UPDATE siparisler SET silindi=1, silen_id=?, silinme=?, silme_nedeni=? WHERE id=?",
                       (kullanici["id"], simdi(), neden, sid))
        self._denetim(kullanici, "Sipariş silindi" + (" – neden: %s" % neden if neden else ""), siparis_id=sid)
        self.c.commit()

    def siparis_geri_al(self, sid, kullanici):
        self.c.execute("UPDATE siparisler SET silindi=0 WHERE id=?", (sid,))
        self._denetim(kullanici, "Silinen sipariş geri alındı", siparis_id=sid)
        self.c.commit()

    def siparis_gemiye_bagla(self, sid, gid):
        self.c.execute("UPDATE siparisler SET gemi_id=? WHERE id=?", (gid, sid))
        self.c.commit()

    def siparis_listesi(self, silinenler=False):
        """Her sipariş: temel bilgiler + durumlar + aşama verisi. silinenler=True ise yalnızca silinenler."""
        if self.bulut:
            return self._siparis_listesi_ayna(silinenler)
        sip = [dict(r) for r in self.c.execute(
            "SELECT s.*, g.ad AS gemi_ad, g.imo AS gemi_imo FROM siparisler s LEFT JOIN gemiler g ON g.id = s.gemi_id "
            "WHERE s.silindi=? ORDER BY s.id DESC", (1 if silinenler else 0,))]
        durum = {}
        for r in self.c.execute("SELECT siparis_id, asama, durum, zaman FROM asama_durum"):
            durum.setdefault(r["siparis_id"], {})[r["asama"]] = r["durum"]
        veri = {}
        for r in self.c.execute("SELECT siparis_id, asama, alan, deger, giren_seviye, zaman FROM asama_veri"):
            veri.setdefault(r["siparis_id"], {}).setdefault(r["asama"], {})[r["alan"]] = (r["deger"], r["giren_seviye"])
        son = {}
        for r in self.c.execute("SELECT siparis_id, MAX(zaman) z FROM denetim WHERE siparis_id IS NOT NULL GROUP BY siparis_id"):
            son[r["siparis_id"]] = r["z"]
        for s in sip:
            s["durum"] = durum.get(s["id"], {})
            s["veri"] = veri.get(s["id"], {})
            s["son_islem"] = son.get(s["id"], s["olusturma"])
        return sip

    def _siparis_listesi_ayna(self, silinenler):
        a = self._ayna()
        with a.kilit:
            anahtar = (a.surum, bool(silinenler))
            if getattr(self, "_liste_onbellek", (None,))[0] != anahtar:
                T = a.tablolar
                durum, veri = {}, {}
                for (sid, n), r in T["asama_durum"].items():
                    durum.setdefault(sid, {})[n] = r["durum"]
                for (sid, n, alan), r in T["asama_veri"].items():
                    veri.setdefault(sid, {}).setdefault(n, {})[alan] = (r["deger"], r["giren_seviye"])
                sip = []
                for r in T["siparisler"].values():
                    if bool(r.get("silindi")) != bool(silinenler):
                        continue
                    s = dict(r)
                    g = T["gemiler"].get((s.get("gemi_id"),)) if s.get("gemi_id") else None
                    s["gemi_ad"], s["gemi_imo"] = (g["ad"], g["imo"]) if g else (None, None)
                    s["durum"] = durum.get(s["id"], {})
                    s["veri"] = veri.get(s["id"], {})
                    s["son_islem"] = a.son_islem.get(s["id"], s["olusturma"])
                    sip.append(s)
                sip.sort(key=lambda x: -x["id"])
                self._liste_onbellek = (anahtar, sip)
            return [dict(x) for x in self._liste_onbellek[1]]

    def durumlar(self, sid):
        if self.bulut:
            T = self._ayna().tablolar["asama_durum"]
            return {n: r["durum"] for (s_, n), r in list(T.items()) if s_ == sid}
        return {r["asama"]: r["durum"] for r in
                self.c.execute("SELECT asama, durum FROM asama_durum WHERE siparis_id=?", (sid,))}

    def durum_ayarla(self, sid, asama, durum, kullanici, aciklama=None):
        from st_tanim import DURUM
        with self.islem():
            self.siparis_kontrol(sid, kullanici)
            r = self._taze("SELECT durum FROM asama_durum WHERE siparis_id=? AND asama=?", (sid, asama)).fetchone()
            eski = r[0] if r else None
            if eski == durum:
                return  # başka bilgisayar aynı anda aynı şeyi yaptı: tekrar yazılmaz
            cur = self.c.execute("UPDATE asama_durum SET durum=?, guncelleyen_id=?, zaman=? WHERE siparis_id=? AND asama=? "
                                 "AND durum<>?", (durum, kullanici["id"], simdi(), sid, asama, durum))
            if cur.rowcount == 0:
                return
            self._denetim(kullanici, aciklama or "Aşama %d durumu: %s → %s" % (asama_no(asama), DURUM.get(eski, eski), DURUM.get(durum, durum)),
                          siparis_id=sid, asama=asama, alan="durum", eski=eski, yeni=durum)

    def iptal_et(self, sid, kullanici):
        with self.islem():
            self.siparis_kontrol(sid, kullanici)
            self.c.execute("UPDATE siparisler SET iptal=1 WHERE id=?", (sid,))
            self._denetim(kullanici, "Sipariş iptal edildi", siparis_id=sid, asama=6)

    def alan_degerleri(self, sid, asama):
        if self.bulut:
            T = self._ayna().tablolar["asama_veri"]
            return {k[2]: dict(r) for k, r in list(T.items()) if k[0] == sid and k[1] == asama}
        return {r["alan"]: dict(r) for r in
                self.c.execute("SELECT * FROM asama_veri WHERE siparis_id=? AND asama=?", (sid, asama))}

    def alanlari_kaydet(self, sid, asama, degerler, kullanici, ilk=None, zorla=False):
        """degerler: {alan: yeni_deger}. Değişenleri kaydeder ve denetime yazar. Değişen alan sayısını döner.
        ilk: formun açıldığı andaki değerler. Verilirse ve bu arada başka biri aynı alanı farklı bir değere
        çevirdiyse hiçbir şey yazılmaz, CakismaHatasi verilir (zorla=True ise yine de yazılır)."""
        seviye = SEVIYE.get(kullanici["rol"], 1)
        tanim = {a[0]: a[1] for a in ASAMA[asama]["alanlar"]}
        with self.islem():
            self.siparis_kontrol(sid, kullanici)
            mevcut = {r["alan"]: dict(r) for r in
                      self._taze("SELECT alan, deger, giren_id, zaman FROM asama_veri WHERE siparis_id=? AND asama=?",
                                 (sid, asama))}
            zaman = simdi()
            veri, denetim, cakismalar = [], [], []
            for alan, yeni in degerler.items():
                yeni = (yeni or "").strip()
                if asama == 1 and alan == "gemi":
                    yeni = gemi_anahtar(yeni)  # gemi adı hep büyük harf
                eski = (mevcut.get(alan) or {}).get("deger") or ""
                if yeni == eski:
                    continue
                if ilk is not None and not zorla:
                    acilista = (ilk.get(alan) or "").strip()
                    if asama == 1 and alan == "gemi":
                        acilista = gemi_anahtar(acilista)
                    if acilista != eski:
                        m = mevcut.get(alan) or {}
                        cakismalar.append({"alan": alan, "etiket": tanim.get(alan, alan), "sizin": yeni, "onlarin": eski,
                                           "kim_id": m.get("giren_id"), "zaman": m.get("zaman")})
                        continue
                veri.append((sid, asama, alan, yeni, kullanici["id"], seviye, zaman))
                denetim.append((sid, None, asama, alan, eski, yeni, "%s değişti" % tanim.get(alan, alan),
                                kullanici["id"], seviye, zaman))
            if cakismalar:
                adlar = self.kullanici_adlari()
                for c in cakismalar:
                    c["kim"] = adlar.get(c["kim_id"], "başka bir kullanıcı")
                raise CakismaHatasi(cakismalar)
            if veri:
                # değişen bütün alanlar tek seferde yazılır (bulutta her sorgu internete gidip gelir)
                self.c.execute(
                    "INSERT INTO asama_veri (siparis_id, asama, alan, deger, giren_id, giren_seviye, zaman) VALUES " +
                    ", ".join(["(?,?,?,?,?,?,?)"] * len(veri)) +
                    " ON CONFLICT(siparis_id, asama, alan) DO UPDATE SET deger=excluded.deger, giren_id=excluded.giren_id, "
                    "giren_seviye=excluded.giren_seviye, zaman=excluded.zaman",
                    [x for r in veri for x in r])
                self.c.execute(
                    "INSERT INTO denetim (siparis_id, gemi_id, asama, alan, eski, yeni, aciklama, kullanici_id, seviye, zaman) "
                    "VALUES " + ", ".join(["(?,?,?,?,?,?,?,?,?,?)"] * len(denetim)),
                    [x for r in denetim for x in r])
        return len(veri)

    # ------------------------------------------------------------ malzeme satırları
    def satirlar(self, sid):
        return [dict(r) for r in self.c.execute("SELECT * FROM satirlar WHERE siparis_id=? AND silindi=0 ORDER BY id", (sid,))]

    def satir_ekle(self, sid, kullanici, **v):
        with self.islem():
            self.siparis_kontrol(sid, kullanici)
            cur = self.c.execute(
                "INSERT INTO satirlar (siparis_id, malzeme, kod, miktar, birim, tedarikci, termin) VALUES (?,?,?,?,?,?,?)",
                (sid, v.get("malzeme"), v.get("kod"), v.get("miktar"), v.get("birim"), v.get("tedarikci"), v.get("termin")))
            self._denetim(kullanici, "Malzeme satırı eklendi: %s" % v.get("malzeme"), siparis_id=sid, asama=1)
        return cur.lastrowid

    def satir_guncelle(self, satir_id, kullanici, asama, **v):
        with self.islem():
            r = self._taze("SELECT * FROM satirlar WHERE id=?", (satir_id,)).fetchone()
            if not r:
                return
            self.siparis_kontrol(r["siparis_id"], kullanici)
            for k, yeni in v.items():
                eski = r[k] or ""
                if (yeni or "") != eski:
                    self.c.execute("UPDATE satirlar SET %s=? WHERE id=?" % k, (yeni, satir_id))
                    self._denetim(kullanici, "%s · %s değişti" % (r["malzeme"], k), siparis_id=r["siparis_id"],
                                  asama=asama, alan=k, eski=eski, yeni=yeni)

    def satir_sil(self, satir_id, kullanici):
        with self.islem():
            r = self._taze("SELECT * FROM satirlar WHERE id=? AND silindi=0", (satir_id,)).fetchone()
            if not r:
                return
            self.siparis_kontrol(r["siparis_id"], kullanici)
            self.c.execute("UPDATE satirlar SET silindi=1 WHERE id=?", (satir_id,))
            self._denetim(kullanici, "Malzeme satırı kaldırıldı: %s" % r["malzeme"], siparis_id=r["siparis_id"], asama=1)

    # ------------------------------------------------------------ ekler
    def ekler(self, sid, asama=None):
        if asama is None:
            q = self.c.execute("SELECT * FROM ekler WHERE siparis_id=? AND silindi=0 ORDER BY id", (sid,))
        else:
            q = self.c.execute("SELECT * FROM ekler WHERE siparis_id=? AND asama=? AND silindi=0 ORDER BY id", (sid, asama))
        return [dict(r) for r in q]

    def ek_ekle(self, sid, asama, kaynak, kullanici):
        """Fotoğraflar (jpg/png…) yüklenirken küçültülür (en uzun kenar 1600 piksel) – bulut alanı hızla dolmasın."""
        s = self.siparis(sid)
        if self.bulut:
            veri, ad = fotograf_kucult(kaynak)
            if len(veri) > 25 * 1024 * 1024:
                raise ValueError("Dosya çok büyük (25 MB üstü). Lütfen küçültüp tekrar ekleyin.")
            with self.islem():
                self.siparis_kontrol(sid, kullanici)
                cur = self.c.execute(
                    "INSERT INTO ekler (siparis_id, asama, dosya_adi, goreli_yol, ekleyen_id, ekleyen_seviye, zaman) VALUES (?,?,?,?,?,?,?)",
                    (sid, asama, ad, "ekler/%s/%s" % (s["no"], ad), kullanici["id"], SEVIYE.get(kullanici["rol"], 1), simdi()))
                self.c.execute("INSERT INTO ek_dosyalar (ek_id, veri) VALUES (?, ?)", (cur.lastrowid, veri))
                self._denetim(kullanici, "Dosya eklendi: %s" % ad, siparis_id=sid, asama=asama)
            return
        hedef_kl = os.path.join(self.ek_klasoru, s["no"])
        os.makedirs(hedef_kl, exist_ok=True)
        veri, ad = fotograf_kucult(kaynak)
        govde, uzanti = os.path.splitext(ad)
        hedef = os.path.join(hedef_kl, ad)
        i = 2
        while os.path.exists(hedef):
            hedef = os.path.join(hedef_kl, "%s_%d%s" % (govde, i, uzanti))
            i += 1
        with open(hedef, "wb") as f:
            f.write(veri)
        goreli = os.path.relpath(hedef, self.klasor)
        self.c.execute(
            "INSERT INTO ekler (siparis_id, asama, dosya_adi, goreli_yol, ekleyen_id, ekleyen_seviye, zaman) VALUES (?,?,?,?,?,?,?)",
            (sid, asama, os.path.basename(hedef), goreli, kullanici["id"], SEVIYE.get(kullanici["rol"], 1), simdi()))
        self._denetim(kullanici, "Dosya eklendi: %s" % os.path.basename(hedef), siparis_id=sid, asama=asama)
        self.c.commit()

    def ek_sil(self, ek_id, kullanici):
        with self.islem():
            r = self._taze("SELECT * FROM ekler WHERE id=? AND silindi=0", (ek_id,)).fetchone()
            if not r:
                return
            self.siparis_kontrol(r["siparis_id"], kullanici)
            self.c.execute("UPDATE ekler SET silindi=1 WHERE id=?", (ek_id,))
            self._denetim(kullanici, "Dosya kaldırıldı: %s" % r["dosya_adi"], siparis_id=r["siparis_id"], asama=r["asama"])

    def ek_tam_yol(self, ek):
        if not self.bulut:
            return os.path.join(self.klasor, ek["goreli_yol"])
        yol = os.path.join(self.ek_klasoru, "%d_%s" % (ek["id"], ek["dosya_adi"]))
        if not os.path.exists(yol):
            r = self.c.execute("SELECT veri FROM ek_dosyalar WHERE ek_id=?", (ek["id"],)).fetchone()
            if not r or r["veri"] is None:
                raise FileNotFoundError("Dosya bulutta bulunamadı: %s" % ek["dosya_adi"])
            with open(yol, "wb") as f:
                f.write(bytes(r["veri"]))
        return yol

    # ------------------------------------------------------------ gemiler
    def gemi_bul_veya_olustur(self, ad, imo, kullanici, siparis_id=None, kaynak_ad=None):
        """Siparişteki gemi adı / IMO'ya göre gemi kaydını bulur, yoksa oluşturur.
        IMO varsa önce IMO ile aranır; siparişteki IMO esas alınır (gemi kaydı ona göre güncellenir).
        Aynı anda iki bilgisayar aynı gemiyi eklerse tek kayıt kalır (çakışmada mevcut kayıt kullanılır)."""
        from st_bulut import tekil_ihlali_mi
        for deneme in range(4):
            try:
                with self.islem():
                    gid = self._gemi_bul_veya_olustur(ad, imo, kullanici, siparis_id, kaynak_ad)
            except Exception as e:
                if tekil_ihlali_mi(e) and deneme < 3:
                    continue  # başka bilgisayar aynı anda ekledi: yeniden bak, onunkini kullan
                raise
            imo_ = (imo or "").strip()
            if gid and imo_:
                gid = self.ayni_imo_birlestir(imo_, kullanici) or gid
            return gid

    def _gemi_bul_veya_olustur(self, ad, imo, kullanici, siparis_id, kaynak_ad):
        ad = gemi_anahtar(ad)
        imo = (imo or "").strip()
        if not ad and not imo:
            return None
        r = None
        if imo:
            r = self._taze("SELECT * FROM gemiler WHERE imo=? ORDER BY id LIMIT 1", (imo,)).fetchone()
        if r is None and ad:
            r = self._taze("SELECT * FROM gemiler WHERE anahtar=?", (ad,)).fetchone()
            if r is not None and imo and r["imo"] and r["imo"] != imo:
                # aynı adlı ama başka IMO'lu gemi kaydı var: bu sipariş başka gemi olabilir
                bagli = self._taze("SELECT COUNT(*) FROM siparisler WHERE gemi_id=? AND silindi=0 AND id<>?",
                                   (r["id"], siparis_id or -1)).fetchone()[0]
                if bagli:
                    r = None
        if r is not None:
            gid = r["id"]
            if imo and r["imo"] != imo:
                self.c.execute("UPDATE gemiler SET imo=? WHERE id=?", (imo, gid))
                self._denetim(kullanici, "IMO siparişe göre güncellendi", gemi_id=gid, siparis_id=siparis_id,
                              alan="imo", eski=r["imo"] or "", yeni=imo)
            yeni_ad = ad or gemi_anahtar(kaynak_ad)
            if yeni_ad and yeni_ad != r["ad"] and r["ad"].startswith("IMO "):
                if not self._taze("SELECT 1 FROM gemiler WHERE anahtar=? AND id<>?", (yeni_ad, gid)).fetchone():
                    self.c.execute("UPDATE gemiler SET ad=?, anahtar=? WHERE id=?", (yeni_ad, yeni_ad, gid))
                    self._denetim(kullanici, "Gemi adı güncellendi", gemi_id=gid, alan="ad", eski=r["ad"], yeni=yeni_ad)
            return gid
        yeni_ad = ad or gemi_anahtar(kaynak_ad) or ("IMO " + imo)
        anahtar = yeni_ad
        if self._taze("SELECT 1 FROM gemiler WHERE anahtar=?", (anahtar,)).fetchone():
            anahtar = "%s (IMO %s)" % (yeni_ad, imo)
        cur = self.c.execute(
            "INSERT INTO gemiler (anahtar, ad, imo, bolge, op_durum, ikmal, hareket, olusturma) VALUES (?,?,?,?,?,?,?,?)",
            (anahtar, yeni_ad, imo, "Belirsiz", "Teknik malzeme", "", "Bilinmiyor", simdi()))
        gid = cur.lastrowid
        self._denetim(kullanici, "Gemi takibe alındı (sipariş açıldı)", gemi_id=gid, siparis_id=siparis_id)
        return gid

    def ayni_imo_birlestir(self, imo, kullanici):
        """Aynı IMO'lu birden çok gemi kaydı varsa (aynı anda eklenmiş) en eskisinde birleştirir. Kalan gemi id'si."""
        imo = (imo or "").strip()
        if not imo:
            return None
        ids = [r[0] for r in self._taze("SELECT id FROM gemiler WHERE imo=? ORDER BY id", (imo,))]
        if len(ids) < 2:
            return ids[0] if ids else None
        hedef = ids[0]
        with self.islem():
            for kaynak in ids[1:]:
                self.c.execute("UPDATE siparisler SET gemi_id=? WHERE gemi_id=?", (hedef, kaynak))
                self.c.execute("UPDATE etalar SET gemi_id=? WHERE gemi_id=?", (hedef, kaynak))
                self.c.execute("UPDATE denetim SET gemi_id=? WHERE gemi_id=?", (hedef, kaynak))
                self.c.execute("DELETE FROM gemiler WHERE id=?", (kaynak,))
            self._denetim(kullanici, "Aynı IMO'lu gemi kayıtları birleştirildi (%d kayıt)" % (len(ids) - 1),
                          gemi_id=hedef, alan="imo", yeni=imo)
            if self.bulut:
                from st_bulut import veri_nesli_yenile
                veri_nesli_yenile(self.c)  # silinen gemi kaydı diğer bilgisayarların aynasından da kalksın
        return hedef

    def gemiler(self):
        if self.bulut:
            return sorted((dict(r) for r in list(self._ayna().tablolar["gemiler"].values())), key=lambda g: g["ad"] or "")
        return [dict(r) for r in self.c.execute("SELECT * FROM gemiler ORDER BY ad")]

    def gemi(self, gid):
        if self.bulut:
            r = self._ayna().tablolar["gemiler"].get((gid,))
            return dict(r) if r else None
        r = self.c.execute("SELECT * FROM gemiler WHERE id=?", (gid,)).fetchone()
        return dict(r) if r else None

    def gemi_guncelle(self, gid, degerler, kullanici):
        r = self.gemi(gid)
        etiket = {"imo": "IMO", "bolge": "Bölge", "op_durum": "Operasyon durumu", "ikmal": "İkmal noktası",
                  "hareket": "Gemi hareketi", "bogaz": "Boğaz / Kıyı Emniyeti bilgisi", "sorumlu": "Sorumlu personel",
                  "notlar": "Notlar"}
        for k, yeni in degerler.items():
            yeni = (yeni or "").strip()
            eski = r.get(k) or ""
            if yeni != eski:
                with self.islem():
                    self.c.execute("UPDATE gemiler SET %s=? WHERE id=?" % k, (yeni, gid))
                    self._denetim(kullanici, "%s değişti" % etiket.get(k, k), gemi_id=gid, alan=k, eski=eski, yeni=yeni)

    def etalar(self, gid):
        if self.bulut:
            return sorted((dict(r) for r in list(self._ayna().tablolar["etalar"].values()) if r["gemi_id"] == gid),
                          key=lambda e: -e["id"])
        return [dict(r) for r in self.c.execute("SELECT * FROM etalar WHERE gemi_id=? ORDER BY id DESC", (gid,))]

    def tum_etalar(self):
        d = {}
        if self.bulut:
            for r in sorted(list(self._ayna().tablolar["etalar"].values()), key=lambda e: -e["id"]):
                d.setdefault(r["gemi_id"], []).append(dict(r))
            return d
        for r in self.c.execute("SELECT * FROM etalar ORDER BY id DESC"):
            d.setdefault(r["gemi_id"], []).append(dict(r))
        return d

    def eta_ekle(self, gid, eta, liman, bildiren, notu, kullanici):
        with self.islem():
            self.c.execute(
                "INSERT INTO etalar (gemi_id, eta, liman, bildiren, notu, giren_id, giren_seviye, alinma) VALUES (?,?,?,?,?,?,?,?)",
                (gid, eta, liman, bildiren, notu, kullanici["id"], SEVIYE.get(kullanici["rol"], 1), simdi()))
            self._denetim(kullanici, "Acente ETA girildi: %s" % eta, gemi_id=gid, alan="eta", yeni=eta)

    # ------------------------------------------------------------ ortak ayarlar (tüm bilgisayarlar)
    def meta_al(self, anahtar, varsayilan=""):
        r = self.c.execute("SELECT deger FROM meta WHERE anahtar=?", (anahtar,)).fetchone()
        return r["deger"] if r and r["deger"] is not None else varsayilan

    def meta_yaz(self, anahtar, deger):
        self.c.execute("INSERT INTO meta (anahtar, deger) VALUES (?,?) ON CONFLICT(anahtar) DO UPDATE SET deger=excluded.deger",
                       (anahtar, deger))
        self.c.commit()

    # ------------------------------------------------------------ okundu
    def okunanlar(self, kid):
        return {r["anahtar"] for r in self.c.execute("SELECT anahtar FROM okundu WHERE kullanici_id=?", (kid,))}

    def okundu_isaretle(self, kid, anahtar):
        self.c.execute("INSERT OR IGNORE INTO okundu (kullanici_id, anahtar, zaman) VALUES (?,?,?)", (kid, anahtar, simdi()))
        self.c.commit()
