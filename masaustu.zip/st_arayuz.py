# -*- coding: utf-8 -*-
"""Sipariş ve Gemi Takip - ana pencere ve ekranlar."""
import os
import sys
import csv
import json
import time
import subprocess
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

import st_mantik as M
from st_tanim import (PROGRAM_ADI, SURUM, ROLLER, DEPARTMANLAR, DURUM, ASAMALAR, ASAMA, RENK, ONCELIK_RENK,
                      TOPLAMA_DURUMLARI, BOLGELER, OPERASYON_DURUMLARI, HAREKET_DURUMLARI, SEVIYE_ADI,
                      LACIVERT, VURGU, ZEMIN, KART, CIZGI, YAZI, SOLUK, gemi_anahtar, tr_upper)
from st_ortak import (font, pill, kart, link, lbl, bant, KaydirmaliAlan, ortala, tarih_alani, saat_alani)


_KEGM = []


def kegm_takibi():
    """Program boyunca tek bir Kıyı Emniyeti takibi çalışır."""
    if not _KEGM:
        from st_kegm import KegmTakip
        t = KegmTakip(os.path.join(os.path.dirname(os.path.abspath(__file__)), "kegm_onbellek.json"))
        if not os.environ.get("ST_KEGM_KAPALI"):
            t.baslat()
        _KEGM.append(t)
    return _KEGM[0]


def dosya_ac(yol):
    try:
        if sys.platform.startswith("win"):
            os.startfile(yol)  # noqa
        elif sys.platform == "darwin":
            subprocess.Popen(["open", yol])
        else:
            subprocess.Popen(["xdg-open", yol])
    except Exception as e:
        messagebox.showerror("Dosya açılamadı", str(e))


# =====================================================================================
class AnaPencere(tk.Frame):
    def __init__(self, root, db, kullanici, ayarlar, cikis_cb):
        super().__init__(root, bg=ZEMIN)
        self.root, self.db, self.k, self.ayarlar, self.cikis_cb = root, db, kullanici, ayarlar, cikis_cb
        self.ekran = None
        self._kaydet_cb = None  # açık formdaki kaydedilmemiş değişiklikleri kaydetmek için
        self._ust_cubuk()
        govde = tk.Frame(self, bg=ZEMIN)
        govde.pack(fill="both", expand=True)
        self.menu = tk.Frame(govde, bg=KART, width=210, highlightthickness=1, highlightbackground=CIZGI)
        self.menu.pack(side="left", fill="y")
        self.menu.pack_propagate(False)
        self.icerik = tk.Frame(govde, bg=ZEMIN)
        self.icerik.pack(side="left", fill="both", expand=True)
        self.durum_cubugu = tk.Label(self, text="", bg="#DDE3E9", fg=SOLUK, anchor="w", font=font(9), padx=12)
        self.durum_cubugu.pack(fill="x", side="bottom")
        self._bekleyen_dosya = os.path.join(db.klasor, "bekleyen_kayitlar.json")
        self.bekleyen = self._bekleyen_oku()
        self._son_oturum = time.time()
        self.kegm = kegm_takibi()
        self._esitle()
        self._menu_kur()
        self.goster("ana")
        self.after(60000, self._periyodik)
        self._kegm_son = self.kegm.veri.get("zaman")
        self.after(3000, self._kegm_kontrol)
        self.after(5000, self._programci_baslat)
        self.bildirim = None
        self.uygulama = None  # siparis_takip.Uygulama (tepsi / bildirim kutuları) – açılışta atanır
        self.after(2500, self._bildirim_baslat)

    # ------------------------------------------------------------------ çerçeve
    def _ust_cubuk(self):
        ust = tk.Frame(self, bg=LACIVERT, height=52)
        ust.pack(fill="x")
        tk.Label(ust, text="⬢  " + PROGRAM_ADI, bg=LACIVERT, fg="#FFFFFF", font=font(14, True)).pack(side="left", padx=16, pady=10)
        tk.Button(ust, text="Çıkış", command=self.cikis, bg=LACIVERT, fg="#FFFFFF", activebackground="#18324A",
                  activeforeground="#FFFFFF", relief="flat", font=font(10), padx=12, cursor="hand2",
                  highlightthickness=1, highlightbackground="#3A5168").pack(side="right", padx=12)
        tk.Button(ust, text="↻  Yeniden başlat", command=self.yeniden_baslat, bg=LACIVERT, fg="#FFFFFF",
                  activebackground="#18324A", activeforeground="#FFFFFF", relief="flat", font=font(10), padx=12,
                  cursor="hand2", highlightthickness=1, highlightbackground="#3A5168").pack(side="right")
        rol = ROLLER[self.k["rol"]] + " · " + DEPARTMANLAR.get(self.k["departman"], "")
        self.kullanici_lbl = tk.Label(ust, text="%s   (%s)" % (self.k["ad"], rol), bg=LACIVERT, fg="#C9D3DD", font=font(10))
        self.kullanici_lbl.pack(side="right", padx=8)
        self.baglanti_lbl = tk.Label(ust, text="", bg=LACIVERT, fg="#7CD992", font=font(10, True))
        self.baglanti_lbl.pack(side="right", padx=14)

    def _menu_kur(self):
        for w in self.menu.winfo_children():
            w.destroy()
        self.menu_dugmeleri = {}
        ogeler = [("ana", "Ana Panel"), ("siparisler", "Siparişler"), ("gemiler", "Gemi Takip"),
                  ("bogaz", "Boğaz Listeleri")]
        if self.k["rol"] in ("yonetici", "ust"):
            ogeler.append(("gecmis", "İşlem Geçmişi"))
        if self.k["rol"] == "ust":
            ogeler += [("kullanicilar", "Kullanıcılar / Yetki"), ("ayarlar", "Ayarlar")]
        tk.Frame(self.menu, bg=KART, height=12).pack()
        for anahtar, ad in ogeler:
            f = tk.Frame(self.menu, bg=KART, cursor="hand2")
            f.pack(fill="x", padx=8, pady=2)
            l = tk.Label(f, text=ad, bg=KART, fg=YAZI, font=font(11), anchor="w", padx=12, pady=10)
            l.pack(side="left", fill="x", expand=True)
            rozet = tk.Label(f, text="", bg=KART, fg="#FFFFFF", font=font(9, True), padx=6)
            rozet.pack(side="right", padx=8)
            for w in (f, l, rozet):
                w.bind("<Button-1>", lambda e, a=anahtar: self.goster(a))
            self.menu_dugmeleri[anahtar] = (f, l, rozet)
        tk.Label(self.menu, text="Sürüm %s" % SURUM, bg=KART, fg=SOLUK, font=font(8)).pack(side="bottom", pady=8)
        self._rozet_guncelle()

    def _menu_vurgula(self, anahtar):
        ana = {"siparis": "siparisler", "gemi": "gemiler"}.get(anahtar, anahtar)
        for a, (f, l, r) in self.menu_dugmeleri.items():
            secili = a == ana
            renk = "#E4ECF3" if secili else KART
            f.configure(bg=renk)
            l.configure(bg=renk, font=font(11, secili))
            if not r.cget("text"):
                r.configure(bg=renk)

    def _rozet_guncelle(self):
        try:
            sayi = len(self._okunmamis_uyarilar())
        except Exception:
            sayi = 0
        if "ana" in self.menu_dugmeleri:
            f, l, r = self.menu_dugmeleri["ana"]
            r.configure(text=str(sayi) if sayi else "", bg="#D64538" if sayi else f.cget("bg"))

    def _programci_baslat(self):
        """Açılışta güncelleme denetimi ve periyodik internet yedeği."""
        try:
            from st_arayuz_programci import acilis_kontrolleri
            acilis_kontrolleri(self)
        except Exception:
            import traceback
            traceback.print_exc()

    def _esitle(self, siparis_id=None):
        """Siparişlerdeki gemi adı / IMO'yu gemi takibine bağlar."""
        try:
            M.gemileri_esitle(self.db, self.k, self.kegm.veri, siparis_id)
        except Exception:
            import traceback
            traceback.print_exc()

    def _okunmamis_uyarilar(self):
        okunan = self.db.okunanlar(self.k["id"])
        return [u for u in M.uyarilar(self.db, self.k, kegm=self.kegm.veri) if u["anahtar"] not in okunan]

    # ------------------------------------------------------------------ bağlantı, bekleyen kayıtlar, oturum
    def _bekleyen_oku(self):
        try:
            with open(self._bekleyen_dosya, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return []

    def _bekleyen_yaz(self):
        try:
            if self.bekleyen:
                gecici = self._bekleyen_dosya + ".tmp"
                with open(gecici, "w", encoding="utf-8") as f:
                    json.dump(self.bekleyen, f, ensure_ascii=False, indent=1)
                os.replace(gecici, self._bekleyen_dosya)
            elif os.path.exists(self._bekleyen_dosya):
                os.remove(self._bekleyen_dosya)
        except Exception:
            import traceback
            traceback.print_exc()

    def bekleyen_ekle(self, s, asama, degerler, ilk):
        """Bağlantı yokken yapılan değişiklik: diske yazılır, bağlantı gelince gönderilir."""
        for e in self.bekleyen:  # aynı sipariş/aşama için bekleyen varsa birleştir
            if e["sid"] == s["id"] and e["asama"] == asama and e["kullanici"]["id"] == self.k["id"]:
                for a, v in degerler.items():
                    if a not in e["degerler"]:
                        e["ilk"][a] = ilk.get(a, "")
                    e["degerler"][a] = v
                self._bekleyen_yaz()
                return
        self.bekleyen.append({"sid": s["id"], "no": s.get("no", ""), "asama": asama, "degerler": dict(degerler),
                              "ilk": dict(ilk), "zaman": M.simdi_str(),
                              "kullanici": {"id": self.k["id"], "rol": self.k["rol"], "ad": self.k["ad"],
                                            "departman": self.k["departman"]}})
        self._bekleyen_yaz()
        self._baglanti_goster()

    def _bekleyenleri_gonder(self):
        from st_bulut import BaglantiYok
        from st_db import CakismaHatasi, SiparisSilindiHatasi, KullaniciHatasi
        gonderilen, notlar = 0, []
        for e in list(self.bekleyen):
            k = e["kullanici"]
            etiket = "%s · Aşama %d" % (e.get("no") or e["sid"], e["asama"])
            try:
                n = self.db.alanlari_kaydet(e["sid"], e["asama"], e["degerler"], k, ilk=e["ilk"])
            except CakismaHatasi as c:
                cak = {x["alan"] for x in c.cakismalar}
                kalan = {a: v for a, v in e["degerler"].items() if a not in cak}
                try:
                    n = self.db.alanlari_kaydet(e["sid"], e["asama"], kalan, k, zorla=True)
                except BaglantiYok:
                    break
                for x in c.cakismalar:
                    notlar.append("%s – %s: siz '%s' yazmıştınız, bu arada %s '%s' yazdı; onlarınki korundu."
                                  % (etiket, x["etiket"], x["sizin"], x["kim"], x["onlarin"]))
            except (SiparisSilindiHatasi, KullaniciHatasi) as x:
                notlar.append("%s: %s" % (etiket, x))
                n = 0
            except BaglantiYok:
                break
            except Exception as x:
                notlar.append("%s: kaydedilemedi (%s)" % (etiket, x))
                n = 0
            if n:
                gonderilen += 1
                try:
                    if self.db.durumlar(e["sid"]).get(e["asama"]) == "todo":
                        self.db.durum_ayarla(e["sid"], e["asama"], "prog", k, "Aşama %d başladı" % e["asama"])
                except Exception:
                    pass
            self.bekleyen.remove(e)
            self._bekleyen_yaz()
        if gonderilen:
            self.bildir("Bağlantı geldi: bekleyen %d değişiklik buluta kaydedildi." % gonderilen)
            if self.ekran in ("ana", "siparisler", "gemiler") and not self._kaydet_cb:
                self.goster(self.ekran, **getattr(self, "_son_kw", {}))
        if notlar:
            messagebox.showwarning("Bekleyen değişiklikler", "Bağlantı yokken yapılan değişikliklerle ilgili:\n\n• " +
                                   "\n• ".join(notlar))

    def _baglanti_goster(self):
        if not self.db.bulut:
            n = len(self.bekleyen)
            self.baglanti_lbl.configure(text=("● %d kayıt bekliyor" % n) if n else "", fg="#FFB74D")
            return
        n = len(self.bekleyen)
        if self.db.cevrimici:
            self.baglanti_lbl.configure(text="● Çevrimiçi" + (" · %d kayıt gönderiliyor" % n if n else ""), fg="#7CD992")
        else:
            self.baglanti_lbl.configure(text="● Bağlantı yok" + (" · %d kayıt bekliyor" % n if n else "") +
                                             " – yeniden bağlanılıyor…", fg="#FF8A80")

    def _oturum_kontrol(self):
        """Hesap pasif yapıldıysa oturum kapanır; rol / departman değiştiyse menü ve yetkiler hemen güncellenir."""
        try:
            u = self.db.kullanici_durumu(self.k["id"])
        except Exception:
            return  # bağlantı yok: sonra tekrar bakılır
        if u is None or not u["aktif"]:
            self._kaydet_cb = None
            messagebox.showwarning("Hesap pasif", "Hesabınız yönetici tarafından pasif yapıldı. Oturum kapatılıyor.")
            self.cikis_zorla()
            return
        if (u["rol"], u["departman"], u["ad"]) != (self.k["rol"], self.k["departman"], self.k["ad"]):
            self._bekleyeni_kaydet()
            self.k.update(rol=u["rol"], departman=u["departman"], ad=u["ad"])
            rol = ROLLER[self.k["rol"]] + " · " + DEPARTMANLAR.get(self.k["departman"], "")
            self.kullanici_lbl.configure(text="%s   (%s)" % (self.k["ad"], rol))
            self._menu_kur()
            izinli = {"ana", "siparisler", "siparis", "gemiler", "gemi", "bogaz"}
            if self.k["rol"] in ("yonetici", "ust"):
                izinli.add("gecmis")
            if self.k["rol"] == "ust":
                izinli |= {"kullanicilar", "ayarlar"}
            self.goster(self.ekran if self.ekran in izinli else "ana", **getattr(self, "_son_kw", {}))
            self.bildir("Yetkileriniz güncellendi: %s" % rol)

    def yeniden_baslat(self):
        """Programı kapatıp yeniden açar (açık formdaki değişiklikler önce kaydedilir)."""
        if not messagebox.askyesno("Yeniden başlat", "Program kapatılıp yeniden açılsın mı?\n\n"
                                                     "Açık formdaki değişiklikler önce kaydedilir."):
            return
        self._bekleyeni_kaydet()
        self._kapandi = True
        try:
            self.db.kapat()
        except Exception:
            pass
        if self.uygulama is not None:
            self.uygulama.tam_kapat(yeniden=True)
            return
        from st_programci import yeniden_baslat
        yeniden_baslat()
        self.root.destroy()

    def cikis_zorla(self):
        self._kaydet_cb = None
        self._kapandi = True
        try:
            self.cikis_cb()
        except Exception:
            pass

    def _kegm_kontrol(self):
        """Kıyı Emniyeti listesi arka planda yenilendiyse ekranı güncelle. Bağlantı / bekleyen kayıt / oturum denetimi."""
        if getattr(self, "_kapandi", False):
            return
        try:
            self._baglanti_goster()
            if self.bekleyen and self.db.cevrimici:
                self._bekleyenleri_gonder()
            if time.time() - self._son_oturum > 5:
                self._son_oturum = time.time()
                self._oturum_kontrol()
                if getattr(self, "_kapandi", False):
                    return
        except Exception:
            import traceback
            traceback.print_exc()
        if self.bildirim is not None:
            self.bildirim.kontrol()
            no = getattr(self.kegm, "fark_no", 0)
            if no != getattr(self, "_kegm_fark_no", None):
                ilk = getattr(self, "_kegm_fark_no", None) is None
                self._kegm_fark_no = no
                if not ilk and not getattr(self.kegm, "son_fark_bayat", False):
                    try:
                        self.bildirim.bogaz(list(self.kegm.son_fark))
                    except Exception:
                        import traceback
                        traceback.print_exc()
        try:
            z = self.kegm.veri.get("zaman")
            if z != self._kegm_son:
                self._kegm_son = z
                self._esitle()
                self._rozet_guncelle()
                self.bildir("Kıyı Emniyeti boğaz listeleri güncellendi (%s)" % z)
                if self.ekran in ("bogaz", "gemiler", "ana") and not self._kaydet_cb:
                    self.goster(self.ekran, **getattr(self, "_son_kw", {}))
        except Exception:
            pass
        if self.winfo_exists():
            self.after(3000, self._kegm_kontrol)

    def _periyodik(self):
        if getattr(self, "_kapandi", False):
            return
        self._rozet_guncelle()
        if self.ekran == "ana" and self.root.state() != "withdrawn":
            self.goster("ana")
        self.after(60000, self._periyodik)

    def bildir(self, metin):
        self.durum_cubugu.configure(text=metin)
        self.after(6000, lambda: self.durum_cubugu.configure(text=""))

    def cikis(self):
        self._bekleyeni_kaydet()
        self._kapandi = True
        if self.uygulama is not None:
            self.uygulama.oturumu_unut()  # bilerek çıkış: bu bilgisayarda hatırlanan oturum silinir
        self.cikis_cb()

    # ------------------------------------------------------------------ arka plan / bildirimler
    def _bildirim_baslat(self):
        if getattr(self, "_kapandi", False) or not self.winfo_exists():
            return
        try:
            from st_bildirim import BildirimIzleyici
            kutular = getattr(self.uygulama, "kutular", None)
            if kutular is None:
                from st_arka_plan import Bildirimler
                kutular = Bildirimler(self.root)
            self.bildirim = BildirimIzleyici(self, kutular)
            if self.uygulama is not None and getattr(self.uygulama, "tepsi", None) is not None:
                self.bildirim.duraklat = self.uygulama.tepsi.duraklat
                self.uygulama.tepsi.baslik("Sipariş ve Gemi Takip · %s" % self.k["ad"])
        except Exception:
            import traceback
            traceback.print_exc()
            self.after(15000, self._bildirim_baslat)  # bağlantı yoksa sonra tekrar

    def pencereyi_ac(self, ekran=None, **kw):
        """Bildirime tıklanınca: pencere öne gelir, ilgili ekran açılır."""
        if self.uygulama is not None:
            self.uygulama.pencereyi_goster()
        else:
            self.root.deiconify()
            self.root.lift()
        if ekran:
            self.goster(ekran, **kw)

    def _bekleyeni_kaydet(self):
        if self._kaydet_cb:
            try:
                self._kaydet_cb(sessiz=True)  # bağlantı yoksa kayıt bu bilgisayarda bekletilir (kaybolmaz)
            except Exception:
                import traceback
                traceback.print_exc()
        self._kaydet_cb = None

    def goster(self, ekran, **kw):
        self._bekleyeni_kaydet()
        for w in self.icerik.winfo_children():
            w.destroy()
        self.ekran = ekran
        self._son_kw = kw if ekran in ("gemi", "ayarlar") else {}
        self._menu_vurgula(ekran)
        from st_bulut import BaglantiYok
        try:
            {"ana": self.ekran_ana, "siparisler": self.ekran_siparisler, "siparis": self.ekran_siparis,
             "gemiler": self.ekran_gemiler, "gemi": self.ekran_gemi, "gecmis": self.ekran_gecmis,
             "kullanicilar": self.ekran_kullanicilar, "ayarlar": self.ekran_ayarlar, "bogaz": self.ekran_bogaz}[ekran](**kw)
        except BaglantiYok:
            # bu ekranın verisi bu bilgisayarda yok ve internet yok: boş ekran yerine açıklama
            self._kaydet_cb = None
            for w in self.icerik.winfo_children():
                w.destroy()
            ic = self._sayfa("Bağlantı yok", "Bu ekranın verisi henüz bu bilgisayara inmemiş")
            k = kart(ic)
            k.pack(fill="x")
            lbl(k, "İnternet / bulut bağlantısı yok. Bağlantı gelince (üstte '● Çevrimiçi' yazınca) bu ekran açılır.\n"
                   "Ana Panel, Siparişler ve Gemi Takip listeleri bağlantı yokken de son bilinen haliyle açılır.",
                fg="#33404D", wraplength=800).pack(anchor="w", padx=18, pady=16)
            ttk.Button(k, text="Tekrar dene", command=lambda: self.goster(ekran, **kw)).pack(anchor="w", padx=18, pady=(0, 16))
        try:
            self._rozet_guncelle()
        except Exception:
            pass

    def _sayfa(self, baslik, alt=None, sag=None):
        alan = KaydirmaliAlan(self.icerik)
        alan.pack(fill="both", expand=True)
        ic = tk.Frame(alan.ic, bg=ZEMIN)
        ic.pack(fill="both", expand=True, padx=24, pady=18)
        bas = tk.Frame(ic, bg=ZEMIN)
        bas.pack(fill="x", pady=(0, 14))
        sol = tk.Frame(bas, bg=ZEMIN)
        sol.pack(side="left")
        tk.Label(sol, text=baslik, bg=ZEMIN, fg=YAZI, font=font(18, True)).pack(anchor="w")
        if alt:
            tk.Label(sol, text=alt, bg=ZEMIN, fg=SOLUK, font=font(10)).pack(anchor="w")
        if sag:
            for metin, komut, stil in sag:
                ttk.Button(bas, text=metin, command=komut, style=stil).pack(side="right", padx=(8, 0))
        return ic

    # ================================================================== ANA PANEL
    def ekran_ana(self):
        sip = self.db.siparis_listesi()
        gem = M.takip_gemileri(self.db, sip)
        uy = M.uyarilar(self.db, self.k, sip, gem, kegm=self.kegm.veri)
        okunan = self.db.okunanlar(self.k["id"])
        ic = self._sayfa("Ana Panel", "Bugün dikkat gerektiren işler · " + M.bugun_str(),
                         [("+  Yeni Sipariş", self.yeni_siparis, "Vurgu.TButton")])
        kartlar = tk.Frame(ic, bg=ZEMIN)
        kartlar.pack(fill="x")
        yakin = [g for g in gem if g["etalar"] and M.tarihsaat_coz(g["etalar"][0]["eta"])
                 and -12 * 3600 < (M.tarihsaat_coz(g["etalar"][0]["eta"]) - __import__("datetime").datetime.now()).total_seconds() <= 48 * 3600]
        veriler = [("Okunmamış uyarı", len([u for u in uy if u["anahtar"] not in okunan]), "Aşağıda listeleniyor", None),
                   ("Açık sipariş", len([s for s in sip if M.acik_mi(s)]), "Siparişlere git", lambda: self.goster("siparisler")),
                   ("Takipteki gemi", len(gem), "Gemi Takip listesine git", lambda: self.goster("gemiler")),
                   ("48 saatte gelecek gemi", len(yakin), "Listeyi aç", lambda: self.goster("gemiler", filtre="yakin"))]
        for i, (ad, sayi, ipucu, komut) in enumerate(veriler):
            k = kart(kartlar)
            k.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 10, 0))
            kartlar.columnconfigure(i, weight=1, uniform="k")
            lbl(k, ad, fg=SOLUK).pack(anchor="w", padx=16, pady=(14, 0))
            lbl(k, str(sayi), boy=24, kalin=True).pack(anchor="w", padx=16)
            if komut:
                link(k, ipucu, komut, kalin=False, boy=9).pack(anchor="w", padx=16, pady=(0, 14))
            else:
                lbl(k, ipucu, fg=SOLUK, boy=9).pack(anchor="w", padx=16, pady=(0, 14))
            if komut:
                for w in (k,) + tuple(k.winfo_children()):
                    w.bind("<Button-1>", lambda e, c=komut: c())
                    w.configure(cursor="hand2")

        liste = kart(ic)
        liste.pack(fill="x", pady=(18, 0))
        bas = tk.Frame(liste, bg=KART)
        bas.pack(fill="x", padx=18, pady=12)
        lbl(bas, "Dikkat gerektirenler", boy=13, kalin=True).pack(side="left")
        lbl(bas, "Sipariş ve gemi hareketi birlikte değerlendirilir", fg=SOLUK, boy=9).pack(side="right")
        if not uy:
            lbl(liste, "Şu an dikkat gerektiren bir iş yok.", fg=SOLUK).pack(anchor="w", padx=18, pady=(0, 16))
        for u in uy:
            okundu = u["anahtar"] in okunan
            tk.Frame(liste, bg="#EEF1F4", height=1).pack(fill="x")
            satir = tk.Frame(liste, bg=KART)
            satir.pack(fill="x", padx=18, pady=10)
            p = pill(satir, u["oncelik"], ONCELIK_RENK[u["oncelik"]])
            p.configure(width=7)
            p.pack(side="left", anchor="n", padx=(0, 14))
            orta = tk.Frame(satir, bg=KART)
            orta.pack(side="left", fill="x", expand=True)
            renk = SOLUK if okundu else YAZI
            lbl(orta, u["baslik"], fg=renk, kalin=True).pack(anchor="w")
            lbl(orta, u["metin"], fg=SOLUK if okundu else "#33404D", wraplength=720).pack(anchor="w")
            lbl(orta, u["kaynak"], fg=SOLUK, boy=8).pack(anchor="w")
            sag = tk.Frame(satir, bg=KART)
            sag.pack(side="right")
            if u.get("gemi_id"):
                ttk.Button(sag, text="Gemiyi aç", command=lambda g=u["gemi_id"]: self.goster("gemi", gemi_id=g)).pack(side="left", padx=4)
            elif u.get("siparis_id"):
                ttk.Button(sag, text="Siparişi aç", command=lambda s=u["siparis_id"]: self.goster("siparis", siparis_id=s)).pack(side="left", padx=4)
            b = ttk.Button(sag, text="Okundu" if okundu else "Okundu işaretle",
                           command=lambda a=u["anahtar"]: (self.db.okundu_isaretle(self.k["id"], a), self.goster("ana")))
            b.pack(side="left", padx=4)
            if okundu:
                b.state(["disabled"])

    # ================================================================== SİPARİŞ LİSTESİ
    FILTRELER = [("acik", "Açık sipariş", lambda s: M.acik_mi(s)),
                 ("hazir", "Sevke hazır", lambda s: M.acik_mi(s) and s["durum"].get(2) == "done" and s["durum"].get(3) != "done"),
                 ("evrak", "Evrak bekliyor", lambda s: M.acik_mi(s) and s["durum"].get(2) == "done" and s["durum"].get(4) != "done"),
                 ("odeme", "Ödeme bekliyor", lambda s: M.acik_mi(s) and s["durum"].get(5) == "prog"),
                 ("geciken", "Geciken", lambda s: M.gecikmis_mi(s)),
                 ("tumu", "Tümü (kapananlar dahil)", lambda s: True)]
    SILINENLER = ("silinen", "Silinenler", lambda s: True)

    def ekran_siparisler(self, filtre=None, arama=""):
        filtre = filtre or getattr(self, "_sip_filtre", "acik")
        self._sip_filtre = filtre
        filtreler = list(self.FILTRELER) + ([self.SILINENLER] if self.k["rol"] == "ust" else [])
        if filtre not in [f[0] for f in filtreler]:
            filtre = self._sip_filtre = "acik"
        sip = self.db.siparis_listesi()
        silinen = self.db.siparis_listesi(silinenler=True) if self.k["rol"] == "ust" else []
        ic = self._sayfa("Siparişler", "Siparişler ve aşama durumları",
                         [("+  Yeni Sipariş", self.yeni_siparis, "Vurgu.TButton"),
                          ("Excel'e aktar", lambda: self.siparisleri_aktar(sip), "TButton")])
        kartlar = tk.Frame(ic, bg=ZEMIN)
        kartlar.pack(fill="x")
        for i, (a, ad, fn) in enumerate(filtreler):
            secili = a == filtre
            k = tk.Frame(kartlar, bg=KART, highlightthickness=2 if secili else 1,
                         highlightbackground=VURGU if secili else CIZGI, cursor="hand2")
            k.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 8, 0))
            kartlar.columnconfigure(i, weight=1, uniform="f")
            l1 = lbl(k, ad, fg=SOLUK, boy=9)
            l1.pack(anchor="w", padx=12, pady=(10, 0))
            l2 = lbl(k, str(len(silinen) if a == "silinen" else len([s for s in sip if fn(s)])), boy=20, kalin=True)
            l2.pack(anchor="w", padx=12, pady=(0, 10))
            for w in (k, l1, l2):
                w.bind("<Button-1>", lambda e, f=a: self.goster("siparisler", filtre=f))

        tablo = kart(ic)
        tablo.pack(fill="x", pady=(16, 0))
        ust = tk.Frame(tablo, bg=KART)
        ust.pack(fill="x", padx=14, pady=10)
        lbl(ust, "Ara").pack(side="left")
        ara = tk.StringVar(value=arama)
        e = ttk.Entry(ust, textvariable=ara, width=40)
        e.pack(side="left", padx=8)
        lejant = tk.Frame(ust, bg=KART)
        lejant.pack(side="right")
        for k_ in ("done", "prog", "todo", "na"):
            pill(lejant, DURUM[k_], k_, boy=8).pack(side="left", padx=3)
        govde = tk.Frame(tablo, bg=KART)
        govde.pack(fill="x")

        fn = dict((a, f) for a, _, f in filtreler)[filtre]
        if filtre == "silinen":
            sip = silinen

        def doldur(*_):
            for w in govde.winfo_children():
                w.destroy()
            q = ara.get().strip().lower()
            satirlar = [s for s in sip if fn(s)]
            if q:
                satirlar = [s for s in satirlar if q in (" ".join([s["no"], M.deger(s, 1, "gemi"), M.deger(s, 1, "musteri"),
                                                                   M.deger(s, 1, "imo")])).lower()]
            basliklar = ["Sipariş No", "Müşteri", "Gemi", "Termin", "Aşamalar 1–6", "Genel durum", "Sıradaki sorumlu", "Son işlem"]
            for c, b in enumerate(basliklar):
                tk.Label(govde, text=b, bg="#F5F7F9", fg="#33404D", font=font(9, True), anchor="w", padx=8, pady=7).grid(row=0, column=c, sticky="ew")
            govde.columnconfigure(1, weight=1, minsize=150)
            govde.columnconfigure(2, weight=1, minsize=130)
            if not satirlar:
                lbl(govde, "Bu filtreye uyan sipariş yok.", fg=SOLUK).grid(row=1, column=0, columnspan=8, sticky="w", padx=10, pady=16)
            for r, s in enumerate(satirlar, start=1):
                ac = (lambda sid: (lambda e=None: self.goster("siparis", siparis_id=sid)))(s["id"])
                metin, renk, sorumlu = M.genel_durum(s)
                hucreler = []
                l = link(govde, s["no"], ac, boy=10)
                l.grid(row=r, column=0, sticky="w", padx=8, pady=6)
                for c, v in ((1, M.deger(s, 1, "musteri") or "—"), (2, M.deger(s, 1, "gemi") or s.get("gemi_ad") or "— taslak —")):
                    x = lbl(govde, v, kalin=(c == 2), padx=8)
                    x.grid(row=r, column=c, sticky="ew", pady=6)
                    hucreler.append(x)
                ter = M.deger(s, 1, "termin") or "—"
                if M.gecikmis_mi(s):
                    pill(govde, ter + " · gecikti", "todo", boy=8).grid(row=r, column=3, sticky="w", padx=8)
                else:
                    x = lbl(govde, ter, padx=8)
                    x.grid(row=r, column=3, sticky="ew")
                    hucreler.append(x)
                pf = tk.Frame(govde, bg=KART)
                pf.grid(row=r, column=4, sticky="w", padx=8)
                for n in range(1, 7):
                    d = s["durum"].get(n, "todo")
                    a_, y_, k_ = RENK[d]
                    tk.Label(pf, text=str(n), width=2, bg=a_, fg=y_, font=font(9, True), highlightthickness=1,
                             highlightbackground=k_).pack(side="left", padx=1)
                pill(govde, metin, renk, boy=8).grid(row=r, column=5, sticky="w", padx=8)
                for c, v in ((6, sorumlu), (7, M.db_zaman_goster(s["son_islem"]))):
                    x = lbl(govde, v, fg="#33404D", padx=8, boy=9)
                    x.grid(row=r, column=c, sticky="ew")
                    hucreler.append(x)
                for x in hucreler + [pf]:
                    x.bind("<Button-1>", ac)
                    x.configure(cursor="hand2")
                tk.Frame(govde, bg="#EEF1F4", height=1).grid(row=r, column=0, columnspan=8, sticky="sew")

        ara.trace_add("write", doldur)
        doldur()
        e.focus_set()

    def siparisleri_aktar(self, sip):
        yol = filedialog.asksaveasfilename(title="Excel'e aktar", defaultextension=".xlsx",
                                           initialfile="siparisler_%s.xlsx" % M.bugun_str().replace(".", "-"),
                                           filetypes=[("Excel", "*.xlsx"), ("CSV", "*.csv")])
        if not yol:
            return
        basliklar = ["Sipariş No", "Müşteri", "Gemi", "IMO", "Sipariş tarihi", "Termin"] + \
                    ["%d. %s" % (a["n"], a["kisa"]) for a in ASAMALAR] + ["Genel durum", "Sorumlu"]
        satirlar = []
        for s in sip:
            g = M.genel_durum(s)
            satirlar.append([s["no"], M.deger(s, 1, "musteri"), M.deger(s, 1, "gemi"), M.deger(s, 1, "imo"),
                             M.deger(s, 1, "siparis_tarihi"), M.deger(s, 1, "termin")] +
                            [DURUM.get(s["durum"].get(n, "todo")) for n in range(1, 7)] + [g[0], g[2]])
        self._tablo_yaz(yol, basliklar, satirlar)

    def _tablo_yaz(self, yol, basliklar, satirlar):
        try:
            if yol.lower().endswith(".xlsx"):
                try:
                    import openpyxl
                    from openpyxl.styles import Font
                except ImportError:
                    yol = yol[:-5] + ".csv"
                    messagebox.showinfo("Bilgi", "Excel kütüphanesi (openpyxl) yok; CSV olarak kaydediliyor.")
                else:
                    wb = openpyxl.Workbook()
                    ws = wb.active
                    ws.append(basliklar)
                    for c in ws[1]:
                        c.font = Font(bold=True)
                    for r in satirlar:
                        ws.append(r)
                    for col in ws.columns:
                        ws.column_dimensions[col[0].column_letter].width = max(12, min(40, max(len(str(c.value or "")) for c in col) + 2))
                    wb.save(yol)
                    self.bildir("Kaydedildi: " + yol)
                    return
            with open(yol, "w", newline="", encoding="utf-8-sig") as f:
                w = csv.writer(f, delimiter=";")
                w.writerow(basliklar)
                w.writerows(satirlar)
            self.bildir("Kaydedildi: " + yol)
        except Exception as e:
            messagebox.showerror("Kaydedilemedi", str(e))

    def silebilir(self, s):
        """Üst Yönetici her siparişi; diğerleri yalnızca kendi açtığı ve kaydı tamamlanmamış (taslak) siparişi silebilir."""
        if self.k["rol"] == "ust":
            return True
        return s.get("olusturan_id") == self.k["id"] and s.get("durum", {}).get(1) != "done"

    def siparis_sil(self, s):
        p = tk.Toplevel(self)
        p.title("Siparişi sil")
        p.configure(bg=KART)
        p.transient(self.root)
        p.grab_set()
        gemi = M.deger(s, 1, "gemi") or s.get("gemi_ad") or "—"
        lbl(p, "%s silinsin mi?" % s["no"], boy=13, kalin=True).pack(anchor="w", padx=18, pady=(16, 2))
        lbl(p, "Gemi: %s · Müşteri: %s" % (gemi, M.deger(s, 1, "musteri") or "—"), fg=SOLUK).pack(anchor="w", padx=18)
        lbl(p, "Sipariş listelerden ve gemi takibinden kalkar. Kayıt tamamen yok edilmez; Üst Yönetici\n"
               "'Silinenler' bölümünden görebilir ve geri alabilir.", fg="#33404D", boy=9).pack(anchor="w", padx=18, pady=(8, 8))
        lbl(p, "Silme nedeni", boy=9, kalin=True).pack(anchor="w", padx=18)
        v = tk.StringVar()
        e = ttk.Entry(p, textvariable=v, width=52)
        e.pack(fill="x", padx=18, pady=(3, 0))
        e.focus_set()

        def tamam():
            self._kaydet_cb = None
            self.db.siparis_sil(s["id"], self.k, v.get().strip())
            p.destroy()
            self.bildir("%s silindi" % s["no"])
            self.goster("siparisler")
        dz = tk.Frame(p, bg=KART)
        dz.pack(fill="x", padx=18, pady=14)
        ttk.Button(dz, text="Vazgeç", command=p.destroy).pack(side="right", padx=(6, 0))
        ttk.Button(dz, text="Sil", style="Tehlike.TButton", command=tamam).pack(side="right")
        p.bind("<Return>", lambda e_: tamam())
        ortala(p, self.root)

    def siparis_geri_al(self, sid):
        self.db.siparis_geri_al(sid, self.k)
        self._esitle(sid)
        self.bildir("Sipariş geri alındı")
        self.goster("siparis", siparis_id=sid)

    def yeni_siparis(self):
        if not (self.k["rol"] == "ust" or self.k["departman"] == "satinalma"):
            if not messagebox.askyesno("Yeni sipariş", "Siparişi genellikle Satın Alma açar. Yine de yeni sipariş açılsın mı?"):
                return
        sid = self.db.siparis_olustur(self.k)
        self.db.alanlari_kaydet(sid, 1, {"siparis_tarihi": M.bugun_str(), "siparisi_alan": self.k["ad"]}, self.k)
        self.goster("siparis", siparis_id=sid, asama=1)

    # ================================================================== SİPARİŞ DETAYI
    def ekran_siparis(self, siparis_id, asama=None):
        s = self.db.siparis(siparis_id)
        if not s:
            self.goster("siparisler")
            return
        liste = [x for x in self.db.siparis_listesi(silinenler=bool(s.get("silindi"))) if x["id"] == siparis_id][0]
        durum = liste["durum"]
        if asama is None:
            asama = next((n for n in range(1, 6) if durum.get(n) != "done"), 1)
        self._asama = asama
        ic = self._sayfa(s["no"], None)
        geri = link(ic, "‹  Sipariş listesi", lambda: self.goster("siparisler"), bg=ZEMIN, kalin=False)
        geri.pack(anchor="w", before=ic.winfo_children()[0])

        # başlık kartı
        metin, renk, sorumlu = M.genel_durum(liste)
        bk = kart(ic)
        bk.pack(fill="x")
        sol = tk.Frame(bk, bg=KART)
        sol.pack(side="left", padx=18, pady=14)
        ust = tk.Frame(sol, bg=KART)
        ust.pack(anchor="w")
        pill(ust, metin, renk).pack(side="left")
        if s["iptal"]:
            pill(ust, "İptal", "todo").pack(side="left", padx=6)
        if s.get("silindi"):
            pill(ust, "SİLİNDİ", "todo").pack(side="left", padx=6)
        gemi = M.deger(liste, 1, "gemi") or liste.get("gemi_ad") or ""
        lbl(sol, "%s · %s · Termin %s" % (M.deger(liste, 1, "musteri") or "Müşteri girilmedi", gemi or "Gemi girilmedi",
                                         M.deger(liste, 1, "termin") or "—"), fg="#33404D").pack(anchor="w", pady=(6, 0))
        sag = tk.Frame(bk, bg=KART)
        sag.pack(side="right", padx=18)
        lbl(sag, "Sıradaki sorumlu: %s" % sorumlu, fg="#33404D").pack(side="right", padx=(12, 0))
        if s.get("silindi"):
            if self.k["rol"] == "ust":
                ttk.Button(sag, text="Geri al (silmeyi kaldır)", style="Vurgu.TButton",
                           command=lambda: self.siparis_geri_al(siparis_id)).pack(side="right")
        elif self.silebilir(liste):
            ttk.Button(sag, text="Siparişi sil", style="Tehlike.TButton",
                       command=lambda: self.siparis_sil(liste)).pack(side="right", padx=(8, 0))
        g = [self.db.gemi(liste["gemi_id"])] if liste.get("gemi_id") and not s.get("silindi") else []
        if g and g[0]:
            et = self.db.etalar(g[0]["id"])
            ttk.Button(sag, text="Gemi takibini aç · ETA %s" % (et[0]["eta"] if et else "belirsiz"),
                       command=lambda: self.goster("gemi", gemi_id=g[0]["id"])).pack(side="right")

        if s.get("silindi"):
            bant(ic, "🗑  Bu sipariş %s tarihinde silindi%s. Listelerde ve gemi takibinde görünmez; kayıtları "
                     "yalnızca Üst Yönetici görebilir ve geri alabilir."
                 % (M.db_zaman_goster(s.get("silinme")), (" – neden: " + s["silme_nedeni"]) if s.get("silme_nedeni") else ""),
                 "hata").pack(fill="x", pady=(12, 0))

        # aşama adımları
        adim = tk.Frame(ic, bg=ZEMIN)
        adim.pack(fill="x", pady=12)
        for i, a in enumerate(ASAMALAR):
            n = a["n"]
            d = durum.get(n, "todo")
            sec = n == asama
            f = tk.Frame(adim, bg=KART, highlightthickness=2 if sec else 1,
                         highlightbackground=LACIVERT if sec else CIZGI, cursor="hand2")
            f.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 6, 0))
            adim.columnconfigure(i, weight=1, uniform="a")
            ust_ = tk.Frame(f, bg=KART)
            ust_.pack(anchor="w", padx=10, pady=(8, 0))
            a_, y_, k_ = RENK[d]
            c = tk.Label(ust_, text=str(n), width=2, bg=a_, fg=y_, font=font(10, True), highlightthickness=2, highlightbackground=k_)
            c.pack(side="left")
            t = lbl(ust_, a["kisa"], kalin=True, padx=6, boy=9)
            t.pack(side="left")
            dl = lbl(f, DURUM[d], fg="#33404D", boy=9)
            dl.pack(anchor="w", padx=10, pady=(2, 8))
            for w in (f, ust_, c, t, dl):
                w.bind("<Button-1>", lambda e, nn=n: self.goster("siparis", siparis_id=siparis_id, asama=nn))

        alt = tk.Frame(ic, bg=ZEMIN)
        alt.pack(fill="both", expand=True)
        alt.columnconfigure(0, weight=1)
        alt.columnconfigure(1, minsize=340)
        sol = tk.Frame(alt, bg=ZEMIN)
        sol.grid(row=0, column=0, sticky="nsew")
        sag = tk.Frame(alt, bg=ZEMIN)
        sag.grid(row=0, column=1, sticky="nsew", padx=(14, 0))
        self._form = AsamaFormu(self, sol, sag, s, liste, asama)  # referans tutulmazsa kutular boş görünür


def vazgec_tamamla(ana, baslik, metin):
    """'Vazgeç' / 'Tamamla' düğmeli onay penceresi. Tamamla'ya basılırsa True."""
    p = tk.Toplevel(ana)
    p.title(baslik)
    p.configure(bg=KART)
    p.transient(ana.root)
    p.resizable(False, False)
    sonuc = {"v": False}
    lbl(p, baslik, boy=13, kalin=True, fg="#8A4300").pack(anchor="w", padx=22, pady=(18, 6))
    lbl(p, metin, fg="#33404D", wraplength=420).pack(anchor="w", padx=22)
    dz = tk.Frame(p, bg=KART)
    dz.pack(fill="x", padx=22, pady=18)

    def sec(v):
        sonuc["v"] = v
        p.destroy()
    ttk.Button(dz, text="Tamamla", style="Vurgu.TButton", command=lambda: sec(True)).pack(side="right")
    vz = ttk.Button(dz, text="Vazgeç", command=lambda: sec(False))
    vz.pack(side="right", padx=(0, 8))
    p.bind("<Escape>", lambda e: sec(False))
    p.protocol("WM_DELETE_WINDOW", lambda: sec(False))
    ortala(p, ana.root)
    vz.focus_set()
    p.grab_set()
    p.wait_window()
    return sonuc["v"]


# =====================================================================================
class AsamaFormu:
    """Bir siparişin seçili aşamasının formu + sağ panel."""

    def __init__(self, ana, sol, sag, s, liste, asama):
        self.ana, self.db, self.k = ana, ana.db, ana.k
        self.s, self.liste, self.asama = s, liste, asama
        self.tanim = ASAMA[asama]
        self.durum = liste["durum"].get(asama, "todo")
        self.durumlar = liste["durum"]
        self.degiskenler = {}
        self.metin_kutulari = {}
        self.girisler = {}
        self._gizli_degiskenler = []
        self._kilit_nedeni()
        self._sol(sol)
        self._ilk = self._form_degerleri()  # formun açıldığı andaki değerler
        if self.asama == 1 and not self.kilitli and "imo" in self.girisler and "gemi" in self.degiskenler:
            self._imo_baglan()
        self._sag(sag)
        if not self.kilitli and self.durum != "na":
            ana._kaydet_cb = self.kaydet

    # ---------------------------------------------------------------- kilit / yetki
    def _kilit_nedeni(self):
        n, k = self.asama, self.k
        self.mesaj = ""
        if self.s["iptal"]:
            self.mesaj = "Bu sipariş iptal edildi; kayıtlar yalnızca görüntülenebilir."
        elif not M.duzenleyebilir(k, n):
            kim = "Yönetici ve Üst Yönetici" if self.tanim["dept"] == "yonetici" else \
                "%s departmanı ve Üst Yönetici" % DEPARTMANLAR[self.tanim["dept"]]
            self.mesaj = "Bu aşamayı yalnızca %s düzenleyebilir. Görüntüleme modundasınız." % kim
        elif n == 5 and self.durum != "done" and any(self.durumlar.get(x) != "done" for x in (1, 2, 3, 4)):
            self.mesaj = "Bu aşama, 1–4. aşamalar tamamlanıp yeşile döndüğünde açılır."
        elif self.durum == "done" and k["rol"] != "ust":
            self.mesaj = "Tamamlanan aşama kilitlidir. Düzeltme için Üst Yönetici aşamayı yeniden açabilir."
        self.kilitli = bool(self.mesaj)

    # ---------------------------------------------------------------- sol: form
    def _sol(self, sol):
        k = kart(sol)
        k.pack(fill="both", expand=True)
        bas = tk.Frame(k, bg=KART)
        bas.pack(fill="x", padx=18, pady=(14, 10))
        sorumlu = "Yönetici" if self.tanim["dept"] == "yonetici" else DEPARTMANLAR[self.tanim["dept"]]
        lbl(bas, "AŞAMA %d · SORUMLU: %s" % (self.asama, tr_upper(sorumlu)), fg=SOLUK, boy=9, kalin=True).pack(anchor="w")
        bs = tk.Frame(bas, bg=KART)
        bs.pack(fill="x")
        lbl(bs, self.tanim["uzun"], boy=13, kalin=True).pack(side="left")
        pill(bs, DURUM[self.durum], self.durum).pack(side="right")
        tk.Frame(k, bg=CIZGI, height=1).pack(fill="x")
        govde = tk.Frame(k, bg=KART)
        govde.pack(fill="both", expand=True, padx=18, pady=14)
        self.govde = govde

        if self.kilitli:
            bant(govde, "🔒  " + self.mesaj, "kilit").pack(fill="x", pady=(0, 12))

        if self.asama == 6 and self.durum == "na":
            f = tk.Frame(govde, bg="#F7F8FA", highlightthickness=1, highlightbackground="#9AA1AC")
            f.pack(fill="x")
            lbl(f, "Bu aşama standart akışta pasiftir ve siparişin tamamlanmasını engellemez. İade, değişim veya iptal "
                   "ihtiyacı doğduğunda Yönetici ya da Üst Yönetici tarafından açılır. Asıl siparişin geçmişi silinmez.",
                bg="#F7F8FA", fg="#33404D", wraplength=700).pack(anchor="w", padx=16, pady=(14, 8))
            b = ttk.Button(f, text="İade / Değişim / İptal sürecini başlat", command=self.asama6_baslat)
            b.pack(anchor="w", padx=16, pady=(0, 14))
            if not M.duzenleyebilir(self.k, 6) or self.s["iptal"]:
                b.state(["disabled"])
            return

        if self.asama == 1 and not self.kilitli:
            bant(govde, "ℹ  Gemi adı veya IMO girilip kaydedilince gemi Gemi Takip'e ve Kıyı Emniyeti boğaz takibine kendiliğinden "
                        "eklenir. IMO numarası girilirse gemi kesin eşleşir (yalnızca IMO girerseniz gemi adı Kıyı Emniyeti'nden alınır).",
                 "bilgi").pack(fill="x", pady=(0, 12))
        if self.asama == 4:
            for u in M.kap_kilo_uyusmazligi(self.db, self.s["id"]):
                bant(govde, "⚠  " + u, "uyari").pack(fill="x", pady=(0, 12))
        if self.asama == 5:
            v = {kk: vv["deger"] for kk, vv in self.db.alan_degerleri(self.s["id"], 5).items()}
            alt = tk.Frame(govde, bg=KART)
            alt.pack(fill="x", pady=(0, 12))
            sevk = bool(v.get("sevk_zamani"))
            lbl(alt, "Sevkiyat:", fg="#33404D").pack(side="left")
            pill(alt, "Tamamlandı" if sevk else "Bekliyor", "done" if sevk else "todo").pack(side="left", padx=(6, 18))
            th = v.get("tahsilat_durumu") or "Talep edilmedi"
            lbl(alt, "Ödeme:", fg="#33404D").pack(side="left")
            pill(alt, th, "done" if th == "Ödendi" else ("todo" if th in ("Gecikmiş", "Talep edilmedi") else "prog")).pack(side="left", padx=6)

        # alanlar
        mevcut = self.db.alan_degerleri(self.s["id"], self.asama)
        izgara = tk.Frame(govde, bg=KART)
        izgara.pack(fill="x")
        sutun = 3
        for c in range(sutun):
            izgara.columnconfigure(c, weight=1, uniform="alan")
        r = c = 0
        for anahtar, etiket, zorunlu, tur, secenek in self.tanim["alanlar"]:
            kayit = mevcut.get(anahtar)
            deger = (kayit or {}).get("deger") or ""
            gizli = kayit is not None and deger and not M.gorebilir(self.k, kayit["giren_seviye"], anahtar, self.asama)
            if tur == "uzun":
                if c != 0:
                    r, c = r + 1, 0
                kutu = tk.Frame(izgara, bg=KART)
                kutu.grid(row=r, column=0, columnspan=sutun, sticky="ew", padx=(0, 12), pady=6)
            else:
                kutu = tk.Frame(izgara, bg=KART)
                kutu.grid(row=r, column=c, sticky="new", padx=(0, 12), pady=6)
            lbl(kutu, etiket + (" *" if zorunlu else ""), fg="#33404D", boy=9, kalin=True).pack(anchor="w")
            satir = tk.Frame(kutu, bg=KART)
            satir.pack(fill="x", pady=(3, 0))
            ro = self.kilitli or gizli
            if gizli:
                deger = "🔒 Gizli (%s girdi)" % SEVIYE_ADI.get(kayit["giren_seviye"], "")
            if tur == "uzun":
                t = tk.Text(satir, height=3, font=font(10), relief="solid", bd=1, wrap="word",
                            highlightthickness=0, bg="#F2F4F7" if ro else "#FFFFFF")
                t.insert("1.0", deger)
                if ro:
                    t.configure(state="disabled")
                t.pack(fill="x")
                self.metin_kutulari[anahtar] = t
            elif tur == "secim":
                var = tk.StringVar(value=deger)
                cb = ttk.Combobox(satir, textvariable=var, values=secenek, state="disabled" if ro else "readonly")
                cb.pack(fill="x")
                self.degiskenler[anahtar] = var
                self.girisler[anahtar] = cb
            elif tur == "saataraligi":
                var = tk.StringVar(value=deger)
                cer, e = saat_alani(satir, var, salt_okunur=ro)
                cer.pack(side="left", fill="x", expand=True)
                self.degiskenler[anahtar] = var
                self.girisler[anahtar] = e
            elif tur in ("tarih", "tarihsaat"):
                # elle yazılabilir + 'Takvim' (tarihsaat'te saat / dakika seçimi de var)
                var = tk.StringVar(value=deger)
                cer, e = tarih_alani(satir, var, tur, salt_okunur=ro)
                cer.pack(side="left", fill="x", expand=True)
                self.degiskenler[anahtar] = var
                self.girisler[anahtar] = e
            else:
                var = tk.StringVar(value=deger)
                e = ttk.Entry(satir, textvariable=var, state="readonly" if ro else "normal")
                e.pack(side="left", fill="x", expand=True)
                self.degiskenler[anahtar] = var
                self.girisler[anahtar] = e
            if tur in ("tarih", "tarihsaat") and not ro:
                lbl(kutu, "gg.aa.yyyy" + (" ss:dd" if tur == "tarihsaat" else ""), fg=SOLUK, boy=8).pack(anchor="w")
            if tur == "saataraligi" and not ro:
                lbl(kutu, "ss:dd - ss:dd  (ya da tek saat)", fg=SOLUK, boy=8).pack(anchor="w")
            if gizli:
                # değişken çöpe gitmesin diye ayrı listede tutulur (aksi halde kutu boş görünür)
                self._gizli_degiskenler.append(self.degiskenler.pop(anahtar, None))
                self.metin_kutulari.pop(anahtar, None)
            if tur == "uzun":
                r, c = r + 1, 0
            else:
                c += 1
                if c >= sutun:
                    r, c = r + 1, 0

        if self.asama in (1, 2):
            self._satirlar(govde)

        # alt düğmeler
        tk.Frame(govde, bg="#E3E8ED", height=1).pack(fill="x", pady=(16, 10))
        alt = tk.Frame(govde, bg=KART)
        alt.pack(fill="x")
        self.engel_lbl = lbl(alt, "", fg=SOLUK, boy=9)
        self.engel_lbl.pack(side="left")
        if self.durum == "done":
            if self.k["rol"] == "ust" and not self.s["iptal"]:
                ttk.Button(alt, text="Aşamayı yeniden aç", command=self.yeniden_ac).pack(side="right", padx=(8, 0))
                ttk.Button(alt, text="Değişiklikleri kaydet", command=self.kaydet).pack(side="right")
            self.engel_lbl.configure(text="✔  Aşama tamamlandı.", fg="#17603A")
        elif not self.kilitli:
            ttk.Button(alt, text="Aşamayı tamamla", style="Vurgu.TButton", command=self.tamamla).pack(side="right", padx=(8, 0))
            ttk.Button(alt, text="Kaydet", command=self.kaydet).pack(side="right")
            if self.asama == 6:
                ttk.Button(alt, text="Süreci kapat (iptal et)", style="Tehlike.TButton",
                           command=self.asama6_geri_al).pack(side="right", padx=(0, 8))

    # ---------------------------------------------------------------- IMO → gemi adı
    def _imo_baglan(self):
        e = self.girisler["imo"]
        kutu = e.master.master
        self.imo_ipucu = lbl(kutu, "IMO yazınca gemi adı otomatik gelir", fg=SOLUK, boy=8, wraplength=300)
        self.imo_ipucu.pack(anchor="w")
        self.imo_duzelt = link(kutu, "", lambda: None, boy=9)
        self._imo_son = ""
        self._imo_zamanlayici = None
        e.bind("<FocusOut>", lambda ev: self._imo_sorgula(odak_cikti=True))
        e.bind("<Return>", lambda ev: self._imo_sorgula(odak_cikti=True))

        def degisti(*_):
            if self._imo_zamanlayici:
                try:
                    e.after_cancel(self._imo_zamanlayici)
                except Exception:
                    pass
            v = (self.degiskenler["imo"].get() or "").strip()
            if len(v) == 7 and v.isdigit():
                self._imo_zamanlayici = e.after(500, self._imo_sorgula)
            else:
                self._imo_son = ""  # yeniden yazılınca tekrar sorgulansın
                self._duzelt_gizle()
                if not v:
                    self._ipucu("IMO yazınca gemi adı otomatik gelir", SOLUK)
        self.degiskenler["imo"].trace_add("write", degisti)
        # form açılırken IMO zaten yazılıysa sessizce kontrol et (açılışta açılır pencere çıkmaz)
        if (self.degiskenler["imo"].get() or "").strip():
            e.after(300, lambda: self._imo_sorgula(sessiz=True))

    def _duzelt_gizle(self):
        try:
            self.imo_duzelt.pack_forget()
        except Exception:
            pass

    def _duzelt_goster(self, ad, kaynak):
        def uygula():
            self.degiskenler["gemi"].set(ad)
            self._duzelt_gizle()
            self._ipucu("✔ Gemi adı güncellendi: %s (%s) – kaydetmeyi unutmayın" % (ad, kaynak), "#17603A")
        self.imo_duzelt.configure(text="→ Gemi adını '%s' yap" % ad)
        self.imo_duzelt.bind("<Button-1>", lambda e: uygula())
        self.imo_duzelt.pack(anchor="w")

    def _ipucu(self, metin, renk):
        try:
            if self.imo_ipucu.winfo_exists():
                self.imo_ipucu.configure(text=metin, fg=renk)
        except Exception:
            pass

    def _imo_sorgula(self, odak_cikti=False, sessiz=False):
        from st_imo import imo_gecerli, yerel_ad, gemi_adi_bul, program_kaydi_ad
        self._sessiz = sessiz
        imo = (self.degiskenler["imo"].get() or "").strip().upper().replace("IMO", "").strip()
        if not imo or imo == self._imo_son:
            return
        if not (len(imo) == 7 and imo.isdigit()):
            if odak_cikti:
                self._ipucu("IMO 7 haneli rakam olmalı", "#9E2A21")
            return
        self._imo_son = imo
        if not imo_gecerli(imo):
            self._ipucu("✖ Bu IMO geçersiz görünüyor (kontrol hanesi tutmuyor) – numarayı kontrol edin", "#9E2A21")
            if sessiz:
                return
            messagebox.showwarning("IMO numarası", "IMO %s geçersiz görünüyor (kontrol hanesi tutmuyor).\n\n"
                                                   "Numarayı kontrol edin. Gemi adını lütfen elle girin." % imo)
            return
        ad, kaynak = yerel_ad(imo, self.ana.kegm.veri)
        if ad:
            self._imo_sonuc(imo, ad, kaynak, None)
            return
        self._ipucu("Gemi adı aranıyor…", SOLUK)
        sonuc = {}
        yedek = program_kaydi_ad(imo, self.db)
        kegm = self.ana.kegm.veri

        def is_():
            sonuc["v"] = gemi_adi_bul(imo, kegm, yedek)

        import threading
        t = threading.Thread(target=is_, daemon=True)
        t.start()
        giris = self.girisler["imo"]

        def bekle():
            try:
                if not giris.winfo_exists():
                    return
            except Exception:
                return
            if t.is_alive():
                giris.after(300, bekle)
                return
            ad_, kaynak_, hata = sonuc.get("v") or (None, None, "bilinmeyen hata")
            if (self.degiskenler["imo"].get() or "").strip() != imo:
                return  # kullanıcı bu arada IMO'yu değiştirdi
            self._imo_sonuc(imo, ad_, kaynak_, hata)
        bekle()

    def _imo_sonuc(self, imo, ad, kaynak, hata):
        sessiz = getattr(self, "_sessiz", False)
        gemi_var = self.degiskenler["gemi"]
        mevcut = (gemi_var.get() or "").strip()
        self._duzelt_gizle()
        if ad:
            if not mevcut:
                gemi_var.set(ad)
                self._ipucu("✔ Gemi adı otomatik geldi: %s (%s)" % (ad, kaynak), "#17603A")
            elif M.gemi_anahtar(mevcut) == M.gemi_anahtar(ad):
                self._ipucu("✔ IMO ve gemi adı uyuşuyor (%s)" % kaynak, "#17603A")
            elif sessiz:
                self._ipucu("⚠ Bu IMO %s kaydında '%s' adıyla geçiyor, siparişte '%s' yazıyor" % (kaynak, ad, mevcut), "#8A4300")
                self._duzelt_goster(ad, kaynak)
            elif messagebox.askyesno("Gemi adı", "IMO %s, %s kaydında '%s' adıyla geçiyor.\n\n"
                                                 "Gemi adı '%s' yerine '%s' yapılsın mı?" % (imo, kaynak, ad, mevcut, ad)):
                gemi_var.set(ad)
                self._ipucu("✔ Gemi adı güncellendi: %s (%s)" % (ad, kaynak), "#17603A")
            else:
                self._ipucu("⚠ %s kaydındaki ad: %s" % (kaynak, ad), "#8A4300")
                self._duzelt_goster(ad, kaynak)
            return
        self._ipucu("✖ Gemi adı bulunamadı – lütfen gemi adını elle girin (%s)" % (hata or ""), "#9E2A21")
        if sessiz:
            return
        messagebox.showinfo("Gemi adı bulunamadı", "IMO %s için gemi adı otomatik bulunamadı.\n(%s)\n\n"
                                                   "Lütfen gemi adını elle girin." % (imo, hata or ""))
        try:
            self.girisler["gemi"].focus_set()
        except Exception:
            pass

    # ---------------------------------------------------------------- malzeme satırları
    def _satirlar(self, govde):
        tk.Frame(govde, bg=KART, height=8).pack()
        baslik = "Malzeme satırları" if self.asama == 1 else "Ürün bazlı toplama durumu"
        lbl(govde, baslik, boy=11, kalin=True).pack(anchor="w", pady=(6, 4))
        if self.asama == 1:
            kol = [("malzeme", "Malzeme / açıklama", 260), ("kod", "Kod / IMPA", 100), ("miktar", "Miktar", 80),
                   ("birim", "Birim", 70), ("tedarikci", "Tedarikçi", 140), ("termin", "Termin", 100)]
        else:
            kol = [("malzeme", "Malzeme", 260), ("miktar", "Sipariş", 90), ("birim", "Birim", 70),
                   ("toplama", "Toplama durumu", 140), ("toplanan", "Toplanan", 90), ("satir_notu", "Not", 200)]
        cer = tk.Frame(govde, bg=KART)
        cer.pack(fill="x")
        tv = ttk.Treeview(cer, columns=[c[0] for c in kol], show="headings", height=5)
        for a, b, g in kol:
            tv.heading(a, text=b)
            tv.column(a, width=g, anchor="w")
        tv.pack(side="left", fill="x", expand=True)
        sb = ttk.Scrollbar(cer, orient="vertical", command=tv.yview)
        sb.pack(side="right", fill="y")
        tv.configure(yscrollcommand=sb.set)
        for d, renk in (("Tamamlandı", "#DDF0E4"), ("Toplanıyor", "#FFF2C4"), ("Tedarik bekliyor", "#FBE3E1"),
                        ("Eksik", "#FBE3E1"), ("Muadil önerildi", "#FFE6CC")):
            tv.tag_configure(d, background=renk)
        self.tv = tv
        self.kol = kol

        def yenile():
            tv.delete(*tv.get_children())
            for r in self.db.satirlar(self.s["id"]):
                tv.insert("", "end", iid=str(r["id"]), values=[r[c[0]] or "" for c in kol],
                          tags=(r["toplama"] or "Bekliyor",) if self.asama == 2 else ())
        self._satir_yenile = yenile
        yenile()
        dz = tk.Frame(govde, bg=KART)
        dz.pack(fill="x", pady=(6, 0))
        if self.kilitli:
            return
        if self.asama == 1:
            ttk.Button(dz, text="+ Satır ekle", command=lambda: self._satir_penceresi(None)).pack(side="left")
            ttk.Button(dz, text="Düzenle", command=lambda: self._secili(lambda i: self._satir_penceresi(i))).pack(side="left", padx=6)
            ttk.Button(dz, text="Kaldır", command=lambda: self._secili(self._satir_sil)).pack(side="left")
            tv.bind("<Double-1>", lambda e: self._secili(lambda i: self._satir_penceresi(i)))
        else:
            ttk.Button(dz, text="Toplama durumunu güncelle", command=lambda: self._secili(self._toplama_penceresi)).pack(side="left")
            lbl(dz, "Satıra çift tıklayarak da güncelleyebilirsiniz.", fg=SOLUK, boy=9).pack(side="left", padx=10)
            tv.bind("<Double-1>", lambda e: self._secili(self._toplama_penceresi))

    def _secili(self, fn):
        sec = self.tv.selection()
        if not sec:
            messagebox.showinfo("Satır seçin", "Önce listeden bir satır seçin.")
            return
        fn(int(sec[0]))

    def _satir_penceresi(self, satir_id):
        mevcut = {}
        if satir_id:
            mevcut = [r for r in self.db.satirlar(self.s["id"]) if r["id"] == satir_id][0]
        p = tk.Toplevel(self.ana)
        p.title("Malzeme satırı")
        p.configure(bg=KART)
        p.transient(self.ana.root)
        p.grab_set()
        alanlar = [("malzeme", "Malzeme / açıklama *"), ("kod", "Ürün kodu / IMPA"), ("miktar", "Miktar *"),
                   ("birim", "Birim"), ("tedarikci", "Tedarikçi"), ("termin", "Termin (gg.aa.yyyy)")]
        vars_ = {}
        for i, (a, b) in enumerate(alanlar):
            lbl(p, b, boy=9, kalin=True).grid(row=i, column=0, sticky="w", padx=16, pady=(10 if i == 0 else 4, 0))
            v = tk.StringVar(value=mevcut.get(a) or "")
            if a == "termin":
                cer, e = tarih_alani(p, v, "tarih", genislik=32)
                cer.grid(row=i, column=1, sticky="ew", padx=16, pady=(10 if i == 0 else 4, 0))
            else:
                e = ttk.Entry(p, textvariable=v, width=44)
                e.grid(row=i, column=1, sticky="ew", padx=16, pady=(10 if i == 0 else 4, 0))
            vars_[a] = v
            if i == 0:
                e.focus_set()

        def tamam():
            d = {a: v.get().strip() for a, v in vars_.items()}
            if not d["malzeme"] or not d["miktar"]:
                messagebox.showwarning("Eksik", "Malzeme ve miktar zorunludur.", parent=p)
                return
            if d["termin"] and not M.tarih_coz(d["termin"]):
                messagebox.showwarning("Tarih", "Termin gg.aa.yyyy biçiminde olmalı.", parent=p)
                return
            if d["termin"]:
                d["termin"] = M.tarih_coz(d["termin"]).strftime("%d.%m.%Y")
            if satir_id:
                self.db.satir_guncelle(satir_id, self.k, 1, **d)
            else:
                self.db.satir_ekle(self.s["id"], self.k, **d)
                if self.durum == "todo":
                    self.db.durum_ayarla(self.s["id"], 1, "prog", self.k, "Aşama 1 başladı")
            p.destroy()
            self._satir_yenile()
            self._sag_yenile()

        dz = tk.Frame(p, bg=KART)
        dz.grid(row=len(alanlar), column=0, columnspan=2, sticky="e", padx=16, pady=14)
        ttk.Button(dz, text="Vazgeç", command=p.destroy).pack(side="right", padx=(6, 0))
        ttk.Button(dz, text="Kaydet", style="Vurgu.TButton", command=tamam).pack(side="right")
        p.bind("<Return>", lambda e: tamam())
        ortala(p, self.ana.root)

    def _satir_sil(self, satir_id):
        if messagebox.askyesno("Satırı kaldır", "Seçili malzeme satırı kaldırılsın mı? (İşlem geçmişinde kalır)"):
            self.db.satir_sil(satir_id, self.k)
            self._satir_yenile()
            self._sag_yenile()

    def _toplama_penceresi(self, satir_id):
        r = [x for x in self.db.satirlar(self.s["id"]) if x["id"] == satir_id][0]
        p = tk.Toplevel(self.ana)
        p.title("Toplama durumu")
        p.configure(bg=KART)
        p.transient(self.ana.root)
        p.grab_set()
        lbl(p, r["malzeme"], boy=12, kalin=True).grid(row=0, column=0, columnspan=2, sticky="w", padx=16, pady=(14, 2))
        lbl(p, "Sipariş: %s %s" % (r["miktar"] or "", r["birim"] or ""), fg=SOLUK).grid(row=1, column=0, columnspan=2, sticky="w", padx=16)
        v1 = tk.StringVar(value=r["toplama"] or "Bekliyor")
        v2 = tk.StringVar(value=r["toplanan"] or "")
        v3 = tk.StringVar(value=r["satir_notu"] or "")
        for i, (b, w) in enumerate((("Toplama durumu", ttk.Combobox(p, textvariable=v1, values=TOPLAMA_DURUMLARI, state="readonly", width=30)),
                                    ("Toplanan miktar", ttk.Entry(p, textvariable=v2, width=32)),
                                    ("Not (eksik / muadil açıklaması)", ttk.Entry(p, textvariable=v3, width=32))), start=2):
            lbl(p, b, boy=9, kalin=True).grid(row=i, column=0, sticky="w", padx=16, pady=6)
            w.grid(row=i, column=1, sticky="ew", padx=16, pady=6)

        def tamam():
            if v1.get() == "Tamamlandı" and not v2.get().strip():
                v2.set(r["miktar"] or "")
            self.db.satir_guncelle(satir_id, self.k, 2, toplama=v1.get(), toplanan=v2.get().strip(), satir_notu=v3.get().strip())
            if self.durum == "todo":
                self.db.durum_ayarla(self.s["id"], 2, "prog", self.k, "Aşama 2 başladı")
            p.destroy()
            self._satir_yenile()
            self._sag_yenile()

        dz = tk.Frame(p, bg=KART)
        dz.grid(row=6, column=0, columnspan=2, sticky="e", padx=16, pady=14)
        ttk.Button(dz, text="Vazgeç", command=p.destroy).pack(side="right", padx=(6, 0))
        ttk.Button(dz, text="Kaydet", style="Vurgu.TButton", command=tamam).pack(side="right")
        ortala(p, self.ana.root)

    # ---------------------------------------------------------------- sağ panel
    def _sag(self, sag):
        self.sag_cer = sag
        self._sag_yenile()

    def _sag_yenile(self):
        for w in self.sag_cer.winfo_children():
            w.destroy()
        sag = self.sag_cer
        # tamamlanma koşulları
        k1 = kart(sag)
        k1.pack(fill="x")
        lbl(k1, "Tamamlanma koşulları", boy=11, kalin=True).pack(anchor="w", padx=14, pady=(12, 2))
        lbl(k1, "Aşama yalnızca bu koşullar sağlanınca yeşile döner.", fg=SOLUK, boy=9, wraplength=290).pack(anchor="w", padx=14)
        if self.asama == 6 and self.durum == "na":
            lbl(k1, "Süreç başlatılmadı.", fg=SOLUK, boy=9).pack(anchor="w", padx=14, pady=(6, 12))
        else:
            engeller = M.tamamlama_engelleri(self.db, self.s["id"], self.asama, self.k, self._form_degerleri())
            uyarilar = M.tamamlama_uyarilari(self.db, self.s["id"], self.asama)
            if not engeller:
                lbl(k1, "✔  Tüm koşullar sağlandı", fg="#17603A", kalin=True).pack(anchor="w", padx=14,
                                                                               pady=(8, 4 if uyarilar else 12))
            else:
                for e in engeller[:14]:
                    lbl(k1, "✖  " + e, fg="#9E2A21", boy=9, wraplength=290).pack(anchor="w", padx=14, pady=1)
                if len(engeller) > 14:
                    lbl(k1, "… ve %d madde daha" % (len(engeller) - 14), fg=SOLUK, boy=9).pack(anchor="w", padx=14)
            for u_ in uyarilar:
                lbl(k1, "⚠  %s (zorunlu değil)" % u_, fg="#8A4300", boy=9, wraplength=290).pack(anchor="w", padx=14, pady=1)
            if engeller or uyarilar:
                tk.Frame(k1, bg=KART, height=10).pack()
            if hasattr(self, "engel_lbl") and self.durum != "done":
                self.engel_lbl.configure(text=("Zorunlu / eksik %d madde" % len(engeller)) if engeller else "Tamamlamaya hazır",
                                         fg="#9E2A21" if engeller else "#17603A")

        # ekler
        k2 = kart(sag)
        k2.pack(fill="x", pady=12)
        lbl(k2, "Ekler · Aşama %d" % self.asama, boy=11, kalin=True).pack(anchor="w", padx=14, pady=(12, 4))
        ekler = [e for e in self.db.ekler(self.s["id"], self.asama) if M.gorebilir(self.k, e["ekleyen_seviye"], asama=self.asama)]
        if not ekler:
            lbl(k2, "Henüz dosya yok.", fg=SOLUK, boy=9).pack(anchor="w", padx=14)
        for e in ekler:
            sat = tk.Frame(k2, bg=KART)
            sat.pack(fill="x", padx=14, pady=1)
            link(sat, "📄 " + e["dosya_adi"], lambda ek=e: dosya_ac(self.db.ek_tam_yol(ek)), kalin=False, boy=9).pack(side="left")
            if not self.kilitli:
                x = tk.Label(sat, text="✕", bg=KART, fg=SOLUK, cursor="hand2", font=font(9))
                x.pack(side="right")
                x.bind("<Button-1>", lambda ev, ek=e: self._ek_sil(ek))
        if not self.kilitli and not (self.asama == 6 and self.durum == "na"):
            ttk.Button(k2, text="Dosya / fotoğraf ekle", command=self._ek_ekle).pack(fill="x", padx=14, pady=(8, 12))
        else:
            tk.Frame(k2, bg=KART, height=10).pack()

        # işlem geçmişi
        k3 = kart(sag)
        k3.pack(fill="x")
        lbl(k3, "İşlem geçmişi", boy=11, kalin=True).pack(anchor="w", padx=14, pady=(12, 2))
        tum = self.db.denetim(siparis_id=self.s["id"], limit=200)
        gorunen = [d for d in tum if M.gorebilir(self.k, d["seviye"], asama=d["asama"])]
        gizli = len(tum) - len(gorunen)
        not_ = "Tüm kayıtlar gösteriliyor." if self.k["rol"] == "ust" else (
            "%d kayıt üst seviyede girildiği için gizli." % gizli if gizli else "Görme yetkiniz olan kayıtlar gösteriliyor.")
        lbl(k3, not_, fg=SOLUK, boy=8).pack(anchor="w", padx=14)
        adlar = self.db.kullanici_adlari()
        for d in gorunen[:25]:
            tk.Frame(k3, bg="#EEF1F4", height=1).pack(fill="x", padx=14, pady=(6, 0))
            metin = d["aciklama"] or ""
            if d["alan"] and d["alan"] != "durum" and (d["eski"] or d["yeni"]):
                metin += ": %s → %s" % ((d["eski"] or "boş")[:30], (d["yeni"] or "boş")[:30])
            lbl(k3, metin, boy=9, wraplength=290).pack(anchor="w", padx=14)
            lbl(k3, "%s · %s · Aşama %s" % (M.db_zaman_goster(d["zaman"]), adlar.get(d["kullanici_id"], "?"), d["asama"] or "-"),
                fg=SOLUK, boy=8).pack(anchor="w", padx=14)
        tk.Frame(k3, bg=KART, height=10).pack()

    def _ek_ekle(self):
        yollar = filedialog.askopenfilenames(title="Dosya veya fotoğraf seçin",
                                             filetypes=[("Belge ve görseller", "*.pdf *.jpg *.jpeg *.png *.heic *.docx *.xlsx *.msg *.eml"),
                                                        ("Tüm dosyalar", "*.*")])
        for y in yollar:
            try:
                self.db.ek_ekle(self.s["id"], self.asama, y, self.k)
            except Exception as e:
                messagebox.showerror("Eklenemedi", "%s\n%s" % (y, e))
        if yollar:
            if self.durum == "todo":
                self.db.durum_ayarla(self.s["id"], self.asama, "prog", self.k, "Aşama %d başladı" % self.asama)
            self.ana.bildir("%d dosya eklendi" % len(yollar))
            self._sag_yenile()

    def _ek_sil(self, ek):
        if messagebox.askyesno("Dosyayı kaldır", "%s kaldırılsın mı? (Kaydı işlem geçmişinde kalır)" % ek["dosya_adi"]):
            self.db.ek_sil(ek["id"], self.k)
            self._sag_yenile()

    # ---------------------------------------------------------------- işlemler
    def _form_degerleri(self):
        from st_ortak import tarih_normalle
        turler = {x[0]: x[3] for x in self.tanim["alanlar"]}
        from st_ortak import saat_normalle
        d = {a: (tarih_normalle(v.get(), turler[a]) if turler.get(a) in ("tarih", "tarihsaat") else
                 saat_normalle(v.get()) if turler.get(a) == "saataraligi" else v.get())
             for a, v in self.degiskenler.items()}
        for a, t in self.metin_kutulari.items():
            d[a] = t.get("1.0", "end").strip()
        return d

    def _degisenler(self):
        """Yalnızca kullanıcının bu formda değiştirdiği alanlar (başkasının girdiğini ezmemek için)."""
        d = self._form_degerleri()
        return {a: v for a, v in d.items() if (v or "").strip() != (self._ilk.get(a) or "").strip()}

    def kaydet(self, sessiz=False):
        if self.kilitli and not (self.durum == "done" and self.k["rol"] == "ust"):
            return 0
        d = self._form_degerleri()
        hatalar = []
        for anahtar, etiket, _, tur, _ in self.tanim["alanlar"]:
            h = M.alan_bicim_hatasi(tur, (d.get(anahtar) or "").strip())
            if h:
                hatalar.append("%s %s" % (etiket, h))
        degisen = self._degisenler()
        n, sonuc = self._guvenli_kaydet(degisen, sessiz)
        if sonuc != "ok":
            return 0
        self._ilk = d
        if n and self.durum == "todo":
            self.db.durum_ayarla(self.s["id"], self.asama, "prog", self.k, "Aşama %d başladı" % self.asama)
            self.durum = "prog"
        if self.asama == 1 and ("gemi" in degisen or "imo" in degisen):
            self._gemiyi_bagla(d)  # yalnızca gemi adı / IMO değiştiyse (gereksiz bulut sorgusu olmasın)
        if not sessiz:
            if hatalar:
                messagebox.showwarning("Kaydedildi, ancak düzeltilmesi gerekenler var", "\n".join(hatalar))
            self.ana.bildir("Kaydedildi (%d alan değişti)" % n if n else "Değişiklik yok")
            self.ana.goster("siparis", siparis_id=self.s["id"], asama=self.asama)
        elif n:
            self.ana.bildir("Değişiklikler otomatik kaydedildi (%s, Aşama %d)" % (self.s["no"], self.asama))
        return n

    def _gemiyi_bagla(self, d=None):
        """Gemi adı veya IMO girildiği anda gemi takibe alınır; IMO değişirse gemi kaydı da güncellenir."""
        self.ana._esitle(self.s["id"])

    def _guvenli_kaydet(self, degisen, sessiz=False):
        """(değişen alan sayısı, sonuç). sonuç: 'ok' kaydedildi · 'kuyruk' internet yok, bilgisayarda bekletiliyor ·
        'iptal' kaydedilmedi. Başka biri aynı alanı değiştirdiyse kullanıcıya sorulur."""
        from st_bulut import BaglantiYok
        from st_db import CakismaHatasi, SiparisSilindiHatasi, KullaniciHatasi
        if not degisen:
            return 0, "ok"
        try:
            return self.db.alanlari_kaydet(self.s["id"], self.asama, degisen, self.k, ilk=self._ilk), "ok"
        except CakismaHatasi as e:
            satirlar = ["• %s: %s '%s' yazdı%s — sizin değeriniz: '%s'" % (
                c["etiket"], c["kim"], c["onlarin"] or "(boş)", (" (%s)" % M.db_zaman_goster(c["zaman"])) if c.get("zaman") else "",
                c["sizin"] or "(boş)") for c in e.cakismalar]
            cevap = messagebox.askyesno(
                "Başka bir kullanıcı aynı alanı değiştirdi",
                "Siz bu formu açtıktan sonra şu alan(lar) başka biri tarafından değiştirildi:\n\n%s\n\n"
                "EVET: Sizin yazdığınız kaydedilsin (onlarınkinin üzerine yazılır).\n"
                "HAYIR: Onların yazdığı kalsın (diğer değişiklikleriniz yine kaydedilir)." % "\n".join(satirlar))
            if not cevap:
                for c in e.cakismalar:
                    degisen = dict(degisen)
                    degisen.pop(c["alan"], None)
            try:
                n = self.db.alanlari_kaydet(self.s["id"], self.asama, degisen, self.k, zorla=True)
            except BaglantiYok:
                return self._kuyruga_al(degisen, sessiz)
            if not cevap and not sessiz:
                self.ana._kaydet_cb = None
                self.ana.goster("siparis", siparis_id=self.s["id"], asama=self.asama)
                return n, "iptal"
            return n, "ok"
        except BaglantiYok:
            return self._kuyruga_al(degisen, sessiz)
        except SiparisSilindiHatasi as e:
            messagebox.showwarning("Sipariş silinmiş", str(e))
            self.ana._kaydet_cb = None
            return 0, "iptal"
        except KullaniciHatasi as e:
            messagebox.showwarning("Hesap", str(e))
            self.ana._kaydet_cb = None
            self.ana.after(100, self.ana.cikis_zorla)
            return 0, "iptal"
        except Exception:
            import traceback
            traceback.print_exc()
            return self._kuyruga_al(degisen, sessiz)

    def _kuyruga_al(self, degisen, sessiz):
        """İnternet yok: değişiklikler bu bilgisayarda saklanır, bağlantı gelince kendiliğinden gönderilir."""
        self.ana.bekleyen_ekle(self.s, self.asama, degisen, {a: self._ilk.get(a, "") for a in degisen})
        self._ilk = dict(self._ilk, **degisen)
        mesaj = ("İnternet / bulut bağlantısı yok.\n\n%s · Aşama %d: %d alandaki değişiklik bu bilgisayarda saklandı. "
                 "Bağlantı gelince kendiliğinden kaydedilecek. Programı kapatsanız da kaybolmaz."
                 % (self.s["no"], self.asama, len(degisen)))
        if sessiz:
            self.ana.bildir("Bağlantı yok – değişiklikler bekletiliyor (%s, Aşama %d)" % (self.s["no"], self.asama))
            if not getattr(self.ana, "_kuyruk_uyarildi", False):
                self.ana._kuyruk_uyarildi = True
                messagebox.showwarning("Bağlantı yok", mesaj)
        else:
            messagebox.showwarning("Bağlantı yok", mesaj)
        return len(degisen), "kuyruk"

    def tamamla(self):
        d = self._form_degerleri()
        n, sonuc = self._guvenli_kaydet(self._degisenler())
        if sonuc != "ok":
            if sonuc == "kuyruk":
                messagebox.showinfo("Aşama tamamlanamadı", "Bağlantı yokken aşama tamamlanamaz. Değişiklikleriniz saklandı; "
                                                           "bağlantı gelince tekrar deneyin.")
            return
        self._ilk = d
        engeller = M.tamamlama_engelleri(self.db, self.s["id"], self.asama, self.k)
        if engeller:
            messagebox.showwarning("Aşama tamamlanamaz", "Önce şunlar giderilmeli:\n\n• " + "\n• ".join(engeller))
            self.ana._kaydet_cb = None
            self.ana.goster("siparis", siparis_id=self.s["id"], asama=self.asama)
            return
        uyarilar = M.tamamlama_uyarilari(self.db, self.s["id"], self.asama)
        if uyarilar:
            belge = self.asama == 4
            if not vazgec_tamamla(self.ana, "Belge yüklenmedi" if belge else "Fotoğraf yüklenmedi",
                                  "⚠  %s.\n\n%s aşamayı tamamlamak istiyor musunuz?" % (
                                      "\n⚠  ".join(uyarilar), "Belgesiz" if belge else "Fotoğrafsız")):
                return
        elif not messagebox.askyesno("Aşamayı tamamla", "Aşama %d (%s) tamamlandı olarak işaretlensin mi?" % (self.asama, self.tanim["kisa"])):
            return
        sonraki = {1: "Depo iş listesine düştü", 2: "Operasyon ve Evrak bilgilendirildi", 3: "Evrak bilgilendirildi",
                   4: "Finans iş listesine düştü", 5: "Sipariş kapandı", 6: "İade / değişim süreci kapandı"}[self.asama]
        self.db.durum_ayarla(self.s["id"], self.asama, "done", self.k,
                             "Aşama %d tamamlandı (%s) · %s%s" % (self.asama, self.tanim["kisa"], sonraki,
                                                                 "".join(" · %s" % u_ for u_ in uyarilar)))
        if self.asama == 1:
            self._gemiyi_bagla(d)
        if self.asama == 6 and d.get("islem_turu") == "Sipariş iptali":
            self.db.iptal_et(self.s["id"], self.k)
            sonraki = "Sipariş iptal edildi"
        self.ana._kaydet_cb = None
        self.ana.bildir("Aşama %d tamamlandı · %s" % (self.asama, sonraki))
        yeni = self.db.durumlar(self.s["id"])
        sonraki_asama = next((n for n in range(1, 6) if yeni.get(n) != "done"), self.asama)
        self.ana.goster("siparis", siparis_id=self.s["id"], asama=sonraki_asama)

    def yeniden_ac(self):
        if messagebox.askyesno("Aşamayı yeniden aç", "Aşama %d yeniden 'Devam ediyor' durumuna alınsın mı?" % self.asama):
            self.db.durum_ayarla(self.s["id"], self.asama, "prog", self.k, "Aşama %d yeniden açıldı (Üst Yönetici)" % self.asama)
            self.ana._kaydet_cb = None
            self.ana.goster("siparis", siparis_id=self.s["id"], asama=self.asama)

    def asama6_baslat(self):
        if messagebox.askyesno("İade / Değişim / İptal", "Bu sipariş için iade / değişim / iptal süreci başlatılsın mı?"):
            self.db.durum_ayarla(self.s["id"], 6, "prog", self.k, "Aşama 6 açıldı: İade / Değişim / İptal")
            self.ana.goster("siparis", siparis_id=self.s["id"], asama=6)

    def asama6_geri_al(self):
        if messagebox.askyesno("Süreci kapat", "İade / değişim süreci yapılmadan kapatılsın mı? (Aşama yeniden pasif olur)"):
            self.db.durum_ayarla(self.s["id"], 6, "na", self.k, "Aşama 6 vazgeçildi, pasife alındı")
            self.ana._kaydet_cb = None
            self.ana.goster("siparis", siparis_id=self.s["id"], asama=6)


# =====================================================================================
# Gemi ekranları, işlem geçmişi, kullanıcılar ve ayarlar AnaPencere'ye eklenir
from st_arayuz_gemi import gemi_ekranlarini_ekle  # noqa: E402
gemi_ekranlarini_ekle(AnaPencere)
